import { describe, expect, it } from "vitest";
import { DEPOSIT_METHODS } from "@/lib/payment-methods";
import { parseTeslaMarket } from "@/lib/market";
import { State } from "country-state-city";
import { depositStatus } from "@/lib/deposit-review";

describe("Deposit proof review", () => {
  it("never credits a balance based only on a matching screenshot", () => {
    expect(depositStatus({ readable: true, amount_matches: true, recipient_matches: true, status_completed: true })).toBe("pending_receipt");
  });
  it("flags mismatched payment details for review", () => {
    expect(depositStatus({ readable: true, amount_matches: false, recipient_matches: true, status_completed: true })).toBe("needs_review");
  });
});

describe("Order location and payments", () => {
  it("offers every state of the selected country", () => {
    const nigeria = State.getStatesOfCountry("NG") ?? [];
    const nigeriaNames = nigeria.map((state) => state.name);
    expect(nigeriaNames).toContain("Lagos");
    expect(nigeriaNames).toContain("Abuja Federal Capital Territory");
    expect(nigeriaNames).not.toContain("London");
  });
  it("shares all six requested methods with the correct details", () => {
    expect(DEPOSIT_METHODS.map((method) => method.label)).toEqual(["Bitcoin", "USDT", "Ethereum", "Card"]);
    expect(DEPOSIT_METHODS.slice(0, 3).map((method) => method.pay)).toEqual(Array(3).fill("adress1235388"));
  });
});
describe("Actual Tesla quotes", () => {
  it("compares against the previous session, not the start of the month", () => {
    const quote = parseTeslaMarket({ chart: { result: [{ meta: { symbol: "TSLA", currency: "USD", regularMarketPrice: 250, regularMarketTime: 1000, chartPreviousClose: 180 }, timestamp: [1, 2, 3], indicators: { quote: [{ close: [180, 240, 250] }] } }] } });
    expect(quote.previousClose).toBe(240);
    expect(quote.change).toBe(10);
    expect(quote.changePercent).toBeCloseTo(4.166667);
  });
  it("rejects absent quotes instead of inventing prices", () => {
    expect(() => parseTeslaMarket({ chart: { result: null } })).toThrow();
  });
});