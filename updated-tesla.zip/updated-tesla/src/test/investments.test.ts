import { describe, expect, it } from "vitest";
import { ASSETS, investmentSchema, parseAssetQuote } from "@/lib/investments";

describe("Multi-asset investments", () => {
  it("offers each additional investment alongside Tesla", () => {
    expect(ASSETS.map((a) => a.symbol)).toEqual(["TSLA", "AAPL", "NVDA", "BTC", "ETH", "SOL"]);
  });
  it("validates investment amounts and supported symbols", () => {
    expect(investmentSchema.safeParse({ symbol: "BTC", amount: 25.50 }).success).toBe(true);
    for (const amount of [0, -1, 1.001, Infinity, NaN, 10_000_001]) expect(investmentSchema.safeParse({ symbol: "BTC", amount }).success).toBe(false);
    expect(investmentSchema.safeParse({ symbol: "FAKE", amount: 25 }).success).toBe(false);
  });
  it("uses each asset's actual feed rate and timestamp", () => {
    const quote = parseAssetQuote({ chart: { result: [{ meta: { symbol: "BTC-USD", currency: "USD", regularMarketPrice: 60000, regularMarketTime: 1000, previousClose: 50000 } }] } }, "BTC-USD");
    expect(quote.price).toBe(60000);
    expect(quote.timestamp).toBe(1000);
    expect(quote.changePercent).toBe(20);
  });
  it("never substitutes a wrong asset or invented rate", () => {
    expect(() => parseAssetQuote({ chart: { result: null } }, "BTC-USD")).toThrow();
    expect(() => parseAssetQuote({ chart: { result: [{ meta: { symbol: "TSLA", currency: "USD", regularMarketPrice: 100, regularMarketTime: 1000 } }] } }, "BTC-USD")).toThrow();
  });
});