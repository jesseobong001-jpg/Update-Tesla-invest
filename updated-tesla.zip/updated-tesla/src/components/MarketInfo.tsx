import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getTeslaMarket } from "@/lib/market.functions";

export const marketQueryOptions = queryOptions({ queryKey: ["tesla-market"], queryFn: () => getTeslaMarket(), staleTime: 60_000, refetchInterval: 60_000 });
const usd = (n: number | null) => n === null ? "—" : n.toLocaleString("en-US", { style: "currency", currency: "USD" });

export function MarketInfo() {
  const { data, refetch, isFetching } = useSuspenseQuery(marketQueryOptions);
  const q = data.quote;
  return <section id="tesla-market" className="mt-10 scroll-mt-6 border-y border-chrome/20 py-8">
    <div className="flex items-center justify-between"><h2 className="text-lg font-semibold">TSLA · Nasdaq</h2><Button type="button" variant="ghost" size="icon" aria-label="Refresh market data" title="Refresh market data" disabled={isFetching} onClick={() => void refetch()}><RefreshCw className={isFetching ? "animate-spin" : ""} /></Button></div>
    {q ? <>
      <p className="mt-6 font-wide text-4xl">{usd(q.price)}</p>
      <p className="mt-3 text-sm text-chrome/70">{q.change !== null && q.changePercent !== null ? `${q.change >= 0 ? "+" : ""}${usd(q.change)} (${q.changePercent >= 0 ? "+" : ""}${q.changePercent.toFixed(2)}%) vs previous close` : "Previous close unavailable"}</p>
      <div className="mt-8 grid grid-cols-2 gap-6 sm:grid-cols-3">{[
        ["Previous close", usd(q.previousClose)], ["Day high", usd(q.dayHigh)], ["Day low", usd(q.dayLow)], ["Volume", q.volume?.toLocaleString("en-US") ?? "—"], ["52-week high", usd(q.yearHigh)], ["52-week low", usd(q.yearLow)],
      ].map(([label, value]) => <div key={label}><p className="text-xs text-chrome/50">{label}</p><p className="mt-2 text-base">{value}</p></div>)}</div>
      <p className="mt-6 text-xs leading-relaxed text-chrome/50">Yahoo Finance · Latest quote: {new Date(q.timestamp * 1000).toLocaleString("en-US", { timeZone: "America/New_York" })} ET. Data may be delayed; not a real-time trading feed.</p>
    </> : <p role="status" className="mt-6 text-sm text-chrome/60">{data.error}</p>}
  </section>;
}