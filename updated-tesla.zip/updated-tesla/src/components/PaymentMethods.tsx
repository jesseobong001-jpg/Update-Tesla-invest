import { useState } from "react";
import { Copy, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DEPOSIT_METHODS, type DepositMethod } from "@/lib/payment-methods";

const CRYPTO_METHODS = DEPOSIT_METHODS.filter((method) => method.group === "Crypto");
const CARD_METHOD = DEPOSIT_METHODS.find((method) => method.group === "Card")!;

export function PaymentMethods({ value, onChange }: { value: DepositMethod | null; onChange: (method: DepositMethod | null) => void }) {
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState(false);
  const [cryptoOpen, setCryptoOpen] = useState(false);
  async function copy() {
    if (!value) return;
    try { await navigator.clipboard.writeText(value.pay); setCopied(true); setCopyError(false); }
    catch { setCopyError(true); }
  }
  return <div className="space-y-4">
    {value ? <>
      <p className="text-sm text-chrome/70">{value.group} · {value.label} ({value.sub})</p>
      {value.group === "Card" ? <p className="rounded-lg border border-chrome/20 p-4 text-sm text-chrome/70">Pay by card. Card details aren't collected on this site — no card is charged yet.</p> : <div className="rounded-lg border border-chrome/20 p-4">
        <p className="text-xs text-chrome/60">{value.group === "Crypto" ? "Send to this address" : "Send to this account"}</p>
        <div className="mt-2 flex items-center justify-between gap-2">
          <p className="break-all text-sm">{value.pay}</p>
          <Button type="button" variant="ghost" size="icon" aria-label={copied ? "Copied" : "Copy payment details"} title="Copy payment details" onClick={copy}>{copied ? <Check /> : <Copy />}</Button>
        </div>
        {copyError && <p role="status" className="mt-2 text-xs text-crimson">Couldn't copy. Select and copy the details above.</p>}
      </div>}
      <p className="text-xs text-chrome/60">Payment details are unverified. No payment is processed here.</p>
      <Button type="button" variant="ghost" className="text-chrome/70" onClick={() => { setCopied(false); onChange(null); }}>Change method</Button>
    </> : <div className="space-y-3">
      <Button type="button" className="h-14 w-full rounded-lg border border-chrome/20 bg-transparent text-sm uppercase tracking-widest text-chrome hover:bg-chrome/10 hover:text-chrome" aria-expanded={cryptoOpen} onClick={() => setCryptoOpen((open) => !open)}>
        Pay with crypto
      </Button>
      {cryptoOpen && <div className="grid grid-cols-3 gap-2" role="group" aria-label="Crypto options">
        {CRYPTO_METHODS.map((method) => <Button key={method.label} type="button" variant="ghost" className="h-16 flex-col gap-1 rounded-lg border border-chrome/20 px-1 text-chrome hover:bg-chrome/10" onClick={() => onChange(method)}>
          <span className="text-sm">{method.label}</span><span className="text-xs text-chrome/50">{method.sub}</span>
        </Button>)}
      </div>}
      <Button type="button" variant="ghost" className="h-16 w-full flex-col gap-1 rounded-lg border border-chrome/20 text-chrome hover:bg-chrome/10" onClick={() => onChange(CARD_METHOD)}>
        <span className="text-sm">Card</span><span className="text-xs text-chrome/50">{CARD_METHOD.sub}</span>
      </Button>
    </div>}
  </div>;
}
