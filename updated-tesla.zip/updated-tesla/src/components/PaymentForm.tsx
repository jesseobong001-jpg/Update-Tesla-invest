import { useState } from "react";

export interface PaymentFormProps {
  onPay?: (details: {
    cardName: string;
    cardNumber: string;
    expiry: string;
    securityCode: string;
    street: string;
    city: string;
    state: string;
    zip: string;
    saveCard: boolean;
  }) => void;
}

function formatExpiry(value: string) {
  const digits = value.replace(/\D/g, "").slice(0, 4);
  if (digits.length > 2) return `${digits.slice(0, 2)} / ${digits.slice(2)}`;
  return digits;
}

export default function PaymentForm({ onPay }: PaymentFormProps = {}) {
  const [cardName, setCardName] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [securityCode, setSecurityCode] = useState("");
  const [street, setStreet] = useState("");
  const [city, setCity] = useState("");
  const [state, setState] = useState("");
  const [zip, setZip] = useState("");
  const [saveCard, setSaveCard] = useState(true);

  const handleSubmit = () => {
    const details = {
      cardName,
      cardNumber,
      expiry,
      securityCode,
      street,
      city,
      state,
      zip,
      saveCard,
    };
    console.log(details);
    onPay?.(details);
  };

  return (
    <div className="w-full max-w-md mx-auto bg-white rounded-xl shadow-xl overflow-hidden font-sans border border-gray-100">
      <div className="p-6 md:p-8">
        <h2 className="text-base font-semibold text-gray-900 mb-6">Card details</h2>

        <div className="space-y-4">
          <div className="relative">
            <label className="block text-xs font-medium text-gray-500 mb-1">Name on card</label>
            <input
              type="text"
              autoComplete="cc-name"
              value={cardName}
              onChange={(e) => setCardName(e.target.value)}
              placeholder="John Doe"
              className="w-full h-12 px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-900 focus:outline-none focus:border-gray-900"
            />
          </div>

          <div className="relative">
            <label className="block text-xs font-medium text-gray-500 mb-1">Card number</label>
            <div className="relative">
              <input
                type="text"
                inputMode="numeric"
                autoComplete="cc-number"
                value={cardNumber}
                onChange={(e) => setCardNumber(e.target.value.replace(/\s/g, "").slice(0, 16))}
                placeholder="•••• •••• •••• ••••"
                className="w-full h-12 pr-10 px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-900 focus:outline-none focus:border-gray-900"
              />
              <svg
                className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth={2}
              >
                <rect x="5" y="11" width="14" height="10" rx="2" />
                <path d="M8 11V7a4 4 0 018 0v4" />
              </svg>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="relative">
              <label className="block text-xs font-medium text-gray-500 mb-1">Expiry date</label>
              <input
                type="text"
                inputMode="numeric"
                autoComplete="cc-exp"
                value={expiry}
                onChange={(e) => setExpiry(formatExpiry(e.target.value))}
                placeholder="MM / YY"
                className="w-full h-12 px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-900 focus:outline-none focus:border-gray-900"
              />
            </div>

            <div className="relative">
              <label className="block text-xs font-medium text-gray-500 mb-1">Security code</label>
              <input
                type="password"
                inputMode="numeric"
                autoComplete="cc-csc"
                value={securityCode}
                onChange={(e) => setSecurityCode(e.target.value.replace(/\D/g, "").slice(0, 3))}
                placeholder="•••"
                className="w-full h-12 pr-10 px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-900 focus:outline-none focus:border-gray-900"
              />
              <svg
                className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth={2}
              >
                <rect x="2" y="5" width="20" height="14" rx="2" />
                <path d="M2 10h20" />
              </svg>
            </div>
          </div>

          <div className="relative">
            <label className="block text-xs font-medium text-gray-500 mb-1">Street address</label>
            <input
              type="text"
              autoComplete="cc-street-address"
              value={street}
              onChange={(e) => setStreet(e.target.value)}
              placeholder="123 Main Street"
              className="w-full h-12 px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-900 focus:outline-none focus:border-gray-900"
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="relative">
              <label className="block text-xs font-medium text-gray-500 mb-1">City</label>
              <input
                type="text"
                autoComplete="cc-address-level2"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="City"
                className="w-full h-12 px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-900 focus:outline-none focus:border-gray-900"
              />
            </div>

            <div className="relative">
              <label className="block text-xs font-medium text-gray-500 mb-1">State</label>
              <input
                type="text"
                autoComplete="cc-address-level1"
                value={state}
                onChange={(e) => setState(e.target.value)}
                placeholder="State"
                className="w-full h-12 px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-900 focus:outline-none focus:border-gray-900"
              />
            </div>

            <div className="relative">
              <label className="block text-xs font-medium text-gray-500 mb-1">Zip</label>
              <input
                type="text"
                inputMode="numeric"
                autoComplete="cc-postal-code"
                value={zip}
                onChange={(e) => setZip(e.target.value.replace(/\D/g, "").slice(0, 10))}
                placeholder="Zip"
                className="w-full h-12 px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-900 focus:outline-none focus:border-gray-900"
              />
            </div>
          </div>

          <label className="flex items-center gap-3 cursor-pointer">
            <button
              type="button"
              role="switch"
              aria-checked={saveCard}
              onClick={() => setSaveCard(!saveCard)}
              className={`relative w-12 h-6 rounded-full transition-colors ${
                saveCard ? "bg-red-600" : "bg-gray-300"
              }`}
            >
              <span
                className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${
                  saveCard ? "translate-x-6" : "translate-x-0"
                }`}
              />
            </button>
            <span className="text-sm text-gray-800">Save card details for next time</span>
          </label>
        </div>

        <button
          type="button"
          onClick={handleSubmit}
          className="mt-6 w-full bg-gray-900 hover:bg-black text-white text-sm font-semibold py-3 rounded-md transition-colors"
        >
          Pay now
        </button>
      </div>
    </div>
  );
}
