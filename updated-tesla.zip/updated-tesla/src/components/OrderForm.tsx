import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { PaymentMethods } from "@/components/PaymentMethods";
import type { DepositMethod } from "@/lib/payment-methods";
import { installment, money, priceNumber, type Plan } from "@/lib/models";
import { getCountries, getStates } from "@/lib/locations.functions";

export function OrderForm({ model, userId, onClose, plan }: { model: { name: string; img: string; price: string }; userId: string; onClose: () => void; plan?: Plan }) {
  const due = plan ? `${money(installment(model.price, plan))}` : money(priceNumber(model.price));
  const [f, setF] = useState({ full_name: "", address: "", country: "", city: "" });
  const [countryCode, setCountryCode] = useState("");
  const [method, setMethod] = useState<DepositMethod | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  const countries = useQuery({ queryKey: ["countries"], queryFn: () => getCountries(), staleTime: Infinity });
  const states = useQuery({ queryKey: ["states", countryCode], queryFn: () => getStates({ data: { country: countryCode } }), enabled: Boolean(countryCode), staleTime: Infinity });
  async function buy(e: React.FormEvent) {
    e.preventDefault();
    if (Object.values(f).some((value) => !value.trim()) || !method) return setMsg("Complete your address and select a payment method.");
    if (!states.data?.includes(f.city)) return setMsg("Select a state in your chosen country.");
    setBusy(true); setMsg(null);
    try {
      const { error } = await supabase.from("orders").insert({ ...f, model: model.name, price: model.price, user_id: userId, payment_method: method.label, payment_plan: plan ? `${plan.label} · ${due}/${plan.unit}` : "Full payment" });
      if (error) { setMsg(error.message); return; }
      setDone(true);
    } catch { setMsg("Couldn't place your order. Please try again."); }
    finally { setBusy(false); }
  }
  const input = "w-full rounded-lg border border-chrome/20 bg-ink px-4 py-3 text-sm text-chrome outline-none focus:border-chrome/60 disabled:opacity-50";
  return <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/80 p-4 backdrop-blur sm:items-center" onClick={() => { if (!busy) onClose(); }}>
    <div role="dialog" aria-modal="true" aria-labelledby="order-title" className="max-h-[90svh] w-full max-w-md overflow-y-auto rounded-lg border border-chrome/15 bg-ink p-6" onClick={(e) => e.stopPropagation()}>
      <div className="flex items-start justify-between"><h2 id="order-title" className="font-wide text-3xl uppercase">Order</h2><Button type="button" variant="ghost" size="icon" disabled={busy} onClick={onClose} aria-label="Close"><X /></Button></div>
      <img src={model.img} alt={`Tesla ${model.name}`} className="mt-4 aspect-[3/2] w-full rounded-lg object-cover" />
      <div className="mt-4 flex flex-wrap justify-between gap-2"><p className="font-wide text-lg uppercase">{model.name}</p><p className="font-wide text-lg">{model.price}</p></div>
      {plan && <p className="mt-1 text-sm text-chrome/70">{due} per {plan.unit} for {plan.label}</p>}
      {done ? <p role="status" className="mt-6 text-sm text-chrome/80">Order placed for your {model.name}. Payment pending — no charge has been made.</p> : <form onSubmit={buy} className="mt-6 space-y-3">
        <input required aria-label="Full name" className={input} placeholder="Full name" maxLength={100} value={f.full_name} onChange={(e) => setF({ ...f, full_name: e.target.value })} />
        <input required aria-label="Street address" className={input} placeholder="Street address" maxLength={200} value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} />
        <label className="block space-y-2 text-xs text-chrome/60"><span>Country</span><select required aria-label="Country" className={input} value={countryCode} onChange={(e) => { const country = countries.data?.find((item) => item.code === e.target.value); setCountryCode(e.target.value); setF({ ...f, country: country?.name ?? "", city: "" }); }}>
          <option value="">{countries.isPending ? "Loading countries…" : "Select country"}</option>{countries.data?.map((country) => <option key={country.code} value={country.code}>{country.name}</option>)}
        </select></label>
        <label className="block space-y-2 text-xs text-chrome/60"><span>State</span><select required aria-label="State" className={input} disabled={!countryCode || states.isPending || !states.data?.length} value={f.city} onChange={(e) => setF({ ...f, city: e.target.value })}>
          <option value="">{!countryCode ? "Select country first" : states.isPending ? "Loading states…" : "Select state"}</option>{f.city && !(states.data ?? []).includes(f.city) && <option value={f.city}>{f.city}</option>}{(states.data ?? []).map((state) => <option key={state} value={state}>{state}</option>)}
        </select></label>
        {states.data?.length === 0 && countryCode && <p className="text-xs text-crimson">No states listed for this country. Choose another country or contact us before ordering.</p>}
        {(countries.isError || states.isError) && <Button type="button" variant="ghost" onClick={() => { void countries.refetch(); if (countryCode) void states.refetch(); }}>Couldn't load locations. Retry</Button>}
        <h3 className="pt-4 text-sm font-semibold uppercase">Payment method</h3><PaymentMethods value={method} onChange={setMethod} />
        {msg && <p role="alert" className="text-xs text-crimson">{msg}</p>}
        <Button disabled={busy || !method} type="submit" className="h-12 w-full bg-chrome text-ink hover:bg-chrome/85">{busy ? "Placing order…" : method?.group === "Card" ? `Pay ${due}` : "Buy now"}</Button>
      </form>}
    </div>
  </div>;
}