import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import teslaWordmark from "@/assets/tesla_wordmark.png";

const LINKS = [
  { to: "/reserve", label: "Preorder" },
  { to: "/stocks", label: "Investment" },
  { to: "/payment-plans", label: "Payment plans" },
] as const;

const BASE = "font-wide font-bold uppercase text-chrome hover:text-chrome/70 shrink-0 whitespace-nowrap text-[0.68rem] tracking-[0.08em] md:text-base md:tracking-[0.18em]";

export function AppNav({ right, borderless }: { right?: ReactNode; borderless?: boolean }) {
  return (
    <nav className={`${borderless ? "" : "border-b border-chrome/10 "}px-4 py-4 md:px-10 md:py-5`}>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between sm:gap-6">
        <Link to="/" aria-label="Tesla home" className="shrink-0">
          <img src={teslaWordmark} alt="Tesla" className="w-32 md:w-36" />
        </Link>
        <div className="flex w-full items-center justify-between gap-x-2 sm:w-auto sm:justify-end sm:gap-x-9">
          {LINKS.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={BASE}
              activeProps={{ className: `${BASE} underline decoration-2 underline-offset-8` }}
            >
              {link.label}
            </Link>
          ))}
          {right}
        </div>
      </div>
    </nav>
  );
}
