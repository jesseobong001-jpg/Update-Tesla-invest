import { getAdminUsers } from "@/lib/admin.functions";
import { useEffect, useState } from "react";

interface UserRow {
  id: string;
  email: string;
  orders: number;
  deposits: number;
  wallet: number;
  createdAt: string;
  lastSignIn: string | undefined;
}

export default function UserManagement() {
  const [users, setUsers] = useState<UserRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const list = await getAdminUsers();
      setUsers(list);
      setLoading(false);
    };
    void load();
  }, []);

  if (loading) return <p className="text-chrome/60">Loading users…</p>;

  return (
    <div className="rounded-3xl border border-chrome/15 p-6">
      <h3 className="font-wide text-xl uppercase mb-4">All users</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm border-collapse">
          <thead>
            <tr className="border-b border-chrome/10">
              <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">User ID</th>
              <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">Email</th>
              <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">Orders</th>
              <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">Deposits</th>
              <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">
                Wallet balance
              </th>
              <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">Joined</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-chrome/10">
            {users.map((u) => (
              <tr key={u.id} className="hover:bg-chrome/5 transition">
                <td className="py-3 text-chrome/90 truncate max-w-xs">{u.id}</td>
                <td className="py-3 text-chrome/90">{u.email}</td>
                <td className="py-3 text-chrome/90">{u.orders}</td>
                <td className="py-3 text-chrome/90">{u.deposits}</td>
                <td className="py-3 text-chrome/90">${u.wallet.toLocaleString()}</td>
                <td className="py-3 text-chrome/60 text-xs">
                  {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : "—"}
                </td>
              </tr>
            ))}
            {users.length === 0 && (
              <tr>
                <td colSpan={6} className="py-6 text-center text-chrome/50">
                  No users found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
