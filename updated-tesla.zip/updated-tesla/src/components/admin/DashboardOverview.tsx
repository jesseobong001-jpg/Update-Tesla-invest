import { getAdminStats } from "@/lib/admin.functions";
import { getPrices, getCryptoDestinations } from "@/lib/admin";
import { useEffect, useState } from "react";
import { CreditCard, FileText, LayoutDashboard, Users } from "lucide-react";

const statCards = [
  { label: "Users", icon: Users, color: "bg-chrome/10 text-chrome" },
  { label: "Orders", icon: CreditCard, color: "bg-chrome/10 text-chrome" },
  { label: "Deposits", icon: FileText, color: "bg-crimson/10 text-crimson" },
  { label: "Card payments", icon: LayoutDashboard, color: "bg-gray-900/10 text-gray-900" },
] as const;

export default function DashboardOverview() {
  const [stats, setStats] = useState<{
    users: number;
    orders: number;
    deposits: number;
    payments: number;
  }>({
    users: 0,
    orders: 0,
    deposits: 0,
    payments: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const s = await getAdminStats();
      setStats(s);
      setLoading(false);
    };
    void load();
  }, []);

  const prices = getPrices();
  const crypto = getCryptoDestinations();

  if (loading) return <p className="text-chrome/60">Loading…</p>;

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {statCards.map((c, i) => {
          const values = [stats.users, stats.orders, stats.deposits, stats.payments];
          return (
            <div key={c.label} className="rounded-3xl border border-chrome/15 p-6">
              <p className="text-xs uppercase tracking-widest text-chrome/50">{c.label}</p>
              <p className="mt-2 font-wide text-3xl">{values[i]}</p>
            </div>
          );
        })}
      </div>

      <div className="rounded-3xl border border-chrome/15 p-6">
        <h3 className="font-wide text-xl uppercase mb-4">Configured prices</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {Object.entries(prices).map(([model, price]) => (
            <div key={model} className="p-3 rounded-xl border border-chrome/10 bg-chrome/5">
              <p className="text-xs text-chrome/60">{model}</p>
              <p className="mt-1 font-wide text-sm">{price}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-3xl border border-chrome/15 p-6">
        <h3 className="font-wide text-xl uppercase mb-4">Crypto destinations</h3>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {Object.entries(crypto).map(([label, addr]) => (
            <div key={label} className="p-3 rounded-xl border border-chrome/10">
              <p className="text-xs text-chrome/60">{label}</p>
              <p className="mt-1 text-sm break-all text-chrome">{addr}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
