import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { adminLogin, isAdminAuthenticated } from "@/lib/admin";
import { Button } from "@/components/ui/button";

export default function AdminLogin() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (isAdminAuthenticated()) {
    navigate({ to: "/admin-dashboard" });
    return null;
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    const ok = adminLogin(email, password);
    setBusy(false);
    if (ok) navigate({ to: "/admin-dashboard" });
    else setMsg("Invalid admin credentials.");
  }

  return (
    <main className="min-h-[100svh] w-full bg-ink text-chrome flex items-center justify-center px-6">
      <div className="max-w-sm w-full">
        <div className="rounded-3xl border border-chrome/15 bg-ink p-8 md:p-12">
          <h2 className="font-wide text-3xl uppercase text-center mb-2">Admin login</h2>
          <p className="text-center text-sm text-chrome/60 mb-8">Tesla investments admin panel</p>
          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-2">
              <label className="block text-xs text-chrome/60">Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-lg border border-chrome/20 bg-transparent px-4 py-3 text-chrome outline-none focus:border-chrome/60"
              />
            </div>
            <div className="space-y-2">
              <label className="block text-xs text-chrome/60">Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-lg border border-chrome/20 bg-transparent px-4 py-3 text-chrome outline-none focus:border-chrome/60"
              />
            </div>
            {msg && <p className="text-xs text-crimson">{msg}</p>}
            <Button
              type="submit"
              disabled={busy}
              className="h-12 w-full rounded-full bg-chrome text-ink text-sm font-semibold uppercase hover:bg-chrome/85 disabled:opacity-50"
            >
              {busy ? "Signing in…" : "Sign in"}
            </Button>
          </form>
          <p className="mt-6 text-center text-xs text-chrome/50">admin@tesla.app · 1234Admin5678</p>
        </div>
      </div>
    </main>
  );
}
