import { useState } from "react";
import { getCryptoDestinations, setCryptoDestinations } from "@/lib/admin";
import { Button } from "@/components/ui/button";

const CRYPTO_METHODS = ["Bitcoin", "USDT", "Ethereum"] as const;

export default function CryptoManagement() {
  const [destinations, setDestinations] = useState(getCryptoDestinations());
  const [msg, setMsg] = useState<string | null>(null);

  function save() {
    setCryptoDestinations(destinations);
    setMsg("Crypto destinations saved.");
    setTimeout(() => setMsg(null), 3000);
  }

  return (
    <div className="rounded-3xl border border-chrome/15 p-6">
      <h3 className="font-wide text-xl uppercase mb-4">Update crypto payment destinations</h3>
      <p className="text-sm text-chrome/60 mb-6">These addresses appear on the deposit screens.</p>
      <div className="space-y-4">
        {CRYPTO_METHODS.map((method) => (
          <div key={method} className="flex flex-col gap-2">
            <label className="text-xs uppercase tracking-widest text-chrome/50">{method}</label>
            <input
              type="text"
              value={destinations[method] ?? ""}
              onChange={(e) => setDestinations({ ...destinations, [method]: e.target.value })}
              placeholder="wallet address"
              className="w-full rounded-lg border border-chrome/20 bg-transparent px-4 py-3 text-chrome outline-none focus:border-chrome/60"
            />
          </div>
        ))}
      </div>
      <Button
        onClick={save}
        className="h-11 rounded-full bg-chrome text-ink text-sm font-semibold uppercase hover:bg-chrome/85"
      >
        Save destinations
      </Button>
      {msg && <p className="mt-4 text-sm text-chrome/70">{msg}</p>}
    </div>
  );
}
