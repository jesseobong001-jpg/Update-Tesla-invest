import { useState } from "react";
import AdminLayout, { type AdminTab } from "@/components/admin/AdminLayout";
import DashboardOverview from "@/components/admin/DashboardOverview";
import UserManagement from "@/components/admin/UserManagement";
import OrderManagement from "@/components/admin/OrderManagement";
import PriceManagement from "@/components/admin/PriceManagement";
import CryptoManagement from "@/components/admin/CryptoManagement";
import PaymentSubmissions from "@/components/admin/PaymentSubmissions";
import ContentManagement from "@/components/admin/ContentManagement";

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState<AdminTab>("overview");

  const tabs: Record<AdminTab, React.ReactNode> = {
    overview: <DashboardOverview />,
    users: <UserManagement />,
    orders: <OrderManagement />,
    prices: <PriceManagement />,
    crypto: <CryptoManagement />,
    payments: <PaymentSubmissions />,
    content: <ContentManagement />,
  };

  return (
    <AdminLayout activeTab={activeTab} onTabChange={setActiveTab}>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="font-wide text-3xl uppercase">Admin panel</h1>
        </div>
        {tabs[activeTab]}
      </div>
    </AdminLayout>
  );
}
