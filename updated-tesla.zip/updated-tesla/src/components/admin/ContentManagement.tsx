import { useState } from "react";
import { getWebsiteContent, setWebsiteContent } from "@/lib/admin";
import { Button } from "@/components/ui/button";

const CONTENT_FIELDS = [
  { key: "heroTitle", label: "Hero title", placeholder: "Tesla Roadster — Models and Investments" },
  {
    key: "heroDescription",
    label: "Hero description",
    placeholder: "Preorder the new Tesla Roadster or invest in TSLA from one place.",
  },
  { key: "stocksTitle", label: "Stocks section title", placeholder: "Invest in Tesla" },
  {
    key: "stocksDescription",
    label: "Stocks section description",
    placeholder: "Own a piece of the company building electric cars...",
  },
  { key: "reserveTitle", label: "Reserve section title", placeholder: "Preorder the new Roadster" },
  {
    key: "reserveDescription",
    label: "Reserve section description",
    placeholder: "Deliveries from 2028",
  },
  { key: "footerText", label: "Footer text", placeholder: "Tesla © 2026 · Concept" },
] as const;

export default function ContentManagement() {
  const [content, setContent] = useState(getWebsiteContent());
  const [msg, setMsg] = useState<string | null>(null);

  function save() {
    setWebsiteContent(content);
    setMsg("Website content saved.");
    setTimeout(() => setMsg(null), 3000);
  }

  return (
    <div className="rounded-3xl border border-chrome/15 p-6">
      <h3 className="font-wide text-xl uppercase mb-4">Update website content</h3>
      <p className="text-sm text-chrome/60 mb-6">Changes apply across public pages.</p>
      <div className="space-y-4">
        {CONTENT_FIELDS.map((field) => (
          <div key={field.key} className="flex flex-col gap-2">
            <label className="text-xs uppercase tracking-widest text-chrome/50">
              {field.label}
            </label>
            <textarea
              value={content[field.key] ?? ""}
              onChange={(e) => setContent({ ...content, [field.key]: e.target.value })}
              placeholder={field.placeholder}
              rows={2}
              className="w-full rounded-lg border border-chrome/20 bg-transparent px-4 py-3 text-chrome outline-none focus:border-chrome/60"
            />
          </div>
        ))}
      </div>
      <Button
        onClick={save}
        className="h-11 rounded-full bg-chrome text-ink text-sm font-semibold uppercase hover:bg-chrome/85"
      >
        Save content
      </Button>
      {msg && <p className="mt-4 text-sm text-chrome/70">{msg}</p>}
    </div>
  );
}
