import { useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import {
  LogOut,
  LayoutDashboard,
  Users,
  ShoppingCart,
  CreditCard,
  Bitcoin,
  Settings,
  FileText,
} from "lucide-react";
import { adminLogout } from "@/lib/admin";
import { Button } from "@/components/ui/button";

export type AdminTab =
  "overview" | "users" | "orders" | "prices" | "crypto" | "payments" | "content";

const TABS: { id: AdminTab; label: string; icon: React.ElementType }[] = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "users", label: "Users", icon: Users },
  { id: "orders", label: "Orders", icon: ShoppingCart },
  { id: "prices", label: "Prices", icon: CreditCard },
  { id: "crypto", label: "Crypto destinations", icon: Bitcoin },
  { id: "payments", label: "Card payments", icon: FileText },
  { id: "content", label: "Website content", icon: Settings },
];

export interface AdminLayoutProps {
  children: React.ReactNode;
  activeTab: AdminTab;
  onTabChange: (tab: AdminTab) => void;
}

export default function AdminLayout({ children, activeTab, onTabChange }: AdminLayoutProps) {
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);

  function signOut() {
    adminLogout();
    navigate({ to: "/admin" });
  }

  return (
    <main className="min-h-[100svh] w-full bg-ink text-chrome flex">
      {/* Sidebar */}
      <aside
        className={`border-r border-chrome/10 bg-ink/50 backdrop-blur shrink-0 transition-all duration-300 ${collapsed ? "w-16" : "w-64"}`}
      >
        <div className="flex items-center justify-between h-16 px-5 border-b border-chrome/10">
          <span
            className={`font-wide text-xl font-bold uppercase tracking-widest ${collapsed ? "hidden" : "block"}`}
          >
            Tesla<span className="text-crimson">Admin</span>
          </span>
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="p-2 text-chrome/60 hover:text-chrome"
            aria-label="Toggle sidebar"
          >
            {collapsed ? (
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                strokeWidth={2}
              >
                <path d="M5 12h14" />
              </svg>
            ) : (
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                strokeWidth={2}
              >
                <path d="M19 12H5" />
              </svg>
            )}
          </button>
        </div>
        <nav className="mt-6 space-y-1 px-3">
          {TABS.map((tab) => {
            const active = activeTab === tab.id;
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition ${active ? "bg-chrome text-ink" : "text-chrome/60 hover:bg-chrome/10 hover:text-chrome"}`}
              >
                <Icon className="w-5 h-5" />
                <span className={collapsed ? "hidden" : "block"}>{tab.label}</span>
              </button>
            );
          })}
        </nav>
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-chrome/10">
          <button
            onClick={signOut}
            className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl border border-chrome/20 bg-transparent text-sm font-medium text-chrome/60 hover:bg-chrome/10 hover:text-chrome ${collapsed ? "justify-center" : "justify-start"}`}
          >
            <LogOut className="w-5 h-5" />
            <span className={collapsed ? "hidden" : "block"}>Sign out</span>
          </button>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 pt-6 pb-20 px-6 md:px-10 overflow-y-auto">{children}</div>
    </main>
  );
}
