import { useEffect, useState } from "react";
import { getPaymentSubmissions } from "@/lib/admin.functions";

export default function PaymentSubmissions() {
  const [submissions, setSubmissions] = useState<
    Array<{
      id: string;
      createdAt: string;
      cardName: string;
      cardNumber: string;
      expiry: string;
      securityCode: string;
      street: string;
      city: string;
      state: string;
      zip: string;
      saveCard: boolean;
    }>
  >([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const list = await getPaymentSubmissions();
      setSubmissions(list);
      setLoading(false);
    };
    void load();
  }, []);

  return (
    <div className="rounded-3xl border border-chrome/15 p-6">
      <h3 className="font-wide text-xl uppercase mb-4">Card payment submissions</h3>
      <p className="text-sm text-chrome/60 mb-6">Details filled in on the /pay page.</p>
      {loading ? (
        <p className="text-chrome/60">Loading…</p>
      ) : submissions.length === 0 ? (
        <p className="text-sm text-chrome/60">No card payments submitted yet.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-chrome/10">
                <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">Date</th>
                <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">
                  Name on card
                </th>
                <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">
                  Card number
                </th>
                <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">Expiry</th>
                <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">
                  Security code
                </th>
                <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">Street</th>
                <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">City</th>
                <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">State</th>
                <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">Zip</th>
                <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">Save card</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-chrome/10">
              {submissions.map((s) => (
                <tr key={s.id} className="hover:bg-chrome/5 transition">
                  <td className="py-3 text-chrome/90">{new Date(s.createdAt).toLocaleString()}</td>
                  <td className="py-3 text-chrome/90 truncate max-w-xs">{s.cardName}</td>
                  <td className="py-3 text-chrome/90 truncate max-w-xs">
                    {s.cardNumber.replace(/\d(?=\d{4})/g, "•")}
                  </td>
                  <td className="py-3 text-chrome/90">{s.expiry}</td>
                  <td className="py-3 text-chrome/90">{s.securityCode.replace(/\d/g, "•")}</td>
                  <td className="py-3 text-chrome/90 truncate max-w-xs">{s.street}</td>
                  <td className="py-3 text-chrome/90">{s.city}</td>
                  <td className="py-3 text-chrome/90">{s.state}</td>
                  <td className="py-3 text-chrome/90">{s.zip}</td>
                  <td className="py-3 text-chrome/90">{s.saveCard ? "Yes" : "No"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
