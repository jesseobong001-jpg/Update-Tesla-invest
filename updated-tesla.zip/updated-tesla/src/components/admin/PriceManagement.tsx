import { useState } from "react";
import { getPrices, setPrices } from "@/lib/admin";
import { Button } from "@/components/ui/button";

const MODELS = [
  "Model 3",
  "Model Y",
  "Model S",
  "Model X",
  "Cybertruck",
  "Cybercab",
  "Semi",
  "Roadster",
] as const;

export default function PriceManagement() {
  const [prices, setPricesState] = useState(getPrices());
  const [msg, setMsg] = useState<string | null>(null);

  function save() {
    setPrices(prices);
    setMsg("Prices saved.");
    setTimeout(() => setMsg(null), 3000);
  }

  return (
    <div className="rounded-3xl border border-chrome/15 p-6">
      <h3 className="font-wide text-xl uppercase mb-4">Adjust vehicle prices</h3>
      <p className="text-sm text-chrome/60 mb-6">Changes apply across the website.</p>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {MODELS.map((model) => (
          <div key={model} className="p-4 rounded-xl border border-chrome/10">
            <p className="text-xs uppercase tracking-widest text-chrome/50 mb-2">{model}</p>
            <input
              type="text"
              value={prices[model] ?? ""}
              onChange={(e) => setPricesState({ ...prices, [model]: e.target.value })}
              placeholder="$0.00"
              className="w-full rounded-lg border border-chrome/20 bg-transparent px-3 py-2 text-chrome outline-none focus:border-chrome/60"
            />
          </div>
        ))}
      </div>
      <div className="mt-6 flex justify-end">
        <Button
          onClick={save}
          className="h-11 rounded-full bg-chrome text-ink text-sm font-semibold uppercase hover:bg-chrome/85"
        >
          Save prices
        </Button>
      </div>
      {msg && <p className="mt-4 text-sm text-chrome/70">{msg}</p>}
    </div>
  );
}
