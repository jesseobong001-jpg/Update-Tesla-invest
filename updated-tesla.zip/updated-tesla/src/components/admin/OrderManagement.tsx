import { useEffect, useState } from "react";
import { getAdminOrders, updateOrderStatus } from "@/lib/admin.functions";

interface OrderRow {
  id: string;
  model: string;
  price: string;
  paymentMethod: string | null;
  status: string;
  userId: string;
  createdAt: string;
}

const STATUSES = ["pending", "paid", "shipped", "cancelled"] as const;

export default function OrderManagement() {
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const list = await getAdminOrders();
      setOrders(list);
      setLoading(false);
    };
    void load();
  }, []);

  async function setStatus(orderId: string, status: (typeof STATUSES)[number]) {
    await updateOrderStatus({ data: { orderId, status } });
    setOrders((prev) => prev.map((o) => (o.id === orderId ? { ...o, status } : o)));
  }

  if (loading) return <p className="text-chrome/60">Loading orders…</p>;

  return (
    <div className="rounded-3xl border border-chrome/15 p-6">
      <h3 className="font-wide text-xl uppercase mb-4">Orders & purchase status</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm border-collapse">
          <thead>
            <tr className="border-b border-chrome/10">
              <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">Order ID</th>
              <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">Model</th>
              <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">Price</th>
              <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">
                Payment method
              </th>
              <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">Status</th>
              <th className="pb-3 text-xs uppercase tracking-widest text-chrome/50">Date</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-chrome/10">
            {orders.map((o) => (
              <tr key={o.id} className="hover:bg-chrome/5 transition">
                <td className="py-3 text-chrome/90 truncate max-w-xs">{o.id}</td>
                <td className="py-3 text-chrome/90">{o.model}</td>
                <td className="py-3 text-chrome/90">{o.price}</td>
                <td className="py-3 text-chrome/90">{o.paymentMethod ?? "—"}</td>
                <td className="py-3">
                  <select
                    value={o.status}
                    onChange={(e) => setStatus(o.id, e.target.value as (typeof STATUSES)[number])}
                    className="rounded-lg border border-chrome/20 bg-transparent px-3 py-1.5 text-xs text-chrome outline-none focus:border-chrome/60"
                  >
                    {STATUSES.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </td>
                <td className="py-3 text-chrome/60 text-xs">
                  {new Date(o.createdAt).toLocaleDateString()}
                </td>
              </tr>
            ))}
            {orders.length === 0 && (
              <tr>
                <td colSpan={6} className="py-6 text-center text-chrome/50">
                  No orders found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
