import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getInvestmentRates } from "@/lib/investments.functions";
import type { AssetSymbol } from "@/lib/investments";

export const investmentRatesOptions = queryOptions({ queryKey: ["investment-rates"], queryFn: () => getInvestmentRates(), staleTime: 60_000, refetchInterval: 60_000 });

export function InvestmentRates({ selected, onSelect }: { selected: AssetSymbol; onSelect: (symbol: AssetSymbol) => void }) {
  const { data, refetch, isFetching } = useSuspenseQuery(investmentRatesOptions);
  return <section id="market" className="mt-10 scroll-mt-6 border-y border-chrome/20 py-8">
    <div className="flex items-center justify-between gap-3"><h2 className="font-wide text-xl uppercase">Market rates</h2><Button variant="ghost" size="icon" aria-label="Refresh market rates" title="Refresh market rates" disabled={isFetching} onClick={() => void refetch()}><RefreshCw className={isFetching ? "motion-safe:animate-spin" : ""} /></Button></div>
    <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{data.map((asset) => <article key={asset.symbol} className={`min-w-0 rounded-lg border p-5 ${selected === asset.symbol ? "border-chrome/60" : "border-chrome/15"}`}>
      <div className="flex justify-between gap-2"><h3 className="font-semibold">{asset.name}</h3><span className="text-xs text-chrome/50">{asset.kind}</span></div>
      <p className="mt-1 text-xs text-chrome/50">{asset.symbol} · USD</p>
      {asset.quote ? <>
        <p className="mt-4 font-wide text-2xl break-words">{asset.quote.price.toLocaleString("en-US", { style: "currency", currency: "USD" })}</p>
        <p className="mt-2 text-xs text-chrome/70">{asset.quote.changePercent === null ? "Change unavailable" : `${asset.quote.changePercent >= 0 ? "+" : ""}${asset.quote.changePercent.toFixed(2)}% vs previous close`}</p>
        <p className="mt-3 text-xs leading-relaxed text-chrome/50">Quote: {new Date(asset.quote.timestamp * 1000).toLocaleString("en-US", { timeZone: "UTC" })} UTC</p>
      </> : <p role="status" className="mt-4 text-sm text-chrome/60">{asset.error}</p>}
      <Button variant="outline" className="mt-4 w-full border-chrome/30 bg-transparent text-chrome hover:bg-chrome/10 hover:text-chrome" onClick={() => { onSelect(asset.symbol); document.getElementById("invest")?.scrollIntoView({ behavior: "smooth" }); }}>{selected === asset.symbol ? `Selected · ${asset.symbol}` : `Invest in ${asset.symbol}`}</Button>
    </article>)}</div>
    <p className="mt-5 text-xs leading-relaxed text-chrome/50">Yahoo Finance · Refreshes every 60 seconds while this page is open. Quotes may be delayed; stocks retain their latest session price when markets are closed. Not a real-time execution feed.</p>
  </section>;
}