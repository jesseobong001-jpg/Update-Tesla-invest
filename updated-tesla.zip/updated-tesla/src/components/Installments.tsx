import { useState } from "react";
import { Button } from "@/components/ui/button";
import { OrderForm } from "@/components/OrderForm";
import { MODELS, PLANS, installment, money, type CarModel, type Plan } from "@/lib/models";

export function Installments({ userId }: { userId: string }) {
  const [freq, setFreq] = useState<"week" | "month">("month");
  const [plans, setPlans] = useState<Record<string, Plan["id"]>>({});
  const [order, setOrder] = useState<{ model: CarModel; plan: Plan } | null>(null);
  const available = PLANS.filter((p) => p.unit === freq);
  return (
    <section id="installments" className="mx-auto max-w-5xl px-5 pb-16 md:px-10">
      <p className="text-xs uppercase tracking-[0.25em] text-crimson">Pay by installment</p>
      <h2 className="mt-2 font-wide text-2xl uppercase md:text-4xl">Drive now, pay over time</h2>
      <div className="mt-6 inline-flex rounded-full border border-chrome/20 p-1" role="tablist" aria-label="Plan frequency">
        {(["week", "month"] as const).map((unit) => (
          <button
            key={unit}
            role="tab"
            aria-selected={freq === unit}
            onClick={() => setFreq(unit)}
            className={`rounded-full px-6 py-2 text-xs font-semibold uppercase tracking-widest transition ${freq === unit ? "bg-chrome text-ink" : "text-chrome/60 hover:text-chrome"}`}
          >
            {unit === "week" ? "Weekly" : "Monthly"}
          </button>
        ))}
      </div>
      <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {MODELS.map((m) => {
          const stored = plans[m.name];
          const plan = available.find((p) => p.id === stored) ?? available[0];
          if (!plan) return null;
          return (
            <div key={m.name} className="overflow-hidden rounded-3xl border border-chrome/15">
              <img src={m.img} alt={`Tesla ${m.name}`} loading="lazy" className="aspect-[3/2] w-full object-cover" />
              <div className="p-5">
                <div className="flex justify-between gap-2"><p className="font-wide text-lg uppercase">{m.name}</p><p className="text-sm text-chrome/60">{m.price}</p></div>
                <label className="mt-4 block text-xs text-chrome/60">Plan
                  <select value={plan.id} onChange={(e) => setPlans({ ...plans, [m.name]: e.target.value as Plan["id"] })} className="mt-2 w-full rounded-lg border border-chrome/20 bg-ink px-3 py-2 text-sm text-chrome">
                    {available.map((p) => <option key={p.id} value={p.id}>{p.label} · {money(installment(m.price, p))}/{p.unit}</option>)}
                  </select>
                </label>
                <p className="mt-4 font-wide text-2xl">{money(installment(m.price, plan))}<span className="text-sm text-chrome/60"> / {plan.unit}</span></p>
                <Button onClick={() => setOrder({ model: m, plan })} className="mt-4 h-11 w-full rounded-full bg-chrome text-sm font-semibold uppercase text-ink hover:bg-chrome/85">Order now</Button>
              </div>
            </div>
          );
        })}
      </div>
      {order && <OrderForm model={order.model} plan={order.plan} userId={userId} onClose={() => setOrder(null)} />}
    </section>
  );
}
