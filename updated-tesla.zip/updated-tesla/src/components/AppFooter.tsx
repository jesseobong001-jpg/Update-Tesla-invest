import { useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import teslaWordmark from "@/assets/tesla_wordmark.png";

export function AppFooter() {
  const navigate = useNavigate();

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/", replace: true });
  }

  return (
    <footer className="border-t border-chrome/10 px-5 py-10 md:px-10">
      <div className="mx-auto flex max-w-5xl flex-col items-center gap-6 sm:flex-row sm:justify-between">
        <img src={teslaWordmark} alt="Tesla" className="w-28" />
        <button
          onClick={signOut}
          className="font-wide w-full rounded-full border border-chrome/40 px-10 py-3 text-center text-sm font-bold uppercase tracking-[0.18em] text-chrome hover:bg-chrome/10 sm:w-auto"
        >
          Sign out
        </button>
      </div>
      <p className="mx-auto mt-8 max-w-5xl text-xs text-chrome/40">Tesla © 2026 · Concept</p>
    </footer>
  );
}
