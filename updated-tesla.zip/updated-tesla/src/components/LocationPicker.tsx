import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getCountries, getStates } from "@/lib/locations.functions";

export function LocationPicker({ className, country, city, onChange }: { className: string; country: string; city: string; onChange: (v: { country: string; city: string }) => void }) {
  const [code, setCode] = useState("");
  const countries = useQuery({ queryKey: ["countries"], queryFn: () => getCountries(), staleTime: Infinity });
  const states = useQuery({ queryKey: ["states", code], queryFn: () => getStates({ data: { country: code } }), enabled: Boolean(code), staleTime: Infinity });
  return <>
    <select required aria-label="Country" className={className} value={code} onChange={(e) => { const c = countries.data?.find((i) => i.code === e.target.value); setCode(e.target.value); onChange({ country: c?.name ?? "", city: "" }); }}>
      <option value="">{countries.isPending ? "Loading countries…" : "Select country"}</option>
      {countries.data?.map((c) => <option key={c.code} value={c.code}>{c.name}</option>)}
    </select>
    <select required aria-label="State" className={className} disabled={!code || states.isPending || !states.data?.length} value={city} onChange={(e) => onChange({ country, city: e.target.value })}>
      <option value="">{!code ? "Select country first" : states.isPending ? "Loading states…" : states.data?.length ? "Select state" : "No states listed"}</option>
      {city && !(states.data ?? []).includes(city) && <option value={city}>{city}</option>}
      {(states.data ?? []).map((s) => <option key={s} value={s}>{s}</option>)}
    </select>
  </>;
}
