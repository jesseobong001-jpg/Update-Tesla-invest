import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { AppNav } from "@/components/AppNav";
import { PaymentMethods } from "@/components/PaymentMethods";
import { DEPOSIT_METHODS, type DepositMethod } from "@/lib/payment-methods";
import { supabase } from "@/integrations/supabase/client";
import { submitDeposit } from "@/lib/deposits.functions";

export const Route = createFileRoute("/_authenticated/confirm-payment")({
  validateSearch: (s: Record<string, unknown>) => ({ amount: typeof s["amount"] === "number" && Number.isFinite(s["amount"]) ? s["amount"] : 0, method: typeof s["method"] === "string" ? s["method"] : "" }),
  head: () => ({ meta: [{ title: "Confirm payment — Tesla investments" }, { name: "description", content: "Submit a private payment screenshot for review of your Tesla investment deposit." }, { property: "og:title", content: "Confirm payment — Tesla investments" }, { property: "og:description", content: "Submit your deposit payment screenshot for review." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: ConfirmPayment,
});

function ConfirmPayment() {
  const { user } = Route.useRouteContext();
  const search = Route.useSearch();
  const [amount, setAmount] = useState(search.amount > 0 ? String(search.amount) : "");
  const [method, setMethod] = useState<DepositMethod | null>(DEPOSIT_METHODS.find((m) => m.label === search.method) ?? null);
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const submit = useServerFn(submitDeposit);
  async function confirm(e: React.FormEvent) {
    e.preventDefault();
    if (!file || !method || !Number.isFinite(Number(amount)) || Number(amount) <= 0 || Number(amount) > 10_000_000) { setMessage("Select a method, amount, and payment screenshot."); return; }
    if (file.size > 5 * 1024 * 1024 || !["image/png", "image/jpeg", "image/webp"].includes(file.type)) { setMessage("Choose a PNG, JPG, or WebP image under 5 MB."); return; }
    setBusy(true); setMessage("Uploading screenshot, then reviewing with AI…");
    try {
      const ext = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : "jpg";
      const path = `${user.id}/${crypto.randomUUID()}.${ext}`;
      const { error } = await supabase.storage.from("payment-proofs").upload(path, file, { contentType: file.type, upsert: false });
      if (error) throw new Error("Couldn't upload the screenshot. Please try again.");
      const result = await submit({ data: { amount: Number(amount), method: method.label, path } });
      setSubmitted(true); setMessage(result.message);
    } catch (err) { setMessage(err instanceof Error ? err.message : "Couldn't submit your payment."); }
    finally { setBusy(false); }
  }
  return <main className="min-h-[100svh] bg-ink text-chrome">
    <AppNav />
    <div className="mx-auto max-w-lg px-5 pb-16">
    <h1 className="mt-2 font-wide text-3xl uppercase">Confirm payment</h1>
    <p className="mt-4 text-sm leading-relaxed text-chrome/60">AI checks the screenshot's visible details. Your balance stays unchanged until receipt of funds is independently verified.</p>
    <form onSubmit={confirm} className="mt-8 space-y-5">
      <fieldset disabled={busy || submitted} className="space-y-5">
        <label className="block space-y-2 text-sm"><span>Amount in USD</span><input required type="number" min="0.01" max="10000000" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} className="w-full rounded-lg border border-chrome/20 bg-ink px-4 py-3" /></label>
        <PaymentMethods value={method} onChange={setMethod} />
        <label className="block space-y-2 text-sm"><span>Payment screenshot</span><input required type="file" accept="image/png,image/jpeg,image/webp" onChange={(e) => setFile(e.target.files?.[0] ?? null)} className="block w-full min-w-0 rounded-lg border border-chrome/20 p-3 text-xs" /></label>
        <p className="text-xs text-chrome/50">PNG, JPG, WebP · Up to 5 MB · Stored privately. The screenshot is sent to AI for review.</p>
      </fieldset>
      {!submitted && <Button className="h-12 w-full bg-chrome text-ink hover:bg-chrome/85" type="submit" disabled={busy}>{busy ? "Reviewing…" : "Submit for review"}</Button>}
      {message && <p role="status" className="text-sm leading-relaxed text-chrome/80">{message}</p>}
    </form>
  </div></main>;
}