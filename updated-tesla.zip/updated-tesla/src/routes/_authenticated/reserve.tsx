import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import heroFrame from "@/assets/hero_frame.jpg";
import { AppNav } from "@/components/AppNav";
import { AppFooter } from "@/components/AppFooter";
import { OrderForm } from "@/components/OrderForm";
import { LocationPicker } from "@/components/LocationPicker";

export const Route = createFileRoute("/_authenticated/reserve")({
  head: () => ({
    meta: [
      { title: "Reserve your Roadster — Tesla" },
      { name: "description", content: "Reserve your Tesla Roadster flying car." },
      { property: "og:title", content: "Reserve your Roadster — Tesla" },
      { property: "og:description", content: "Place your Tesla Roadster reservation." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Reserve,
});

type Res = { id: string; full_name: string; country: string; created_at: string };

import { MODELS } from "@/lib/models";

function Reserve() {
  const { user } = Route.useRouteContext();
  const [mine, setMine] = useState<Res[]>([]);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [country, setCountry] = useState("");
  const [city, setCity] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [order, setOrder] = useState<(typeof MODELS)[number] | null>(null);

  const load = () => supabase.from("reservations").select("id,full_name,country,created_at").order("created_at", { ascending: false }).then(({ data }) => setMine(data ?? []));
  useEffect(() => { load(); }, []);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!country || !city) return setMsg("Select your country and state.");
    const { error } = await supabase.from("reservations").insert({ full_name: name, phone: phone || null, country: `${city}, ${country}`, user_id: user.id });
    if (error) return setMsg(error.message);
    setMsg("Reservation confirmed. Welcome to the sky.");
    setName(""); setPhone(""); setCountry(""); setCity("");
    load();
  }

  const input = "w-full rounded-full border border-chrome/20 bg-transparent px-5 py-3 text-chrome placeholder:text-chrome/40 outline-none focus:border-chrome/60";
  return (
    <main className="min-h-[100svh] bg-ink text-chrome">
      <AppNav />
      <div className="mx-auto grid max-w-5xl gap-10 px-5 pb-20 md:grid-cols-2 md:px-10">
        <img src={heroFrame} alt="Tesla Roadster" className="aspect-[4/5] w-full rounded-3xl object-cover" />
        <div>
          <h1 className="font-wide text-4xl uppercase md:text-6xl">Preorder the new Roadster</h1>
          <p className="mt-3 text-sm text-chrome/60">Signed in as {user.email}</p>
          <form onSubmit={submit} className="mt-8 space-y-3">
            <input className={input} required placeholder="Full name" value={name} onChange={(e) => setName(e.target.value)} />
            <input className={input} placeholder="Phone (optional)" value={phone} onChange={(e) => setPhone(e.target.value)} />
            <LocationPicker className={`${input} bg-ink`} country={country} city={city} onChange={(v) => { setCountry(v.country); setCity(v.city); }} />
            <button className="w-full rounded-full bg-chrome py-3 text-sm font-semibold uppercase tracking-widest text-ink hover:bg-chrome/85">Confirm preorder</button>
          </form>
          {msg && <p className="mt-4 text-sm text-crimson">{msg}</p>}
          {mine.length > 0 && (
            <div className="mt-10">
              <p className="text-xs uppercase tracking-[0.25em] text-chrome/50">Your reservations</p>
              <ul className="mt-3 divide-y divide-chrome/10">
                {mine.map((r) => (
                  <li key={r.id} className="flex justify-between py-3 text-sm">
                    <span>{r.full_name} · {r.country}</span>
                    <span className="text-chrome/50">{new Date(r.created_at).toLocaleDateString()}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      <section className="mx-auto max-w-5xl px-5 pb-20 md:px-10">
        <p className="text-xs uppercase tracking-[0.25em] text-chrome/50">Lineup</p>
        <h2 className="mt-2 font-wide text-3xl uppercase md:text-5xl">Tesla models</h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {MODELS.map((m) => (
            <div key={m.name} className="overflow-hidden rounded-3xl border border-chrome/15">
              <img src={m.img} alt={`Tesla ${m.name}`} loading="lazy" width={1024} height={680} className="aspect-[3/2] w-full object-cover" />
              <div className="p-6">
              <p className="font-wide text-xl uppercase">{m.name}</p>
              <p className="mt-1 text-sm text-chrome/60">{m.tag}</p>
              <p className="mt-6 text-xs uppercase tracking-widest text-chrome/50">From</p>
              <p className="font-wide text-2xl">{m.price}</p>
              <p className="mt-3 text-xs text-chrome/60">{m.spec}</p>
              <button type="button" onClick={() => setOrder(m)} className="mt-5 w-full rounded-full bg-chrome py-2.5 text-xs font-semibold uppercase tracking-widest text-ink hover:bg-chrome/85">Order now</button>
              </div>
            </div>
          ))}
        </div>
        <p className="mt-3 text-xs text-chrome/40">Starting prices in USD, before incentives. Subject to change.</p>
      </section>

      <section className="mx-auto max-w-5xl px-5 pb-24 md:px-10">
        <div className="rounded-3xl border border-crimson/40 p-8">
          <p className="text-xs uppercase tracking-[0.25em] text-crimson">Investment</p>
          <h2 className="mt-2 font-wide text-3xl uppercase md:text-5xl">Own a piece of Tesla</h2>
          <div className="mt-6 grid grid-cols-2 gap-4 text-sm md:grid-cols-4">
            {[["Ticker", "TSLA"], ["Exchange", "Nasdaq"], ["Public since", "2010"], ["Currency", "USD"]].map(([k, v]) => (
              <div key={k}><p className="text-xs uppercase tracking-widest text-chrome/50">{k}</p><p className="mt-1 font-wide text-lg">{v}</p></div>
            ))}
          </div>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/stocks" className="rounded-full bg-chrome px-6 py-3 text-xs font-semibold uppercase tracking-widest text-ink">Invest in stocks</Link>
          </div>
        </div>
      </section>
    {order && <OrderForm model={order} userId={user.id} onClose={() => setOrder(null)} />}
    <AppFooter />
    </main>
  );
}
