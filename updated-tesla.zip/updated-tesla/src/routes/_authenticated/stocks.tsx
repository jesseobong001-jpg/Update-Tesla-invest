import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AppNav } from "@/components/AppNav";
import { AppFooter } from "@/components/AppFooter";
import { PaymentMethods } from "@/components/PaymentMethods";
import type { DepositMethod } from "@/lib/payment-methods";
import { MarketInfo, marketQueryOptions } from "@/components/MarketInfo";
import { Button } from "@/components/ui/button";
import { InvestmentRates, investmentRatesOptions } from "@/components/InvestmentRates";
import { ASSETS, type AssetSymbol } from "@/lib/investments";
import { allocateInvestment } from "@/lib/investments.functions";
import { useServerFn } from "@tanstack/react-start";

export const Route = createFileRoute("/_authenticated/stocks")({
  head: () => ({
    meta: [
      { title: "Tesla Investments — Stocks & Crypto Market Rates" },
      { name: "description", content: "Manage investment allocations and view current Tesla, Apple, NVIDIA, Bitcoin, Ethereum and Solana market rates." },
      { property: "og:title", content: "Tesla Investments — Stocks & Crypto Market Rates" },
      { property: "og:description", content: "Your wallet, investment allocations and automatically refreshed stock and cryptocurrency rates." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: async ({ context }) => { await Promise.all([context.queryClient.ensureQueryData(marketQueryOptions), context.queryClient.ensureQueryData(investmentRatesOptions)]); },
  component: Stocks,
});

const FACTS = [
  ["Ticker", "TSLA"], ["Exchange", "Nasdaq"], ["Public since", "June 2010"], ["Currency", "USD"],
  ["IPO price", "$17 / share"], ["Stock splits", "5-for-1 (2020), 3-for-1 (2022)"], ["Sector", "Automotive & Energy"], ["Index", "S&P 500, Nasdaq-100"],
];

const WHY = [
  ["Vehicles", "Model 3, Y, S, X, Cybertruck and the new Roadster."],
  ["Energy", "Powerwall and Megapack storage for homes and grids."],
  ["Autonomy", "Self-driving software and the robotaxi network."],
  ["Robotics", "Optimus humanoid robot for everyday work."],
];

function Stocks() {
  const [selected, setSelected] = useState<AssetSymbol>("TSLA");
  return (
    <main className="min-h-[100svh] bg-ink text-chrome">
      <AppNav />
      <section className="mx-auto max-w-5xl px-5 pb-16 md:px-10">
        <Wallet selected={selected} onSelect={setSelected} />
        <p className="mt-10 text-xs uppercase tracking-[0.25em] text-crimson">Investment</p>
        <h1 className="mt-2 font-wide text-4xl uppercase md:text-6xl">Stocks & crypto</h1>
        <InvestmentRates selected={selected} onSelect={setSelected} />
        <p className="mt-10 max-w-xl text-sm text-chrome/60">Tesla, Inc. trades on the Nasdaq under the ticker TSLA.</p>
        <MarketInfo />
        <div className="mt-10 grid grid-cols-2 gap-6 md:grid-cols-4">
          {FACTS.map(([k, v]) => (
            <div key={k} className="rounded-2xl border border-chrome/15 p-5">
              <p className="text-xs uppercase tracking-widest text-chrome/50">{k}</p>
              <p className="mt-2 font-wide text-base">{v}</p>
            </div>
          ))}
        </div>
      </section>
      <section className="mx-auto max-w-5xl px-5 pb-24 md:px-10">
        <h2 className="font-wide text-2xl uppercase md:text-4xl">What you're investing in</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          {WHY.map(([t, d]) => (
            <div key={t} className="rounded-3xl border border-chrome/15 p-6">
              <p className="font-wide text-lg uppercase">{t}</p>
              <p className="mt-2 text-sm text-chrome/60">{d}</p>
            </div>
          ))}
        </div>
        <div className="mt-10 flex flex-col gap-3 sm:flex-row">
          <a href="#invest" onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: "smooth" }); }} className="rounded-full bg-chrome px-8 py-3 text-center text-sm font-semibold uppercase tracking-widest text-ink hover:bg-chrome/85">Invest</a>
          <a href="#market" onClick={(e) => { e.preventDefault(); document.getElementById("market")?.scrollIntoView({ behavior: "smooth" }); }} className="rounded-full border border-chrome/40 px-8 py-3 text-center text-sm font-semibold uppercase tracking-widest hover:bg-chrome/10">View market</a>
        </div>
        <p className="mt-8 text-xs text-chrome/40">For information only, not financial advice.</p>
      </section>
      <AppFooter />
    </main>
  );
}

const usd = (n: number) => n.toLocaleString("en-US", { style: "currency", currency: "USD" });

function Wallet({ selected, onSelect }: { selected: AssetSymbol; onSelect: (symbol: AssetSymbol) => void }) {
  const { user } = Route.useRouteContext();
  const navigate = useNavigate();
  const [balance, setBalance] = useState(0);
  const [invested, setInvested] = useState(0);
  const [amount, setAmount] = useState("");
  const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [depositOpen, setDepositOpen] = useState(false);
  const [method, setMethod] = useState<DepositMethod | null>(null);
  const [dAmount, setDAmount] = useState("");
  const [dMsg, setDMsg] = useState<string | null>(null);
  const [allocations, setAllocations] = useState<{ symbol: string; amount: number }[]>([]);
  const allocate = useServerFn(allocateInvestment);

  async function loadWallet() {
    const [{ data, error }, positions] = await Promise.all([
      supabase.from("wallets").select("balance,invested").eq("user_id", user.id).maybeSingle(),
      supabase.from("investment_allocations").select("symbol,amount").eq("user_id", user.id),
    ]);
    if (error || positions.error) { setMsg({ ok: false, t: "Your wallet could not be loaded. Please refresh." }); return; }
    if (data) { setBalance(Number(data.balance)); setInvested(Number(data.invested)); }
    setAllocations((positions.data ?? []).map((p) => ({ symbol: p.symbol, amount: Number(p.amount) })));
  }

  useEffect(() => {
    void loadWallet();
  }, [user.id]);

  async function invest() {
    const a = Math.round(Number(amount) * 100) / 100;
    if (!a || a <= 0 || a > 10_000_000) return setMsg({ ok: false, t: "Enter an amount above $0." });
    if (a > balance) return setMsg({ ok: false, t: "Not enough balance. Deposit first." });
    setBusy(true);
    try {
      await allocate({ data: { symbol: selected, amount: a } });
      await loadWallet();
      setAmount("");
      setMsg({ ok: true, t: `Allocated ${usd(a)} to ${selected}.` });
    } catch (error) {
      setMsg({ ok: false, t: error instanceof Error ? error.message : "Investment could not be saved." });
    } finally { setBusy(false); }
  }

  async function deposit() {
    if (!method) return;
    const a = Math.round(Number(dAmount) * 100) / 100;
    if (!a || a <= 0 || a > 10_000_000) return setDMsg("Enter an amount above $0.");
    if (method.group === "Card") { setDepositOpen(false); navigate({ to: "/pay" }); return; }
    setDepositOpen(false);
    navigate({ to: "/confirm-payment", search: { amount: a, method: method.label } });
  }

  return (
    <div id="invest" className="scroll-mt-6 border-b border-chrome/15 pb-8">
      <p className="text-xs uppercase tracking-widest text-chrome/50">Balance</p>
      <p className={`mt-1 break-words font-wide leading-none md:text-8xl ${usd(balance).length > 10 ? "text-3xl" : "text-6xl"}`}>{usd(balance)}</p>
      <div className="mt-4 flex items-center gap-2">
        <p className="text-xs uppercase tracking-widest text-chrome/50">Total allocated</p>
        <p className="font-wide text-lg md:text-xl">{usd(invested)}</p>
      </div>
      {allocations.length > 0 && <div className="mt-5 divide-y divide-chrome/10">{allocations.map((p) => <div key={p.symbol} className="flex justify-between gap-3 py-2 text-sm"><span>{p.symbol}</span><span>{usd(p.amount)}</span></div>)}</div>}
      <label htmlFor="investment-asset" className="mt-6 block text-xs text-chrome/60">Investment</label>
      <select id="investment-asset" value={selected} onChange={(e) => onSelect(e.target.value as AssetSymbol)} className="mt-2 w-full rounded-lg border border-chrome/20 bg-ink px-4 py-3 text-sm">{ASSETS.map((asset) => <option key={asset.symbol} value={asset.symbol}>{asset.name} ({asset.symbol})</option>)}</select>
      <input aria-label="Investment amount in USD" type="number" inputMode="decimal" min="0" step="0.01" placeholder="Amount in USD" value={amount} onChange={(e) => setAmount(e.target.value)}
        className="mt-6 w-full rounded-xl border border-chrome/20 bg-transparent px-4 py-3 text-sm outline-none focus:border-chrome/60" />
      <div className="mt-3 grid grid-cols-2 gap-3">
        <Button disabled={busy} onClick={() => { setDepositOpen(true); setMethod(null); setDMsg(null); }} className="h-12 rounded-full bg-chrome text-sm font-semibold uppercase text-ink hover:bg-chrome/85">Deposit</Button>
        <Button variant="outline" disabled={busy} onClick={invest} className="h-12 rounded-full border-chrome/40 bg-transparent text-sm font-semibold text-chrome hover:bg-chrome/10 hover:text-chrome">{busy ? "Saving…" : `Invest · ${selected}`}</Button>
      </div>
      <p className="mt-4 text-xs leading-relaxed text-chrome/50">Allocations are recorded on this site only. No brokerage or exchange is connected; investing here does not purchase real shares or crypto.</p>
      {msg && <p className={`mt-3 text-xs ${msg.ok ? "text-chrome/70" : "text-crimson"}`}>{msg.t}</p>}

      {depositOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/80 p-4 backdrop-blur sm:items-center" onClick={() => setDepositOpen(false)}>
          <div className="max-h-[90svh] w-full max-w-md overflow-y-auto rounded-3xl border border-chrome/15 bg-ink p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between">
              <h3 className="font-wide text-2xl uppercase">Deposit</h3>
              <button aria-label="Close" onClick={() => { setDepositOpen(false); setMethod(null); setDMsg(null); }} className="text-2xl text-chrome/60 hover:text-chrome">×</button>
            </div>
            <div className="mt-4"><PaymentMethods value={method} onChange={(value) => { setMethod(value); setDMsg(null); if (value?.group === "Card") { setDepositOpen(false); navigate({ to: "/pay" }); } }} /></div>
            {method && <>
              <input aria-label="Deposit amount in USD" type="number" inputMode="decimal" min="0" step="0.01" placeholder="Amount in USD" value={dAmount} onChange={(e) => setDAmount(e.target.value)} className="mt-3 w-full rounded-xl border border-chrome/20 bg-transparent px-4 py-3 text-sm outline-none focus:border-chrome/60" />
              {dMsg && <p className="mt-3 text-xs text-crimson">{dMsg}</p>}
              <Button type="button" onClick={deposit} className="mt-4 h-12 w-full rounded-full bg-chrome text-sm font-semibold text-ink hover:bg-chrome/85">{method.group === "Card" ? `Pay ${usd(Number(dAmount) || 0)}` : "I've made the deposit"}</Button>
            </>}
          </div>
        </div>
      )}
    </div>
  );
}
