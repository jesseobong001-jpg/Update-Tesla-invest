import { createFileRoute } from "@tanstack/react-router";
import { AppNav } from "@/components/AppNav";
import { AppFooter } from "@/components/AppFooter";
import { Installments } from "@/components/Installments";

export const Route = createFileRoute("/_authenticated/payment-plans")({
  head: () => ({
    meta: [
      { title: "Payment plans — Tesla vehicles" },
      {
        name: "description",
        content: "Choose a weekly or monthly payment plan for every Tesla model.",
      },
      { property: "og:title", content: "Payment plans — Tesla vehicles" },
      {
        property: "og:description",
        content: "Pay for your Tesla weekly or monthly with flexible plans.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PaymentPlans,
});

function PaymentPlans() {
  const { user } = Route.useRouteContext();
  return (
    <main className="min-h-[100svh] bg-ink text-chrome">
      <AppNav />
      <div className="pt-4">
        <Installments userId={user.id} />
      </div>
      <AppFooter />
    </main>
  );
}
