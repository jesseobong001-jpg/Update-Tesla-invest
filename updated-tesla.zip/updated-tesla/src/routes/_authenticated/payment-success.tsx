import { createFileRoute, Link } from "@tanstack/react-router";
import model3 from "@/assets/model_3.png";

export const Route = createFileRoute("/_authenticated/payment-success")({
  head: () => ({
    meta: [
      { title: "Order confirmed — Tesla investments" },
      {
        name: "description",
        content: "Your Tesla order is on the way and a confirmation email has been sent.",
      },
      { property: "og:title", content: "Order confirmed — Tesla investments" },
      {
        property: "og:description",
        content: "Your order is on the way. Check your email for confirmation.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PaymentSuccess,
});

function PaymentSuccess() {
  return (
    <main className="min-h-[100svh] w-full bg-white text-gray-900 font-sans flex flex-col items-center justify-center px-6">
      <div className="mx-auto max-w-md text-center px-6 py-12">
        <img
          src={model3}
          alt="Tesla Model 3"
          className="mx-auto mb-8 max-w-[260px] h-auto rounded-xl shadow-lg"
        />
        <h1 className="font-wide text-3xl uppercase md:text-5xl mb-4">Order confirmed</h1>
        <p className="text-lg text-gray-600 mb-2">Your order is on the way.</p>
        <p className="text-lg text-gray-600 mb-8">A confirmation email has been sent to you.</p>
        <Link
          to="/"
          className="rounded-full bg-chrome px-10 py-3 text-center text-sm font-semibold uppercase tracking-widest text-ink transition hover:bg-chrome/85"
        >
          Back to home
        </Link>
      </div>
    </main>
  );
}
