import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import teslaLogo from "@/assets/tesla_logo.png";
import teslaWordmark from "@/assets/tesla_wordmark.png";
import heroFrame from "@/assets/hero_frame.jpg";
import { Button } from "@/components/ui/button";
import { AppNav } from "@/components/AppNav";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Tesla Roadster — Models and Investments" },
      {
        name: "description",
        content:
          "Tesla Roadster: preorder the new Roadster and follow TSLA stock, all in one place.",
      },
      { property: "og:title", content: "Tesla Roadster — Models and Investments" },
      {
        property: "og:description",
        content: "Preorder the new Tesla Roadster or invest in TSLA from one place.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function OutroWordmark() {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver((entries) => setShown(!!entries[0]?.isIntersecting), {
      threshold: 0.6,
    });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} className="flex items-center justify-center px-8 py-12">
      <img
        src={teslaWordmark}
        alt="Tesla"
        className={`wordmark-reveal w-full max-w-[9rem] ${shown ? "is-shown" : ""}`}
      />
    </div>
  );
}

function Index() {
  const [session, setSession] = useState<boolean>(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(Boolean(data.session)));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(Boolean(s)));
    return () => sub.subscription.unsubscribe();
  }, []);

  return (
    <main className="bg-ink text-chrome">
      {/* HERO */}
      <section className="relative flex h-[100svh] w-full flex-col overflow-hidden">
        <img
          src={heroFrame}
          alt="Tesla Roadster"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 hero-veil" />
        {session && (
          <div className="relative z-20">
            <AppNav borderless />
          </div>
        )}
        <div className="relative z-10 flex flex-1 flex-col items-center justify-center px-6">
          <h1 className="sr-only">Tesla Roadster</h1>
          <img src={teslaLogo} alt="Tesla" className="logo-intro w-28 md:w-40" />
          <div className="absolute inset-x-0 bottom-10 flex flex-col items-center gap-3 px-6 sm:flex-row sm:justify-center">
            {!session && (
              <>
                <Link
                  to="/auth"
                  search={{ redirect: undefined }}
                  className="w-full max-w-xs rounded-full bg-chrome px-10 py-3 text-center text-sm font-semibold uppercase tracking-widest text-ink transition hover:bg-chrome/85 sm:w-auto"
                >
                  Sign in
                </Link>
                <Link
                  to="/auth"
                  search={{ redirect: undefined }}
                  className="w-full max-w-xs rounded-full border border-chrome/40 px-10 py-3 text-center text-sm font-semibold uppercase tracking-widest text-chrome transition hover:bg-chrome/10 sm:w-auto"
                >
                  Log in
                </Link>
              </>
            )}
            {session && (
              <Link
                to="/payment-plans"
                className="w-full max-w-xs rounded-full bg-chrome px-10 py-3 text-center text-sm font-semibold uppercase tracking-widest text-ink transition hover:bg-chrome/85 sm:w-auto"
              >
                Payment plans
              </Link>
            )}
          </div>
        </div>
      </section>

      <OutroWordmark />

      {/* STOCKS */}
      <section id="stocks" className="border-t border-chrome/10 px-5 py-20 md:px-10">
        <p className="text-xs uppercase tracking-[0.3em] text-crimson">Investors</p>
        <h2 className="font-wide mt-4 text-4xl uppercase md:text-7xl">Invest in Tesla</h2>
        <p className="mt-4 max-w-xl text-chrome/70">
          Own a piece of the company building electric cars, energy storage and autonomous vehicles.
          Tesla shares trade publicly on the Nasdaq.
        </p>
        <div className="mt-12 grid grid-cols-2 gap-y-10 md:grid-cols-4">
          {[
            ["TSLA", "Ticker"],
            ["Nasdaq", "Exchange"],
            ["2010", "Public since"],
            ["USD", "Currency"],
          ].map(([v, l]) => (
            <div key={l}>
              <p className="font-wide text-3xl md:text-5xl">{v}</p>
              <p className="mt-2 text-xs uppercase tracking-[0.25em] text-chrome/60">{l}</p>
            </div>
          ))}
        </div>
        <div className="mt-12 flex flex-col gap-3 sm:flex-row">
          <Link
            to="/stocks"
            className="rounded-full bg-chrome px-10 py-3 text-center text-sm font-semibold uppercase tracking-widest text-ink transition hover:bg-chrome/85"
          >
            Invest in stocks
          </Link>
        </div>
      </section>

      {/* RESERVE */}
      <section className="relative overflow-hidden">
        <img src={heroFrame} alt="" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-ink/60" />
        <div className="relative flex min-h-[60svh] flex-col items-center justify-center px-6 text-center">
          <p className="text-xs uppercase tracking-[0.3em] text-chrome/70">Deliveries from 2028</p>
          <h2 className="font-wide mt-4 text-5xl uppercase md:text-8xl">
            Preorder the new Roadster
          </h2>
          <div className="mt-10 flex flex-col gap-3 sm:flex-row">
            <Link
              to="/reserve"
              className="rounded-full bg-chrome px-10 py-3 text-sm font-semibold uppercase tracking-widest text-ink transition hover:bg-chrome/85"
            >
              Preorder Roadster
            </Link>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-chrome/10 px-5 py-12 md:px-10">
        <div className="flex flex-col items-center gap-8 md:flex-row md:justify-between">
          <img src={teslaWordmark} alt="Tesla" className="w-32" />
          <nav className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-xs uppercase tracking-widest text-chrome/60">
            {["Models", "Energy", "Charging", "Careers", "Privacy", "Contact"].map((l) => (
              <Button
                key={l}
                asChild
                variant="link"
                className="h-auto p-0 text-xs uppercase tracking-widest text-chrome/60 hover:text-chrome"
              >
                <Link to="/reserve">{l}</Link>
              </Button>
            ))}
          </nav>
          <p className="text-xs text-chrome/40">Tesla © 2026 · Concept</p>
        </div>
      </footer>
    </main>
  );
}
