import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { PasswordInput } from "@/components/PasswordInput";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import teslaWordmark from "@/assets/tesla_wordmark.png";

const safe = (r?: string) => (r && r.startsWith("/") && !r.startsWith("//") ? r : "/reserve");

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>) => ({ redirect: typeof s["redirect"] === "string" ? s["redirect"] : undefined }),
  head: () => ({
    meta: [
      { title: "Sign in — Tesla Roadster" },
      { name: "description", content: "Sign in or create an account to reserve your Tesla Roadster." },
      { property: "og:title", content: "Sign in — Tesla Roadster" },
      { property: "og:description", content: "Sign in to reserve your Tesla Roadster flying car." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { redirect } = Route.useSearch();
  const to = safe(redirect);
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { if (data.session) navigate({ to, replace: true }); });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => { if (s) navigate({ to, replace: true }); });
    return () => sub.subscription.unsubscribe();
  }, [navigate, to]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setMsg(null);
    if (mode === "in") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) setMsg(error.message);
    } else {
      const { data, error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin + to } });
      if (error) setMsg(error.message);
      else if (!data.session) setMsg("Check your email to confirm your account, then sign in.");
    }
    setBusy(false);
  }


  async function forgot() {
    if (!email) { setMsg("Enter your email first, then tap Forgot password."); return; }
    setBusy(true); setMsg(null);
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: window.location.origin + "/reset-password",
    });
    setBusy(false);
    setMsg(error ? error.message : "Check your email for a link to choose a new password.");
  }

  const input = "w-full rounded-full border border-chrome/20 bg-transparent px-5 py-3 text-chrome placeholder:text-chrome/40 outline-none focus:border-chrome/60";

  return (
    <main className="flex min-h-[100svh] flex-col items-center justify-center bg-ink px-6 text-chrome">
      <Link to="/"><img src={teslaWordmark} alt="Tesla" className="mb-10 w-36" /></Link>
      <div className="w-full max-w-sm">
        <h1 className="font-wide text-center text-3xl uppercase">{mode === "in" ? "Sign in" : "Create account"}</h1>
        <p className="mt-2 text-center text-sm text-chrome/60">You need an account to reserve your Roadster.</p>
        <form onSubmit={submit} className="space-y-3">
          <input className={input} type="email" required placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <PasswordInput className={input} required minLength={6} placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <button disabled={busy} className="w-full rounded-full border border-chrome/60 py-3 text-sm font-semibold uppercase tracking-widest hover:bg-chrome/10 disabled:opacity-50">
            {busy ? "…" : mode === "in" ? "Sign in" : "Sign up"}
          </button>
        </form>
        {mode === "in" && (
          <button type="button" onClick={forgot} className="mt-4 w-full text-center text-sm text-chrome/60 hover:text-chrome">Forgot password?</button>
        )}
        {msg && <p className="mt-4 text-center text-sm text-crimson">{msg}</p>}

        <button type="button" onClick={() => setMode(mode === "in" ? "up" : "in")} className="mt-6 w-full text-center text-sm text-chrome/60 hover:text-chrome">
          {mode === "in" ? "New here? Create an account" : "Have an account? Sign in"}
        </button>
      </div>
    </main>
  );
}
