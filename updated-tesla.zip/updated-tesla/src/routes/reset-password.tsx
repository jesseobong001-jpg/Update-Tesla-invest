import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { PasswordInput } from "@/components/PasswordInput";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import teslaWordmark from "@/assets/tesla_wordmark.png";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Choose a new password — Tesla Roadster" },
      { name: "description", content: "Set a new password for your Tesla Roadster account." },
      { property: "og:title", content: "Choose a new password — Tesla Roadster" },
      { property: "og:description", content: "Set a new password for your Tesla Roadster account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);
  const [checking, setChecking] = useState(true);
  const [msg, setMsg] = useState<string | null>(null);
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    async function init() {
      const url = new URL(window.location.href);
      const code = url.searchParams.get("code");
      const hash = new URLSearchParams(url.hash.replace(/^#/, ""));
      const type = url.searchParams.get("type") ?? hash.get("type");

      if (code) {
        const { error } = await supabase.auth.exchangeCodeForSession(code);
        const { data } = await supabase.auth.getSession();
        if (data.session) {
          setReady(true);
        } else {
          setMsg(error?.message ?? "This reset link has expired. Request a new one.");
        }
        url.searchParams.delete("code");
        url.searchParams.delete("type");
        window.history.replaceState({}, "", url.pathname + url.search);
        setChecking(false);
        return;
      }

      const { data } = await supabase.auth.getSession();
      if (data.session && type === "recovery") setReady(true);
      else if (data.session) navigate({ to: "/reserve", replace: true });
      else setMsg("This reset link has expired. Request a new one.");
      setChecking(false);
    }
    init();
  }, [navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (pw.length < 6) return setMsg("Use at least 6 characters.");
    if (pw !== pw2) return setMsg("The two passwords don't match.");
    setBusy(true);
    setMsg(null);
    const { error } = await supabase.auth.updateUser({ password: pw });
    setBusy(false);
    if (error) return setMsg(error.message);
    navigate({ to: "/reserve", replace: true });
  }

  const input = "w-full rounded-full border border-chrome/20 bg-transparent px-5 py-3 text-chrome placeholder:text-chrome/40 outline-none focus:border-chrome/60";

  return (
    <main className="flex min-h-[100svh] flex-col items-center justify-center bg-ink px-6 text-chrome">
      <Link to="/"><img src={teslaWordmark} alt="Tesla" className="mb-10 w-36" /></Link>
      <div className="w-full max-w-sm">
        <h1 className="font-wide text-center text-3xl uppercase">New password</h1>
        <p className="mt-2 text-center text-sm text-chrome/60">Choose a new password for your account.</p>
        {checking && <p className="mt-8 text-center text-sm text-chrome/60">Checking your link…</p>}
        {ready && (
          <form onSubmit={submit} className="mt-8 space-y-3">
            <PasswordInput className={input} required minLength={6} placeholder="New password" value={pw} onChange={(e) => setPw(e.target.value)} />
            <PasswordInput className={input} required minLength={6} placeholder="Repeat new password" value={pw2} onChange={(e) => setPw2(e.target.value)} />
            <button disabled={busy} className="w-full rounded-full bg-chrome py-3 text-sm font-semibold uppercase tracking-widest text-ink hover:bg-chrome/85 disabled:opacity-50">
              {busy ? "…" : "Save new password"}
            </button>
          </form>
        )}
        {msg && <p className="mt-4 text-center text-sm text-crimson">{msg}</p>}
        {!ready && (
          <Link to="/auth" search={{ redirect: undefined }} className="mt-6 block w-full text-center text-sm text-chrome/60 hover:text-chrome">Back to sign in</Link>
        )}
      </div>
    </main>
  );
}
