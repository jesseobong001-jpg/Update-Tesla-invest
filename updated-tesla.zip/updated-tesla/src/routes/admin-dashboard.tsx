import { createFileRoute, redirect, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import AdminDashboard from "@/components/admin/AdminDashboard";
import { isAdminAuthenticated } from "@/lib/admin";

export const Route = createFileRoute("/admin-dashboard")({
  head: () => ({
    meta: [
      { title: "Admin dashboard — Tesla investments" },
      { name: "description", content: "Tesla investments admin panel." },
    ],
  }),
  beforeLoad: async () => {
    if (!isAdminAuthenticated()) throw redirect({ to: "/admin" });
  },
  component: AdminDashboard,
});
