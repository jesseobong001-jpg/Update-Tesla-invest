import { createFileRoute, Link } from "@tanstack/react-router";
import AdminLogin from "@/components/admin/AdminLogin";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin login — Tesla investments" },
      { name: "description", content: "Tesla investments admin panel login." },
    ],
  }),
  component: AdminLogin,
});
