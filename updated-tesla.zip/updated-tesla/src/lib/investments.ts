import { z } from "zod";

export const ASSETS = [
  { symbol: "TSLA", name: "Tesla", feed: "TSLA", kind: "Stock" },
  { symbol: "AAPL", name: "Apple", feed: "AAPL", kind: "Stock" },
  { symbol: "NVDA", name: "NVIDIA", feed: "NVDA", kind: "Stock" },
  { symbol: "BTC", name: "Bitcoin", feed: "BTC-USD", kind: "Crypto" },
  { symbol: "ETH", name: "Ethereum", feed: "ETH-USD", kind: "Crypto" },
  { symbol: "SOL", name: "Solana", feed: "SOL-USD", kind: "Crypto" },
] as const;
export const assetSymbolSchema = z.enum(["TSLA", "AAPL", "NVDA", "BTC", "ETH", "SOL"]);
export type AssetSymbol = z.infer<typeof assetSymbolSchema>;
export const investmentSchema = z.object({ symbol: assetSymbolSchema, amount: z.number().finite().positive().max(10_000_000).refine((n) => Math.abs(n * 100 - Math.round(n * 100)) < 0.000001, "Use at most two decimal places") });

export function parseAssetQuote(payload: unknown, expectedSymbol: string) {
  const schema = z.object({ chart: z.object({ result: z.array(z.object({
    meta: z.object({ symbol: z.literal(expectedSymbol), currency: z.literal("USD"), regularMarketPrice: z.number().finite().positive(), regularMarketTime: z.number().finite().positive(), previousClose: z.number().positive().optional(), chartPreviousClose: z.number().positive().optional() }),
  })).nullable() }) });
  const result = schema.parse(payload).chart.result?.[0];
  if (!result) throw new Error("Rate unavailable");
  const m = result.meta;
  const previous = m.previousClose ?? m.chartPreviousClose;
  return { price: m.regularMarketPrice, timestamp: m.regularMarketTime, changePercent: previous ? (m.regularMarketPrice - previous) / previous * 100 : null };
}