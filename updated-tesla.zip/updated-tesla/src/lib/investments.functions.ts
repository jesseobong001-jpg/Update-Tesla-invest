import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { ASSETS, investmentSchema, parseAssetQuote } from "@/lib/investments";

export const getInvestmentRates = createServerFn({ method: "GET" }).handler(async () => {
  // The catalog is capped at six to respect the Worker outbound connection budget.
  return Promise.all(ASSETS.map(async (asset) => {
    try {
      const response = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${asset.feed}?interval=1d&range=1d`, { signal: AbortSignal.timeout(8000) });
      if (!response.ok) throw new Error("Rate unavailable");
      return { ...asset, quote: parseAssetQuote(await response.json(), asset.feed), error: null };
    } catch {
      return { ...asset, quote: null, error: "Rate temporarily unavailable" };
    }
  }));
});

export const allocateInvestment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => investmentSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.rpc("allocate_investment", { _symbol: data.symbol, _amount: data.amount });
    if (error) throw new Error("Investment could not be saved. Check your available balance and try again.");
    return { ok: true };
  });