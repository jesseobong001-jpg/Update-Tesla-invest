export function depositStatus(review: { readable: boolean; amount_matches: boolean; recipient_matches: boolean; status_completed: boolean }) {
  // A screenshot cannot prove settlement, even when every visible field matches.
  return review.readable && review.amount_matches && review.recipient_matches && review.status_completed ? "pending_receipt" : "needs_review";
}