import { z } from "zod";

const payloadSchema = z.object({ chart: z.object({ result: z.array(z.object({
  meta: z.object({ symbol: z.literal("TSLA"), currency: z.literal("USD"), regularMarketPrice: z.number().positive(), regularMarketTime: z.number(), chartPreviousClose: z.number().optional(), previousClose: z.number().optional(), regularMarketDayHigh: z.number().optional(), regularMarketDayLow: z.number().optional(), regularMarketVolume: z.number().optional(), fiftyTwoWeekHigh: z.number().optional(), fiftyTwoWeekLow: z.number().optional() }),
  timestamp: z.array(z.number()),
  indicators: z.object({ quote: z.array(z.object({ close: z.array(z.number().nullable()) })) }),
})).nullable() }) });

export function parseTeslaMarket(payload: unknown) {
  const result = payloadSchema.parse(payload).chart.result?.[0];
  if (!result) throw new Error("Quote unavailable");
  const { meta } = result;
  const points = result.timestamp.flatMap((timestamp, i) => {
    const close = result.indicators.quote[0]?.close[i];
    return typeof close === "number" ? [{ timestamp, close }] : [];
  });
  const previousClose = meta.previousClose ?? points.at(-2)?.close ?? meta.chartPreviousClose ?? null;
  const change = previousClose ? meta.regularMarketPrice - previousClose : null;
  return { price: meta.regularMarketPrice, timestamp: meta.regularMarketTime, previousClose, change, changePercent: change !== null && previousClose ? change / previousClose * 100 : null, dayHigh: meta.regularMarketDayHigh ?? null, dayLow: meta.regularMarketDayLow ?? null, volume: meta.regularMarketVolume ?? null, yearHigh: meta.fiftyTwoWeekHigh ?? null, yearLow: meta.fiftyTwoWeekLow ?? null, points };
}