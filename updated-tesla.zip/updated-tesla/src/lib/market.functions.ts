import { createServerFn } from "@tanstack/react-start";
import { parseTeslaMarket } from "@/lib/market";

export const getTeslaMarket = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const response = await fetch("https://query1.finance.yahoo.com/v8/finance/chart/TSLA?interval=1d&range=1mo", { signal: AbortSignal.timeout(8000) });
    if (!response.ok) throw new Error("Market feed unavailable");
    return { quote: parseTeslaMarket(await response.json()), error: null };
  } catch {
    return { quote: null, error: "Market information is temporarily unavailable. Please try again." };
  }
});