import m3 from "@/assets/model_3.png";
import my from "@/assets/model_y.jpg";
import ms from "@/assets/model_s.jpg";
import mx from "@/assets/model_x.jpg";
import ct from "@/assets/cybertruck.jpg";
import cc from "@/assets/cybercab.jpg";
import sm from "@/assets/semi.jpg";
import rd from "@/assets/hero_frame.jpg";

export const MODELS = [
  { img: m3, name: "Model 3", tag: "Sport sedan", price: "$42,490", spec: "Up to 363 mi range" },
  { img: my, name: "Model Y", tag: "Midsize SUV", price: "$44,990", spec: "Up to 327 mi range" },
  { img: ms, name: "Model S", tag: "Luxury sedan", price: "$84,990", spec: "Up to 410 mi range" },
  { img: mx, name: "Model X", tag: "Luxury SUV", price: "$89,990", spec: "Up to 352 mi range" },
  { img: ct, name: "Cybertruck", tag: "Pickup", price: "$79,990", spec: "Up to 320 mi range" },
  { img: cc, name: "Cybercab", tag: "Autonomous robotaxi", price: "$29,990", spec: "Up to 300 mi range (est.)" },
  { img: sm, name: "Semi", tag: "Electric truck", price: "$179,990", spec: "Up to 500 mi range" },
  { img: rd, name: "Roadster", tag: "Flying supercar", price: "$200,000", spec: "Preorder now" },
];
export type CarModel = (typeof MODELS)[number];

export const PLANS = [
  { id: "w52", label: "52 weeks", unit: "week", count: 52 },
  { id: "w104", label: "104 weeks", unit: "week", count: 104 },
  { id: "m12", label: "12 months", unit: "month", count: 12 },
  { id: "m24", label: "24 months", unit: "month", count: 24 },
  { id: "m48", label: "48 months", unit: "month", count: 48 },
] as const;
export type Plan = (typeof PLANS)[number];

export const priceNumber = (price: string) => Number(price.replace(/[^0-9.]/g, ""));
export const installment = (price: string, plan: Plan) => Math.ceil((priceNumber(price) / plan.count) * 100) / 100;
export const money = (n: number) => n.toLocaleString("en-US", { style: "currency", currency: "USD" });
