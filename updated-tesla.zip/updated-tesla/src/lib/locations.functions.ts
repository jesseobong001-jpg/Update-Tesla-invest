import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export const getCountries = createServerFn({ method: "GET" }).handler(async () => {
  const { Country } = await import("country-state-city");
  return Country.getAllCountries().map(({ name, isoCode }) => ({ name, code: isoCode })).sort((a, b) => a.name.localeCompare(b.name));
});

export const getStates = createServerFn({ method: "GET" })
  .inputValidator(z.object({ country: z.string().regex(/^[A-Z]{2}$/) }))
  .handler(async ({ data }) => {
    const { State } = await import("country-state-city");
    return [...new Set((State.getStatesOfCountry(data.country) ?? []).map((state) => state.name))].sort((a, b) => a.localeCompare(b));
  });