export const DEPOSIT_METHODS = [
  { group: "Crypto", label: "Bitcoin", sub: "BTC", pay: "adress1235388" },
  { group: "Crypto", label: "USDT", sub: "Tether", pay: "adress1235388" },
  { group: "Crypto", label: "Ethereum", sub: "ETH", pay: "adress1235388" },
  { group: "Card", label: "Card", sub: "Debit or credit", pay: "" },
] as const;
export type DepositMethod = (typeof DEPOSIT_METHODS)[number];
