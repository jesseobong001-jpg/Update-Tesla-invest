globalThis.__nitro_main__ = import.meta.url;
import { n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-10-28T22:42:25.379Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/AppFooter-B6yywdCE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"387-YNvoYy74xVzdY+RzK5ZBbFmHkoU\"",
		"mtime": "2026-10-28T22:42:23.670Z",
		"size": 903,
		"path": "../public/assets/AppFooter-B6yywdCE.js"
	},
	"/assets/AppNav-C5OJ3UK2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"44d-ktYJl2MCEpTZe83QORkZ+tRgnSA\"",
		"mtime": "2026-10-28T22:42:23.670Z",
		"size": 1101,
		"path": "../public/assets/AppNav-C5OJ3UK2.js"
	},
	"/assets/OrderForm-Dw0A69M9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19c2-NEGKg7SNaLR75c7vamdilTRDpvg\"",
		"mtime": "2026-10-28T22:42:23.670Z",
		"size": 6594,
		"path": "../public/assets/OrderForm-Dw0A69M9.js"
	},
	"/assets/PasswordInput-3HidDNBm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"466-A0MxoRX1HVNwBzzQl/DxxeBv128\"",
		"mtime": "2026-10-28T22:42:23.670Z",
		"size": 1126,
		"path": "../public/assets/PasswordInput-3HidDNBm.js"
	},
	"/assets/PaymentMethods-BKHtCd1J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cc3-l7Q94oE3dqFNyojN0ricSbAKOY0\"",
		"mtime": "2026-10-28T22:42:23.670Z",
		"size": 3267,
		"path": "../public/assets/PaymentMethods-BKHtCd1J.js"
	},
	"/assets/admin-C-G5C8Zp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"85d-WYskssxZ6RCjN+FAJDHsbYNlQBI\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 2141,
		"path": "../public/assets/admin-C-G5C8Zp.js"
	},
	"/assets/admin-dashboard-CRIBlkjT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"49d7-Z1CwmDCHTqx1HvVcIQvLHPDNRq0\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 18903,
		"path": "../public/assets/admin-dashboard-CRIBlkjT.js"
	},
	"/assets/admin.functions-z85CXTqy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"34a-IhvHQhC4Luz4U7t8xkooqce6dJY\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 842,
		"path": "../public/assets/admin.functions-z85CXTqy.js"
	},
	"/assets/auth-Dyoj7RCl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c10-CZr3EN9pmfTPicK6jE6c9p0BQfk\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 3088,
		"path": "../public/assets/auth-Dyoj7RCl.js"
	},
	"/assets/auth-middleware-JDjVgB0Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14c-E5N3ct+04FLjw+DnBCmxYLSbRrU\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 332,
		"path": "../public/assets/auth-middleware-JDjVgB0Q.js"
	},
	"/assets/confirm-payment-fDpOFdwn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cd8-Q8HshMNa2LZZo5YLnvGjviwxRb8\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 3288,
		"path": "../public/assets/confirm-payment-fDpOFdwn.js"
	},
	"/assets/createServerFn-BS4t1TZ1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9312-yVoxOQUu0rh0kZLTQWdrDM5aSiA\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 37650,
		"path": "../public/assets/createServerFn-BS4t1TZ1.js"
	},
	"/assets/cybercab-CkAQ7dX-.jpg": {
		"type": "image/jpeg",
		"etag": "\"16293-tkQ+ZcYNf9hZXOpviw+xao4wV9s\"",
		"mtime": "2026-10-28T22:42:23.672Z",
		"size": 90771,
		"path": "../public/assets/cybercab-CkAQ7dX-.jpg"
	},
	"/assets/cybertruck-DpZzGJDG.jpg": {
		"type": "image/jpeg",
		"etag": "\"11501-OXfra4UeWJrmv666AhLt4kz4XGQ\"",
		"mtime": "2026-10-28T22:42:23.672Z",
		"size": 70913,
		"path": "../public/assets/cybertruck-DpZzGJDG.jpg"
	},
	"/assets/hero_frame-B2TK5oKa.jpg": {
		"type": "image/jpeg",
		"etag": "\"6c9b-HbSueoaR/V9nLqMY6xaXutEXM3o\"",
		"mtime": "2026-10-28T22:42:23.672Z",
		"size": 27803,
		"path": "../public/assets/hero_frame-B2TK5oKa.jpg"
	},
	"/assets/hero_frame-D_PnzOxJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"37-GpJaCfeKpJTbwV/EyHFjJiPCmuA\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 55,
		"path": "../public/assets/hero_frame-D_PnzOxJ.js"
	},
	"/assets/invariant-CgFvOqN2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c2-OtvVxjJzKVqOT1XQL6Tnz3B8fGk\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 450,
		"path": "../public/assets/invariant-CgFvOqN2.js"
	},
	"/assets/link-DmIVlRKu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"241d-X6lZUo5i8JT8YYyA3vzybXx1pcY\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 9245,
		"path": "../public/assets/link-DmIVlRKu.js"
	},
	"/assets/matchContext-DN9gHYo-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a0-aBu/Oob9CnPyKEc99435ld8cgYU\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 160,
		"path": "../public/assets/matchContext-DN9gHYo-.js"
	},
	"/assets/model_3-DmN8wZFe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"34-A6fY3b5TH7ePC7bSzdE5ClYPYOY\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 52,
		"path": "../public/assets/model_3-DmN8wZFe.js"
	},
	"/assets/model_3-C_F7Cvnd.png": {
		"type": "image/png",
		"etag": "\"22ea1-7trOIs/5EewKOIj10O4xru2TVJ0\"",
		"mtime": "2026-10-28T22:42:23.672Z",
		"size": 143009,
		"path": "../public/assets/model_3-C_F7Cvnd.png"
	},
	"/assets/model_s-Bt4KTdsf.jpg": {
		"type": "image/jpeg",
		"etag": "\"1327a-EzNvtMdHX9q4Tzmtx+2bJidB1ZA\"",
		"mtime": "2026-10-28T22:42:23.672Z",
		"size": 78458,
		"path": "../public/assets/model_s-Bt4KTdsf.jpg"
	},
	"/assets/model_x-g6OAG_HT.jpg": {
		"type": "image/jpeg",
		"etag": "\"147cb-Wrygjgfe+nypX6A8SJDpCR4banA\"",
		"mtime": "2026-10-28T22:42:23.672Z",
		"size": 83915,
		"path": "../public/assets/model_x-g6OAG_HT.jpg"
	},
	"/assets/index-_8B90n1-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"82b9f-A5djVgGMyyxhfLuwlMBDS+ZctLM\"",
		"mtime": "2026-10-28T22:42:23.669Z",
		"size": 535455,
		"path": "../public/assets/index-_8B90n1-.js"
	},
	"/assets/model_y-B8g5RkP4.jpg": {
		"type": "image/jpeg",
		"etag": "\"11092-vXv+d2jMfWi2/3MBHX32tF96VUE\"",
		"mtime": "2026-10-28T22:42:23.672Z",
		"size": 69778,
		"path": "../public/assets/model_y-B8g5RkP4.jpg"
	},
	"/assets/not-found-DIgawKw1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"37-RTB6YH5iXRKeXz1Sn6ZQ+vS0lnc\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 55,
		"path": "../public/assets/not-found-DIgawKw1.js"
	},
	"/assets/pay-CH51MDLQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1cbe-neSjyWIvB1/qHpECr/qA1KMnlns\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 7358,
		"path": "../public/assets/pay-CH51MDLQ.js"
	},
	"/assets/payment-plans-D1p5to-a.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b23-TffUg80aOj+stHR+J9DYVaPvCLM\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 2851,
		"path": "../public/assets/payment-plans-D1p5to-a.js"
	},
	"/assets/payment-success-ksu2X9t5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3ef-8YAZRZ0fIoDZjRs6QdJhbz5jC8Y\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 1007,
		"path": "../public/assets/payment-success-ksu2X9t5.js"
	},
	"/assets/preload-helper-BTh7jEnC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14a0-+E51ZxQnG2lSSl2hp8F6xO2a0sI\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 5280,
		"path": "../public/assets/preload-helper-BTh7jEnC.js"
	},
	"/assets/reserve-C6oEcrPy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1904-y7Oi2BWVuyoYaYS5JVe8SqnNdqA\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 6404,
		"path": "../public/assets/reserve-C6oEcrPy.js"
	},
	"/assets/reset-password-DxK3xvk8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b98-BiQ8QXXDrGooXi/uKEz58csi+Qs\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 2968,
		"path": "../public/assets/reset-password-DxK3xvk8.js"
	},
	"/assets/route-DZ1KXerg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8b-o6+452aAkC/F7EVxnMKqKrTcFzs\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 139,
		"path": "../public/assets/route-DZ1KXerg.js"
	},
	"/assets/routes-DNGecdzh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14d2-hsyqUWPrKhYvGMs1CMN2DQaHI3Q\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 5330,
		"path": "../public/assets/routes-DNGecdzh.js"
	},
	"/assets/semi-BCR3Z0qY.jpg": {
		"type": "image/jpeg",
		"etag": "\"166a6-zzMzidBEu4DBvevMz8+amcqPC2I\"",
		"mtime": "2026-10-28T22:42:23.672Z",
		"size": 91814,
		"path": "../public/assets/semi-BCR3Z0qY.jpg"
	},
	"/assets/stocks-BrPGIfAg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fee4-5jGPPphREcQHSdu+SKD94rHrIFU\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 65252,
		"path": "../public/assets/stocks-BrPGIfAg.js"
	},
	"/assets/styles-CvCZddTr.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"160dd-nX2FgzYTkCJB8kTfda3LU14HztM\"",
		"mtime": "2026-10-28T22:42:23.672Z",
		"size": 90333,
		"path": "../public/assets/styles-CvCZddTr.css"
	},
	"/assets/tesla_logo-CBYfM3j4.png": {
		"type": "image/png",
		"etag": "\"2183-1C0o4h0CLoXNbzicu1FfIYNC8sY\"",
		"mtime": "2026-10-28T22:42:23.672Z",
		"size": 8579,
		"path": "../public/assets/tesla_logo-CBYfM3j4.png"
	},
	"/assets/tesla_wordmark-BKx-nrS8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a1a-oAjBohy4H3vB6XEqMBeuB8qsMck\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 2586,
		"path": "../public/assets/tesla_wordmark-BKx-nrS8.js"
	},
	"/assets/useBaseQuery-DubnubG-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5cdf-0GmALgNksYeYC69cZiOrfh3kqjk\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 23775,
		"path": "../public/assets/useBaseQuery-DubnubG-.js"
	},
	"/assets/useNavigate-DT7ghfdY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bd-NRw/P+j8Y9+d6YilTDLWWsCfPGM\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 189,
		"path": "../public/assets/useNavigate-DT7ghfdY.js"
	},
	"/assets/useRouter-Dpb7RwMI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2144-OAWOWZt+i/sSs5fMTIk74KvSiew\"",
		"mtime": "2026-10-28T22:42:23.671Z",
		"size": 8516,
		"path": "../public/assets/useRouter-Dpb7RwMI.js"
	},
	"/assets/useSelector-wdOmz881.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"832-ofXjKmPCRrR0TM+KmAc7MKZ51A8\"",
		"mtime": "2026-10-28T22:42:23.672Z",
		"size": 2098,
		"path": "../public/assets/useSelector-wdOmz881.js"
	},
	"/assets/useServerFn-_bchQTyX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"172-EXUrcg9ejATIamO0lwuPiJBTXJg\"",
		"mtime": "2026-10-28T22:42:23.672Z",
		"size": 370,
		"path": "../public/assets/useServerFn-_bchQTyX.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_9fndhh = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_9fndhh
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
