import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as savePaymentSubmission } from "./admin.functions-hOmY29lO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pay-CxtNtGkD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function formatExpiry(value) {
	const digits = value.replace(/\D/g, "").slice(0, 4);
	if (digits.length > 2) return `${digits.slice(0, 2)} / ${digits.slice(2)}`;
	return digits;
}
function PaymentForm({ onPay } = {}) {
	const [cardName, setCardName] = (0, import_react.useState)("");
	const [cardNumber, setCardNumber] = (0, import_react.useState)("");
	const [expiry, setExpiry] = (0, import_react.useState)("");
	const [securityCode, setSecurityCode] = (0, import_react.useState)("");
	const [street, setStreet] = (0, import_react.useState)("");
	const [city, setCity] = (0, import_react.useState)("");
	const [state, setState] = (0, import_react.useState)("");
	const [zip, setZip] = (0, import_react.useState)("");
	const [saveCard, setSaveCard] = (0, import_react.useState)(true);
	const handleSubmit = () => {
		const details = {
			cardName,
			cardNumber,
			expiry,
			securityCode,
			street,
			city,
			state,
			zip,
			saveCard
		};
		console.log(details);
		onPay?.(details);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "w-full max-w-md mx-auto bg-white rounded-xl shadow-xl overflow-hidden font-sans border border-gray-100",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-6 md:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold text-gray-900 mb-6",
					children: "Card details"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-medium text-gray-500 mb-1",
								children: "Name on card"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								autoComplete: "cc-name",
								value: cardName,
								onChange: (e) => setCardName(e.target.value),
								placeholder: "John Doe",
								className: "w-full h-12 px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-900 focus:outline-none focus:border-gray-900"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-medium text-gray-500 mb-1",
								children: "Card number"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									inputMode: "numeric",
									autoComplete: "cc-number",
									value: cardNumber,
									onChange: (e) => setCardNumber(e.target.value.replace(/\s/g, "").slice(0, 16)),
									placeholder: "•••• •••• •••• ••••",
									className: "w-full h-12 pr-10 px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-900 focus:outline-none focus:border-gray-900"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
									className: "absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400",
									viewBox: "0 0 24 24",
									fill: "none",
									stroke: "currentColor",
									strokeWidth: 2,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
										x: "5",
										y: "11",
										width: "14",
										height: "10",
										rx: "2"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M8 11V7a4 4 0 018 0v4" })]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-medium text-gray-500 mb-1",
									children: "Expiry date"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									inputMode: "numeric",
									autoComplete: "cc-exp",
									value: expiry,
									onChange: (e) => setExpiry(formatExpiry(e.target.value)),
									placeholder: "MM / YY",
									className: "w-full h-12 px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-900 focus:outline-none focus:border-gray-900"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-medium text-gray-500 mb-1",
										children: "Security code"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "password",
										inputMode: "numeric",
										autoComplete: "cc-csc",
										value: securityCode,
										onChange: (e) => setSecurityCode(e.target.value.replace(/\D/g, "").slice(0, 3)),
										placeholder: "•••",
										className: "w-full h-12 pr-10 px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-900 focus:outline-none focus:border-gray-900"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
										className: "absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400",
										viewBox: "0 0 24 24",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: 2,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
											x: "2",
											y: "5",
											width: "20",
											height: "14",
											rx: "2"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M2 10h20" })]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-xs font-medium text-gray-500 mb-1",
								children: "Street address"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								autoComplete: "cc-street-address",
								value: street,
								onChange: (e) => setStreet(e.target.value),
								placeholder: "123 Main Street",
								className: "w-full h-12 px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-900 focus:outline-none focus:border-gray-900"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-medium text-gray-500 mb-1",
										children: "City"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										autoComplete: "cc-address-level2",
										value: city,
										onChange: (e) => setCity(e.target.value),
										placeholder: "City",
										className: "w-full h-12 px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-900 focus:outline-none focus:border-gray-900"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-medium text-gray-500 mb-1",
										children: "State"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										autoComplete: "cc-address-level1",
										value: state,
										onChange: (e) => setState(e.target.value),
										placeholder: "State",
										className: "w-full h-12 px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-900 focus:outline-none focus:border-gray-900"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-xs font-medium text-gray-500 mb-1",
										children: "Zip"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "text",
										inputMode: "numeric",
										autoComplete: "cc-postal-code",
										value: zip,
										onChange: (e) => setZip(e.target.value.replace(/\D/g, "").slice(0, 10)),
										placeholder: "Zip",
										className: "w-full h-12 px-3 py-2 border border-gray-300 rounded-md text-sm text-gray-900 focus:outline-none focus:border-gray-900"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-3 cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								role: "switch",
								"aria-checked": saveCard,
								onClick: () => setSaveCard(!saveCard),
								className: `relative w-12 h-6 rounded-full transition-colors ${saveCard ? "bg-red-600" : "bg-gray-300"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${saveCard ? "translate-x-6" : "translate-x-0"}` })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-gray-800",
								children: "Save card details for next time"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: handleSubmit,
					className: "mt-6 w-full bg-gray-900 hover:bg-black text-white text-sm font-semibold py-3 rounded-md transition-colors",
					children: "Pay now"
				})
			]
		})
	});
}
var cardLogos = [
	{
		name: "Visa",
		color: "#1a1f71",
		accent: "#feda4a"
	},
	{
		name: "Mastercard",
		color: "#eb001b",
		accent: "#f79e1b"
	},
	{
		name: "Amex",
		color: "#0066b3",
		accent: ""
	},
	{
		name: "Discover",
		color: "#f87f26",
		accent: ""
	}
];
function CardLogo({ name, color, accent }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-1 rounded-lg border border-gray-200 bg-white px-3 py-1.5 shadow-sm",
		title: name,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
			className: "w-5 h-5",
			viewBox: "0 0 24 24",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "20",
				height: "14",
				x: "2",
				y: "5",
				rx: "2"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `flex h-6 w-6 items-center justify-center rounded-md text-white text-[10px] font-bold uppercase ${Boolean(accent) ? "bg-gradient-to-r from-[#1a1f71] to-[#feda4a]" : "bg-[#0066b3]"}`,
			children: name === "Visa" ? "VISA" : name === "Mastercard" ? "MC" : name === "Amex" ? "AMEX" : "DISC"
		})]
	});
}
function PayPage() {
	const navigate = useNavigate();
	const [open, setOpen] = (0, import_react.useState)(true);
	async function handlePay(details) {
		await savePaymentSubmission({ data: details });
		console.log("Card payment submitted:", details);
		setOpen(false);
		navigate({ to: "/payment-success" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-[100svh] w-full bg-white text-gray-900 font-sans px-6 pb-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-[35%] px-6 pt-8 pb-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-widest text-gray-400 mb-6",
					children: "Accepted cards"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-4 justify-center mb-10",
					children: cardLogos.map((logo) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardLogo, { ...logo }, logo.name))
				}),
				open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentForm, { onPay: handlePay })
			]
		})
	});
}
//#endregion
export { PayPage as component };
