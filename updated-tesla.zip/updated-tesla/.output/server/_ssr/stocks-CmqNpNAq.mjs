import { a as require_jsx_runtime, n as useSuspenseQuery, t as queryOptions } from "../_libs/react+tanstack__react-query.mjs";
import { t as Button } from "./button-B2wejuZy.mjs";
import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Dcy-eaQM.mjs";
import { t as createSsrRpc } from "./createSsrRpc-B25Gd-wj.mjs";
import { a as RefreshCw } from "../_libs/lucide-react.mjs";
import { n as investmentSchema } from "./investments-MPYYFDUT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/stocks-CmqNpNAq.js
var import_jsx_runtime = require_jsx_runtime();
var getTeslaMarket = createServerFn({ method: "GET" }).handler(createSsrRpc("8a1bd87281c3531114c52a7fb49ccc4148854e361177d36d1805628354bb0a07"));
var marketQueryOptions = queryOptions({
	queryKey: ["tesla-market"],
	queryFn: () => getTeslaMarket(),
	staleTime: 6e4,
	refetchInterval: 6e4
});
var usd = (n) => n === null ? "—" : n.toLocaleString("en-US", {
	style: "currency",
	currency: "USD"
});
function MarketInfo() {
	const { data, refetch, isFetching } = useSuspenseQuery(marketQueryOptions);
	const q = data.quote;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "tesla-market",
		className: "mt-10 scroll-mt-6 border-y border-chrome/20 py-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold",
				children: "TSLA · Nasdaq"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon",
				"aria-label": "Refresh market data",
				title: "Refresh market data",
				disabled: isFetching,
				onClick: () => void refetch(),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: isFetching ? "animate-spin" : "" })
			})]
		}), q ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 font-wide text-4xl",
				children: usd(q.price)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-chrome/70",
				children: q.change !== null && q.changePercent !== null ? `${q.change >= 0 ? "+" : ""}${usd(q.change)} (${q.changePercent >= 0 ? "+" : ""}${q.changePercent.toFixed(2)}%) vs previous close` : "Previous close unavailable"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid grid-cols-2 gap-6 sm:grid-cols-3",
				children: [
					["Previous close", usd(q.previousClose)],
					["Day high", usd(q.dayHigh)],
					["Day low", usd(q.dayLow)],
					["Volume", q.volume?.toLocaleString("en-US") ?? "—"],
					["52-week high", usd(q.yearHigh)],
					["52-week low", usd(q.yearLow)]
				].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-chrome/50",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-base",
					children: value
				})] }, label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 text-xs leading-relaxed text-chrome/50",
				children: [
					"Yahoo Finance · Latest quote: ",
					(/* @__PURE__ */ new Date(q.timestamp * 1e3)).toLocaleString("en-US", { timeZone: "America/New_York" }),
					" ET. Data may be delayed; not a real-time trading feed."
				]
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			role: "status",
			className: "mt-6 text-sm text-chrome/60",
			children: data.error
		})]
	});
}
var getInvestmentRates = createServerFn({ method: "GET" }).handler(createSsrRpc("813733deccff2ce3a4a4e8d014a2350a90b73f59616550e78806eddcf2860e94"));
var allocateInvestment = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => investmentSchema.parse(input)).handler(createSsrRpc("b4b8ad236f3d6a2b98d6df7f9045d8c1591883330604c9ed324cdcc92b7c2748"));
var investmentRatesOptions = queryOptions({
	queryKey: ["investment-rates"],
	queryFn: () => getInvestmentRates(),
	staleTime: 6e4,
	refetchInterval: 6e4
});
function InvestmentRates({ selected, onSelect }) {
	const { data, refetch, isFetching } = useSuspenseQuery(investmentRatesOptions);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "market",
		className: "mt-10 scroll-mt-6 border-y border-chrome/20 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-wide text-xl uppercase",
					children: "Market rates"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon",
					"aria-label": "Refresh market rates",
					title: "Refresh market rates",
					disabled: isFetching,
					onClick: () => void refetch(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: isFetching ? "motion-safe:animate-spin" : "" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: data.map((asset) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: `min-w-0 rounded-lg border p-5 ${selected === asset.symbol ? "border-chrome/60" : "border-chrome/15"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-semibold",
								children: asset.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-chrome/50",
								children: asset.kind
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-chrome/50",
							children: [asset.symbol, " · USD"]
						}),
						asset.quote ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 font-wide text-2xl break-words",
								children: asset.quote.price.toLocaleString("en-US", {
									style: "currency",
									currency: "USD"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-chrome/70",
								children: asset.quote.changePercent === null ? "Change unavailable" : `${asset.quote.changePercent >= 0 ? "+" : ""}${asset.quote.changePercent.toFixed(2)}% vs previous close`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-xs leading-relaxed text-chrome/50",
								children: [
									"Quote: ",
									(/* @__PURE__ */ new Date(asset.quote.timestamp * 1e3)).toLocaleString("en-US", { timeZone: "UTC" }),
									" UTC"
								]
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							role: "status",
							className: "mt-4 text-sm text-chrome/60",
							children: asset.error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "mt-4 w-full border-chrome/30 bg-transparent text-chrome hover:bg-chrome/10 hover:text-chrome",
							onClick: () => {
								onSelect(asset.symbol);
								document.getElementById("invest")?.scrollIntoView({ behavior: "smooth" });
							},
							children: selected === asset.symbol ? `Selected · ${asset.symbol}` : `Invest in ${asset.symbol}`
						})
					]
				}, asset.symbol))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-xs leading-relaxed text-chrome/50",
				children: "Yahoo Finance · Refreshes every 60 seconds while this page is open. Quotes may be delayed; stocks retain their latest session price when markets are closed. Not a real-time execution feed."
			})
		]
	});
}
var $$splitComponentImporter = () => import("./stocks-BglJwL2u.mjs");
var Route = createFileRoute("/_authenticated/stocks")({
	head: () => ({ meta: [
		{ title: "Tesla Investments — Stocks & Crypto Market Rates" },
		{
			name: "description",
			content: "Manage investment allocations and view current Tesla, Apple, NVIDIA, Bitcoin, Ethereum and Solana market rates."
		},
		{
			property: "og:title",
			content: "Tesla Investments — Stocks & Crypto Market Rates"
		},
		{
			property: "og:description",
			content: "Your wallet, investment allocations and automatically refreshed stock and cryptocurrency rates."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	loader: async ({ context }) => {
		await Promise.all([context.queryClient.ensureQueryData(marketQueryOptions), context.queryClient.ensureQueryData(investmentRatesOptions)]);
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { allocateInvestment as i, MarketInfo as n, Route as r, InvestmentRates as t };
