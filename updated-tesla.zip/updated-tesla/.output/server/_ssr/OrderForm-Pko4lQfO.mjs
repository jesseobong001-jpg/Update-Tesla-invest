import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime, r as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { t as Button } from "./button-B2wejuZy.mjs";
import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as createSsrRpc } from "./createSsrRpc-B25Gd-wj.mjs";
import { o as objectType, s as stringType } from "../_libs/zod.mjs";
import { t as X } from "../_libs/lucide-react.mjs";
import { t as supabase } from "./client-fMq9G4Ay.mjs";
import { t as PaymentMethods } from "./PaymentMethods-ZeNCBbZH.mjs";
import { t as model_3_default } from "./model_3-CphTR_0O.mjs";
import { t as hero_frame_default } from "./hero_frame-B0rA0ldX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/OrderForm-Pko4lQfO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MODELS = [
	{
		img: model_3_default,
		name: "Model 3",
		tag: "Sport sedan",
		price: "$42,490",
		spec: "Up to 363 mi range"
	},
	{
		img: "/assets/model_y-B8g5RkP4.jpg",
		name: "Model Y",
		tag: "Midsize SUV",
		price: "$44,990",
		spec: "Up to 327 mi range"
	},
	{
		img: "/assets/model_s-Bt4KTdsf.jpg",
		name: "Model S",
		tag: "Luxury sedan",
		price: "$84,990",
		spec: "Up to 410 mi range"
	},
	{
		img: "/assets/model_x-g6OAG_HT.jpg",
		name: "Model X",
		tag: "Luxury SUV",
		price: "$89,990",
		spec: "Up to 352 mi range"
	},
	{
		img: "/assets/cybertruck-DpZzGJDG.jpg",
		name: "Cybertruck",
		tag: "Pickup",
		price: "$79,990",
		spec: "Up to 320 mi range"
	},
	{
		img: "/assets/cybercab-CkAQ7dX-.jpg",
		name: "Cybercab",
		tag: "Autonomous robotaxi",
		price: "$29,990",
		spec: "Up to 300 mi range (est.)"
	},
	{
		img: "/assets/semi-BCR3Z0qY.jpg",
		name: "Semi",
		tag: "Electric truck",
		price: "$179,990",
		spec: "Up to 500 mi range"
	},
	{
		img: hero_frame_default,
		name: "Roadster",
		tag: "Flying supercar",
		price: "$200,000",
		spec: "Preorder now"
	}
];
var PLANS = [
	{
		id: "w52",
		label: "52 weeks",
		unit: "week",
		count: 52
	},
	{
		id: "w104",
		label: "104 weeks",
		unit: "week",
		count: 104
	},
	{
		id: "m12",
		label: "12 months",
		unit: "month",
		count: 12
	},
	{
		id: "m24",
		label: "24 months",
		unit: "month",
		count: 24
	},
	{
		id: "m48",
		label: "48 months",
		unit: "month",
		count: 48
	}
];
var priceNumber = (price) => Number(price.replace(/[^0-9.]/g, ""));
var installment = (price, plan) => Math.ceil(priceNumber(price) / plan.count * 100) / 100;
var money = (n) => n.toLocaleString("en-US", {
	style: "currency",
	currency: "USD"
});
var getCountries = createServerFn({ method: "GET" }).handler(createSsrRpc("551d241f8441b5fe044d2212a4092d8892d0416576bbbcbfb5cf4309998663d0"));
var getStates = createServerFn({ method: "GET" }).inputValidator(objectType({ country: stringType().regex(/^[A-Z]{2}$/) })).handler(createSsrRpc("c1964b3579e6962aabd181aca431c300cbbb44e1c32e2f8024963eb0ed55f0ba"));
function OrderForm({ model, userId, onClose, plan }) {
	const due = plan ? `${money(installment(model.price, plan))}` : money(priceNumber(model.price));
	const [f, setF] = (0, import_react.useState)({
		full_name: "",
		address: "",
		country: "",
		city: ""
	});
	const [countryCode, setCountryCode] = (0, import_react.useState)("");
	const [method, setMethod] = (0, import_react.useState)(null);
	const [msg, setMsg] = (0, import_react.useState)(null);
	const [done, setDone] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const countries = useQuery({
		queryKey: ["countries"],
		queryFn: () => getCountries(),
		staleTime: Infinity
	});
	const states = useQuery({
		queryKey: ["states", countryCode],
		queryFn: () => getStates({ data: { country: countryCode } }),
		enabled: Boolean(countryCode),
		staleTime: Infinity
	});
	async function buy(e) {
		e.preventDefault();
		if (Object.values(f).some((value) => !value.trim()) || !method) return setMsg("Complete your address and select a payment method.");
		if (!states.data?.includes(f.city)) return setMsg("Select a state in your chosen country.");
		setBusy(true);
		setMsg(null);
		try {
			const { error } = await supabase.from("orders").insert({
				...f,
				model: model.name,
				price: model.price,
				user_id: userId,
				payment_method: method.label,
				payment_plan: plan ? `${plan.label} · ${due}/${plan.unit}` : "Full payment"
			});
			if (error) {
				setMsg(error.message);
				return;
			}
			setDone(true);
		} catch {
			setMsg("Couldn't place your order. Please try again.");
		} finally {
			setBusy(false);
		}
	}
	const input = "w-full rounded-lg border border-chrome/20 bg-ink px-4 py-3 text-sm text-chrome outline-none focus:border-chrome/60 disabled:opacity-50";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-ink/80 p-4 backdrop-blur sm:items-center",
		onClick: () => {
			if (!busy) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "order-title",
			className: "max-h-[90svh] w-full max-w-md overflow-y-auto rounded-lg border border-chrome/15 bg-ink p-6",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "order-title",
						className: "font-wide text-3xl uppercase",
						children: "Order"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "icon",
						disabled: busy,
						onClick: onClose,
						"aria-label": "Close",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: model.img,
					alt: `Tesla ${model.name}`,
					className: "mt-4 aspect-[3/2] w-full rounded-lg object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-wide text-lg uppercase",
						children: model.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-wide text-lg",
						children: model.price
					})]
				}),
				plan && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-chrome/70",
					children: [
						due,
						" per ",
						plan.unit,
						" for ",
						plan.label
					]
				}),
				done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					role: "status",
					className: "mt-6 text-sm text-chrome/80",
					children: [
						"Order placed for your ",
						model.name,
						". Payment pending — no charge has been made."
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: buy,
					className: "mt-6 space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							"aria-label": "Full name",
							className: input,
							placeholder: "Full name",
							maxLength: 100,
							value: f.full_name,
							onChange: (e) => setF({
								...f,
								full_name: e.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							"aria-label": "Street address",
							className: input,
							placeholder: "Street address",
							maxLength: 200,
							value: f.address,
							onChange: (e) => setF({
								...f,
								address: e.target.value
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block space-y-2 text-xs text-chrome/60",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Country" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								required: true,
								"aria-label": "Country",
								className: input,
								value: countryCode,
								onChange: (e) => {
									const country = countries.data?.find((item) => item.code === e.target.value);
									setCountryCode(e.target.value);
									setF({
										...f,
										country: country?.name ?? "",
										city: ""
									});
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: countries.isPending ? "Loading countries…" : "Select country"
								}), countries.data?.map((country) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: country.code,
									children: country.name
								}, country.code))]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block space-y-2 text-xs text-chrome/60",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "State" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								required: true,
								"aria-label": "State",
								className: input,
								disabled: !countryCode || states.isPending || !states.data?.length,
								value: f.city,
								onChange: (e) => setF({
									...f,
									city: e.target.value
								}),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: !countryCode ? "Select country first" : states.isPending ? "Loading states…" : "Select state"
									}),
									f.city && !(states.data ?? []).includes(f.city) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: f.city,
										children: f.city
									}),
									(states.data ?? []).map((state) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: state,
										children: state
									}, state))
								]
							})]
						}),
						states.data?.length === 0 && countryCode && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-crimson",
							children: "No states listed for this country. Choose another country or contact us before ordering."
						}),
						(countries.isError || states.isError) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							onClick: () => {
								countries.refetch();
								if (countryCode) states.refetch();
							},
							children: "Couldn't load locations. Retry"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "pt-4 text-sm font-semibold uppercase",
							children: "Payment method"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentMethods, {
							value: method,
							onChange: setMethod
						}),
						msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							role: "alert",
							className: "text-xs text-crimson",
							children: msg
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: busy || !method,
							type: "submit",
							className: "h-12 w-full bg-chrome text-ink hover:bg-chrome/85",
							children: busy ? "Placing order…" : method?.group === "Card" ? `Pay ${due}` : "Buy now"
						})
					]
				})
			]
		})
	});
}
//#endregion
export { getStates as a, getCountries as i, OrderForm as n, installment as o, PLANS as r, money as s, MODELS as t };
