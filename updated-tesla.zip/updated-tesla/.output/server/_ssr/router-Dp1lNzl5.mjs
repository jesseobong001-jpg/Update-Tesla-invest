import { i as __toESM } from "../_runtime.mjs";
import { o as isAdminAuthenticated } from "./admin-DIQeDyiU.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime, i as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { K as redirect, _ as createFileRoute, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRouteWithContext, x as useRouter, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-fMq9G4Ay.mjs";
import { t as Route$8 } from "./auth-ehOh6BmY.mjs";
import { t as Route$9 } from "./confirm-payment-Dc24vLhD.mjs";
import { t as Route$10 } from "./payment-plans-CjmpqFoD.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as Route$11 } from "./reserve-DBdyidAB.mjs";
import { r as Route$12 } from "./stocks-CmqNpNAq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Dp1lNzl5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-CvCZddTr.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message: describeThrown(error),
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var MAX_SERIALIZED_LENGTH = 2e3;
function describeThrown(error) {
	if (error instanceof Response) return `Response ${error.status}${error.url ? ` at ${error.url}` : ""}`;
	if (error instanceof Error) return error.message;
	if (typeof error === "string") return error;
	const { message } = error ?? {};
	if (typeof message === "string" && message.length > 0) return message;
	try {
		return JSON.stringify(error)?.slice(0, MAX_SERIALIZED_LENGTH) ?? String(error);
	} catch {
		return String(error);
	}
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$7 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Tesla Roadster — Models and Investments" },
			{
				name: "description",
				content: "Explore Tesla models, Roadster preorders, and Tesla market information."
			},
			{
				property: "og:title",
				content: "Tesla Roadster — Models and Investments"
			},
			{
				property: "og:description",
				content: "Explore Tesla models, Roadster preorders, and Tesla market information."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@62..125,100..900&family=Inter+Tight:wght@300;400;500;600&family=Pinyon+Script&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$7.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
var $$splitComponentImporter$6 = () => import("./routes-btqrweJb.mjs");
var Route$6 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "Tesla Roadster — Models and Investments" },
		{
			name: "description",
			content: "Tesla Roadster: preorder the new Roadster and follow TSLA stock, all in one place."
		},
		{
			property: "og:title",
			content: "Tesla Roadster — Models and Investments"
		},
		{
			property: "og:description",
			content: "Preorder the new Tesla Roadster or invest in TSLA from one place."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./route-Di7iQBCH.mjs");
var Route$5 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async ({ location }) => {
		const { data } = await supabase.auth.getUser();
		if (!data.user) throw redirect({
			to: "/auth",
			search: { redirect: location.pathname }
		});
		return { user: data.user };
	},
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./admin-CTLknD87.mjs");
var Route$4 = createFileRoute("/admin")({
	head: () => ({ meta: [{ title: "Admin login — Tesla investments" }, {
		name: "description",
		content: "Tesla investments admin panel login."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./admin-dashboard-CbQm7Amg.mjs");
var Route$3 = createFileRoute("/admin-dashboard")({
	head: () => ({ meta: [{ title: "Admin dashboard — Tesla investments" }, {
		name: "description",
		content: "Tesla investments admin panel."
	}] }),
	beforeLoad: async () => {
		if (!isAdminAuthenticated()) throw redirect({ to: "/admin" });
	},
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./reset-password-Ba4GQ2Id.mjs");
var Route$2 = createFileRoute("/reset-password")({
	head: () => ({ meta: [
		{ title: "Choose a new password — Tesla Roadster" },
		{
			name: "description",
			content: "Set a new password for your Tesla Roadster account."
		},
		{
			property: "og:title",
			content: "Choose a new password — Tesla Roadster"
		},
		{
			property: "og:description",
			content: "Set a new password for your Tesla Roadster account."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./pay-CxtNtGkD.mjs");
var Route$1 = createFileRoute("/_authenticated/pay")({
	head: () => ({ meta: [
		{ title: "Pay with card — Tesla investments" },
		{
			name: "description",
			content: "Enter your card details to complete your Tesla investment payment."
		},
		{
			property: "og:title",
			content: "Pay with card — Tesla investments"
		},
		{
			property: "og:description",
			content: "Pay for your Tesla investment with a debit or credit card."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./payment-success-JYylszBG.mjs");
var Route = createFileRoute("/_authenticated/payment-success")({
	head: () => ({ meta: [
		{ title: "Order confirmed — Tesla investments" },
		{
			name: "description",
			content: "Your Tesla order is on the way and a confirmation email has been sent."
		},
		{
			property: "og:title",
			content: "Order confirmed — Tesla investments"
		},
		{
			property: "og:description",
			content: "Your order is on the way. Check your email for confirmation."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$6.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$7
});
var AuthenticatedRouteRoute = Route$5.update({
	id: "/_authenticated",
	getParentRoute: () => Route$7
});
var AdminRoute = Route$4.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$7
});
var AdminDashboardRoute = Route$3.update({
	id: "/admin-dashboard",
	path: "/admin-dashboard",
	getParentRoute: () => Route$7
});
var AuthRoute = Route$8.update({
	id: "/auth",
	path: "/auth",
	getParentRoute: () => Route$7
});
var ResetPasswordRoute = Route$2.update({
	id: "/reset-password",
	path: "/reset-password",
	getParentRoute: () => Route$7
});
var AuthenticatedRouteRouteChildren = {
	AuthenticatedConfirmPaymentRoute: Route$9.update({
		id: "/confirm-payment",
		path: "/confirm-payment",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedPayRoute: Route$1.update({
		id: "/pay",
		path: "/pay",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedPaymentPlansRoute: Route$10.update({
		id: "/payment-plans",
		path: "/payment-plans",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedPaymentSuccessRoute: Route.update({
		id: "/payment-success",
		path: "/payment-success",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedReserveRoute: Route$11.update({
		id: "/reserve",
		path: "/reserve",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedStocksRoute: Route$12.update({
		id: "/stocks",
		path: "/stocks",
		getParentRoute: () => AuthenticatedRouteRoute
	})
};
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	AdminRoute,
	AdminDashboardRoute,
	AuthRoute,
	ResetPasswordRoute
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
