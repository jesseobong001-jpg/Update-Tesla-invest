import { a as numberType, i as literalType, o as objectType, r as enumType, t as arrayType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/investments-MPYYFDUT.js
var ASSETS = [
	{
		symbol: "TSLA",
		name: "Tesla",
		feed: "TSLA",
		kind: "Stock"
	},
	{
		symbol: "AAPL",
		name: "Apple",
		feed: "AAPL",
		kind: "Stock"
	},
	{
		symbol: "NVDA",
		name: "NVIDIA",
		feed: "NVDA",
		kind: "Stock"
	},
	{
		symbol: "BTC",
		name: "Bitcoin",
		feed: "BTC-USD",
		kind: "Crypto"
	},
	{
		symbol: "ETH",
		name: "Ethereum",
		feed: "ETH-USD",
		kind: "Crypto"
	},
	{
		symbol: "SOL",
		name: "Solana",
		feed: "SOL-USD",
		kind: "Crypto"
	}
];
var assetSymbolSchema = enumType([
	"TSLA",
	"AAPL",
	"NVDA",
	"BTC",
	"ETH",
	"SOL"
]);
var investmentSchema = objectType({
	symbol: assetSymbolSchema,
	amount: numberType().finite().positive().max(1e7).refine((n) => Math.abs(n * 100 - Math.round(n * 100)) < 1e-6, "Use at most two decimal places")
});
function parseAssetQuote(payload, expectedSymbol) {
	const result = objectType({ chart: objectType({ result: arrayType(objectType({ meta: objectType({
		symbol: literalType(expectedSymbol),
		currency: literalType("USD"),
		regularMarketPrice: numberType().finite().positive(),
		regularMarketTime: numberType().finite().positive(),
		previousClose: numberType().positive().optional(),
		chartPreviousClose: numberType().positive().optional()
	}) })).nullable() }) }).parse(payload).chart.result?.[0];
	if (!result) throw new Error("Rate unavailable");
	const m = result.meta;
	const previous = m.previousClose ?? m.chartPreviousClose;
	return {
		price: m.regularMarketPrice,
		timestamp: m.regularMarketTime,
		changePercent: previous ? (m.regularMarketPrice - previous) / previous * 100 : null
	};
}
//#endregion
export { investmentSchema as n, parseAssetQuote as r, ASSETS as t };
