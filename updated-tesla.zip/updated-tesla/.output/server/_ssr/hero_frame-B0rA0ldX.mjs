//#region node_modules/.nitro/vite/services/ssr/assets/hero_frame-B0rA0ldX.js
var hero_frame_default = "/assets/hero_frame-B2TK5oKa.jpg";
//#endregion
export { hero_frame_default as t };
