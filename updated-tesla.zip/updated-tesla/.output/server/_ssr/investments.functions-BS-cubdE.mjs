import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Dcy-eaQM.mjs";
import { t as createServerRpc } from "./createServerRpc-CxD4EZ5P.mjs";
import { n as investmentSchema, r as parseAssetQuote, t as ASSETS } from "./investments-MPYYFDUT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/investments.functions-BS-cubdE.js
var getInvestmentRates_createServerFn_handler = createServerRpc({
	id: "813733deccff2ce3a4a4e8d014a2350a90b73f59616550e78806eddcf2860e94",
	name: "getInvestmentRates",
	filename: "src/lib/investments.functions.ts"
}, (opts) => getInvestmentRates.__executeServer(opts));
var getInvestmentRates = createServerFn({ method: "GET" }).handler(getInvestmentRates_createServerFn_handler, async () => {
	return Promise.all(ASSETS.map(async (asset) => {
		try {
			const response = await fetch(`https://query1.finance.yahoo.com/v8/finance/chart/${asset.feed}?interval=1d&range=1d`, { signal: AbortSignal.timeout(8e3) });
			if (!response.ok) throw new Error("Rate unavailable");
			return {
				...asset,
				quote: parseAssetQuote(await response.json(), asset.feed),
				error: null
			};
		} catch {
			return {
				...asset,
				quote: null,
				error: "Rate temporarily unavailable"
			};
		}
	}));
});
var allocateInvestment_createServerFn_handler = createServerRpc({
	id: "b4b8ad236f3d6a2b98d6df7f9045d8c1591883330604c9ed324cdcc92b7c2748",
	name: "allocateInvestment",
	filename: "src/lib/investments.functions.ts"
}, (opts) => allocateInvestment.__executeServer(opts));
var allocateInvestment = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((input) => investmentSchema.parse(input)).handler(allocateInvestment_createServerFn_handler, async ({ data, context }) => {
	const { error } = await context.supabase.rpc("allocate_investment", {
		_symbol: data.symbol,
		_amount: data.amount
	});
	if (error) throw new Error("Investment could not be saved. Check your available balance and try again.");
	return { ok: true };
});
//#endregion
export { allocateInvestment_createServerFn_handler, getInvestmentRates_createServerFn_handler };
