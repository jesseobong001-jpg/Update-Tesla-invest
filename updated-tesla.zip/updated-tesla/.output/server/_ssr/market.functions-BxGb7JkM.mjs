import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { a as numberType, i as literalType, o as objectType, t as arrayType } from "../_libs/zod.mjs";
import { t as createServerRpc } from "./createServerRpc-CxD4EZ5P.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/market.functions-BxGb7JkM.js
var payloadSchema = objectType({ chart: objectType({ result: arrayType(objectType({
	meta: objectType({
		symbol: literalType("TSLA"),
		currency: literalType("USD"),
		regularMarketPrice: numberType().positive(),
		regularMarketTime: numberType(),
		chartPreviousClose: numberType().optional(),
		previousClose: numberType().optional(),
		regularMarketDayHigh: numberType().optional(),
		regularMarketDayLow: numberType().optional(),
		regularMarketVolume: numberType().optional(),
		fiftyTwoWeekHigh: numberType().optional(),
		fiftyTwoWeekLow: numberType().optional()
	}),
	timestamp: arrayType(numberType()),
	indicators: objectType({ quote: arrayType(objectType({ close: arrayType(numberType().nullable()) })) })
})).nullable() }) });
function parseTeslaMarket(payload) {
	const result = payloadSchema.parse(payload).chart.result?.[0];
	if (!result) throw new Error("Quote unavailable");
	const { meta } = result;
	const points = result.timestamp.flatMap((timestamp, i) => {
		const close = result.indicators.quote[0]?.close[i];
		return typeof close === "number" ? [{
			timestamp,
			close
		}] : [];
	});
	const previousClose = meta.previousClose ?? points.at(-2)?.close ?? meta.chartPreviousClose ?? null;
	const change = previousClose ? meta.regularMarketPrice - previousClose : null;
	return {
		price: meta.regularMarketPrice,
		timestamp: meta.regularMarketTime,
		previousClose,
		change,
		changePercent: change !== null && previousClose ? change / previousClose * 100 : null,
		dayHigh: meta.regularMarketDayHigh ?? null,
		dayLow: meta.regularMarketDayLow ?? null,
		volume: meta.regularMarketVolume ?? null,
		yearHigh: meta.fiftyTwoWeekHigh ?? null,
		yearLow: meta.fiftyTwoWeekLow ?? null,
		points
	};
}
var getTeslaMarket_createServerFn_handler = createServerRpc({
	id: "8a1bd87281c3531114c52a7fb49ccc4148854e361177d36d1805628354bb0a07",
	name: "getTeslaMarket",
	filename: "src/lib/market.functions.ts"
}, (opts) => getTeslaMarket.__executeServer(opts));
var getTeslaMarket = createServerFn({ method: "GET" }).handler(getTeslaMarket_createServerFn_handler, async () => {
	try {
		const response = await fetch("https://query1.finance.yahoo.com/v8/finance/chart/TSLA?interval=1d&range=1mo", { signal: AbortSignal.timeout(8e3) });
		if (!response.ok) throw new Error("Market feed unavailable");
		return {
			quote: parseTeslaMarket(await response.json()),
			error: null
		};
	} catch {
		return {
			quote: null,
			error: "Market information is temporarily unavailable. Please try again."
		};
	}
});
//#endregion
export { getTeslaMarket_createServerFn_handler };
