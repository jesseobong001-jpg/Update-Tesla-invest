import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as tesla_wordmark_default } from "./tesla_wordmark-Bax_ylkM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/AppNav-CKEiHbPq.js
var import_jsx_runtime = require_jsx_runtime();
var LINKS = [
	{
		to: "/reserve",
		label: "Preorder"
	},
	{
		to: "/stocks",
		label: "Investment"
	},
	{
		to: "/payment-plans",
		label: "Payment plans"
	}
];
var BASE = "font-wide font-bold uppercase text-chrome hover:text-chrome/70 shrink-0 whitespace-nowrap text-[0.68rem] tracking-[0.08em] md:text-base md:tracking-[0.18em]";
function AppNav({ right, borderless }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: `${borderless ? "" : "border-b border-chrome/10 "}px-4 py-4 md:px-10 md:py-5`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between sm:gap-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				"aria-label": "Tesla home",
				className: "shrink-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: tesla_wordmark_default,
					alt: "Tesla",
					className: "w-32 md:w-36"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex w-full items-center justify-between gap-x-2 sm:w-auto sm:justify-end sm:gap-x-9",
				children: [LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: link.to,
					className: BASE,
					activeProps: { className: `${BASE} underline decoration-2 underline-offset-8` },
					children: link.label
				}, link.to)), right]
			})]
		})
	});
}
//#endregion
export { AppNav as t };
