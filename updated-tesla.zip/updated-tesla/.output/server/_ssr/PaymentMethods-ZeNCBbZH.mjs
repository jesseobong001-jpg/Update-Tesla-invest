import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as Button } from "./button-B2wejuZy.mjs";
import { f as Copy, p as Check } from "../_libs/lucide-react.mjs";
import { t as DEPOSIT_METHODS } from "./payment-methods-ChWa9U61.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/PaymentMethods-ZeNCBbZH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CRYPTO_METHODS = DEPOSIT_METHODS.filter((method) => method.group === "Crypto");
var CARD_METHOD = DEPOSIT_METHODS.find((method) => method.group === "Card");
function PaymentMethods({ value, onChange }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [copyError, setCopyError] = (0, import_react.useState)(false);
	const [cryptoOpen, setCryptoOpen] = (0, import_react.useState)(false);
	async function copy() {
		if (!value) return;
		try {
			await navigator.clipboard.writeText(value.pay);
			setCopied(true);
			setCopyError(false);
		} catch {
			setCopyError(true);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-4",
		children: value ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-chrome/70",
				children: [
					value.group,
					" · ",
					value.label,
					" (",
					value.sub,
					")"
				]
			}),
			value.group === "Card" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-lg border border-chrome/20 p-4 text-sm text-chrome/70",
				children: "Pay by card. Card details aren't collected on this site — no card is charged yet."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-chrome/20 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-chrome/60",
						children: value.group === "Crypto" ? "Send to this address" : "Send to this account"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "break-all text-sm",
							children: value.pay
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "icon",
							"aria-label": copied ? "Copied" : "Copy payment details",
							title: "Copy payment details",
							onClick: copy,
							children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {})
						})]
					}),
					copyError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "status",
						className: "mt-2 text-xs text-crimson",
						children: "Couldn't copy. Select and copy the details above."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-chrome/60",
				children: "Payment details are unverified. No payment is processed here."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				className: "text-chrome/70",
				onClick: () => {
					setCopied(false);
					onChange(null);
				},
				children: "Change method"
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					className: "h-14 w-full rounded-lg border border-chrome/20 bg-transparent text-sm uppercase tracking-widest text-chrome hover:bg-chrome/10 hover:text-chrome",
					"aria-expanded": cryptoOpen,
					onClick: () => setCryptoOpen((open) => !open),
					children: "Pay with crypto"
				}),
				cryptoOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2",
					role: "group",
					"aria-label": "Crypto options",
					children: CRYPTO_METHODS.map((method) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "ghost",
						className: "h-16 flex-col gap-1 rounded-lg border border-chrome/20 px-1 text-chrome hover:bg-chrome/10",
						onClick: () => onChange(method),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm",
							children: method.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-chrome/50",
							children: method.sub
						})]
					}, method.label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "ghost",
					className: "h-16 w-full flex-col gap-1 rounded-lg border border-chrome/20 text-chrome hover:bg-chrome/10",
					onClick: () => onChange(CARD_METHOD),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: "Card"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-chrome/50",
						children: CARD_METHOD.sub
					})]
				})
			]
		})
	});
}
//#endregion
export { PaymentMethods as t };
