import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as Button } from "./button-B2wejuZy.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-fMq9G4Ay.mjs";
import { t as tesla_wordmark_default } from "./tesla_wordmark-Bax_ylkM.mjs";
import { t as AppNav } from "./AppNav-CKEiHbPq.mjs";
import { t as hero_frame_default } from "./hero_frame-B0rA0ldX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-btqrweJb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var tesla_logo_default = "/assets/tesla_logo-CBYfM3j4.png";
function OutroWordmark() {
	const ref = (0, import_react.useRef)(null);
	const [shown, setShown] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const io = new IntersectionObserver((entries) => setShown(!!entries[0]?.isIntersecting), { threshold: .6 });
		io.observe(el);
		return () => io.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: "flex items-center justify-center px-8 py-12",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: tesla_wordmark_default,
			alt: "Tesla",
			className: `wordmark-reveal w-full max-w-[9rem] ${shown ? "is-shown" : ""}`
		})
	});
}
function Index() {
	const [session, setSession] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		supabase.auth.getSession().then(({ data }) => setSession(Boolean(data.session)));
		const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(Boolean(s)));
		return () => sub.subscription.unsubscribe();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "bg-ink text-chrome",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative flex h-[100svh] w-full flex-col overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: hero_frame_default,
						alt: "Tesla Roadster",
						className: "absolute inset-0 h-full w-full object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 hero-veil" }),
					session && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative z-20",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppNav, { borderless: true })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 flex flex-1 flex-col items-center justify-center px-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "sr-only",
								children: "Tesla Roadster"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: tesla_logo_default,
								alt: "Tesla",
								className: "logo-intro w-28 md:w-40"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute inset-x-0 bottom-10 flex flex-col items-center gap-3 px-6 sm:flex-row sm:justify-center",
								children: [!session && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/auth",
									search: { redirect: void 0 },
									className: "w-full max-w-xs rounded-full bg-chrome px-10 py-3 text-center text-sm font-semibold uppercase tracking-widest text-ink transition hover:bg-chrome/85 sm:w-auto",
									children: "Sign in"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/auth",
									search: { redirect: void 0 },
									className: "w-full max-w-xs rounded-full border border-chrome/40 px-10 py-3 text-center text-sm font-semibold uppercase tracking-widest text-chrome transition hover:bg-chrome/10 sm:w-auto",
									children: "Log in"
								})] }), session && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/payment-plans",
									className: "w-full max-w-xs rounded-full bg-chrome px-10 py-3 text-center text-sm font-semibold uppercase tracking-widest text-ink transition hover:bg-chrome/85 sm:w-auto",
									children: "Payment plans"
								})]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutroWordmark, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "stocks",
				className: "border-t border-chrome/10 px-5 py-20 md:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.3em] text-crimson",
						children: "Investors"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-wide mt-4 text-4xl uppercase md:text-7xl",
						children: "Invest in Tesla"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-chrome/70",
						children: "Own a piece of the company building electric cars, energy storage and autonomous vehicles. Tesla shares trade publicly on the Nasdaq."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid grid-cols-2 gap-y-10 md:grid-cols-4",
						children: [
							["TSLA", "Ticker"],
							["Nasdaq", "Exchange"],
							["2010", "Public since"],
							["USD", "Currency"]
						].map(([v, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-wide text-3xl md:text-5xl",
							children: v
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs uppercase tracking-[0.25em] text-chrome/60",
							children: l
						})] }, l))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 flex flex-col gap-3 sm:flex-row",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/stocks",
							className: "rounded-full bg-chrome px-10 py-3 text-center text-sm font-semibold uppercase tracking-widest text-ink transition hover:bg-chrome/85",
							children: "Invest in stocks"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: hero_frame_default,
						alt: "",
						className: "absolute inset-0 h-full w-full object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-ink/60" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex min-h-[60svh] flex-col items-center justify-center px-6 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.3em] text-chrome/70",
								children: "Deliveries from 2028"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-wide mt-4 text-5xl uppercase md:text-8xl",
								children: "Preorder the new Roadster"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-10 flex flex-col gap-3 sm:flex-row",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/reserve",
									className: "rounded-full bg-chrome px-10 py-3 text-sm font-semibold uppercase tracking-widest text-ink transition hover:bg-chrome/85",
									children: "Preorder Roadster"
								})
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-chrome/10 px-5 py-12 md:px-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center gap-8 md:flex-row md:justify-between",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: tesla_wordmark_default,
							alt: "Tesla",
							className: "w-32"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "flex flex-wrap justify-center gap-x-6 gap-y-2 text-xs uppercase tracking-widest text-chrome/60",
							children: [
								"Models",
								"Energy",
								"Charging",
								"Careers",
								"Privacy",
								"Contact"
							].map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "link",
								className: "h-auto p-0 text-xs uppercase tracking-widest text-chrome/60 hover:text-chrome",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/reserve",
									children: l
								})
							}, l))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-chrome/40",
							children: "Tesla © 2026 · Concept"
						})
					]
				})
			})
		]
	});
}
//#endregion
export { Index as component };
