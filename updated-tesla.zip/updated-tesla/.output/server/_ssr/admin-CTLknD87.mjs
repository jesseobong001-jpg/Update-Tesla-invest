import { i as __toESM } from "../_runtime.mjs";
import { o as isAdminAuthenticated, t as adminLogin } from "./admin-DIQeDyiU.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as Button } from "./button-B2wejuZy.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-CTLknD87.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminLogin() {
	const navigate = useNavigate();
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [msg, setMsg] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (isAdminAuthenticated()) {
		navigate({ to: "/admin-dashboard" });
		return null;
	}
	async function submit(e) {
		e.preventDefault();
		setBusy(true);
		setMsg(null);
		const ok = adminLogin(email, password);
		setBusy(false);
		if (ok) navigate({ to: "/admin-dashboard" });
		else setMsg("Invalid admin credentials.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-[100svh] w-full bg-ink text-chrome flex items-center justify-center px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "max-w-sm w-full",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-3xl border border-chrome/15 bg-ink p-8 md:p-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-wide text-3xl uppercase text-center mb-2",
						children: "Admin login"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-center text-sm text-chrome/60 mb-8",
						children: "Tesla investments admin panel"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: submit,
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs text-chrome/60",
									children: "Email"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "email",
									required: true,
									value: email,
									onChange: (e) => setEmail(e.target.value),
									className: "w-full rounded-lg border border-chrome/20 bg-transparent px-4 py-3 text-chrome outline-none focus:border-chrome/60"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs text-chrome/60",
									children: "Password"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "password",
									required: true,
									value: password,
									onChange: (e) => setPassword(e.target.value),
									className: "w-full rounded-lg border border-chrome/20 bg-transparent px-4 py-3 text-chrome outline-none focus:border-chrome/60"
								})]
							}),
							msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-crimson",
								children: msg
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: busy,
								className: "h-12 w-full rounded-full bg-chrome text-ink text-sm font-semibold uppercase hover:bg-chrome/85 disabled:opacity-50",
								children: busy ? "Signing in…" : "Sign in"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-center text-xs text-chrome/50",
						children: "admin@tesla.app · 1234Admin5678"
					})
				]
			})
		})
	});
}
var SplitComponent = AdminLogin;
//#endregion
export { SplitComponent as component };
