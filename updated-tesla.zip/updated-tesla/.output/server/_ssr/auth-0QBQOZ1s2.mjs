import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-fMq9G4Ay.mjs";
import { t as Route } from "./auth-ehOh6BmY.mjs";
import { t as tesla_wordmark_default } from "./tesla_wordmark-Bax_ylkM.mjs";
import { t as PasswordInput } from "./PasswordInput-Cpgll29Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-0QBQOZ1s2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var safe = (r) => r && r.startsWith("/") && !r.startsWith("//") ? r : "/reserve";
function AuthPage() {
	const { redirect } = Route.useSearch();
	const to = safe(redirect);
	const navigate = useNavigate();
	const [mode, setMode] = (0, import_react.useState)("in");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [msg, setMsg] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		supabase.auth.getSession().then(({ data }) => {
			if (data.session) navigate({
				to,
				replace: true
			});
		});
		const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
			if (s) navigate({
				to,
				replace: true
			});
		});
		return () => sub.subscription.unsubscribe();
	}, [navigate, to]);
	async function submit(e) {
		e.preventDefault();
		setBusy(true);
		setMsg(null);
		if (mode === "in") {
			const { error } = await supabase.auth.signInWithPassword({
				email,
				password
			});
			if (error) setMsg(error.message);
		} else {
			const { data, error } = await supabase.auth.signUp({
				email,
				password,
				options: { emailRedirectTo: window.location.origin + to }
			});
			if (error) setMsg(error.message);
			else if (!data.session) setMsg("Check your email to confirm your account, then sign in.");
		}
		setBusy(false);
	}
	async function forgot() {
		if (!email) {
			setMsg("Enter your email first, then tap Forgot password.");
			return;
		}
		setBusy(true);
		setMsg(null);
		const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin + "/reset-password" });
		setBusy(false);
		setMsg(error ? error.message : "Check your email for a link to choose a new password.");
	}
	const input = "w-full rounded-full border border-chrome/20 bg-transparent px-5 py-3 text-chrome placeholder:text-chrome/40 outline-none focus:border-chrome/60";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-[100svh] flex-col items-center justify-center bg-ink px-6 text-chrome",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: tesla_wordmark_default,
				alt: "Tesla",
				className: "mb-10 w-36"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-wide text-center text-3xl uppercase",
					children: mode === "in" ? "Sign in" : "Create account"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-center text-sm text-chrome/60",
					children: "You need an account to reserve your Roadster."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: input,
							type: "email",
							required: true,
							placeholder: "Email",
							value: email,
							onChange: (e) => setEmail(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordInput, {
							className: input,
							required: true,
							minLength: 6,
							placeholder: "Password",
							value: password,
							onChange: (e) => setPassword(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: busy,
							className: "w-full rounded-full border border-chrome/60 py-3 text-sm font-semibold uppercase tracking-widest hover:bg-chrome/10 disabled:opacity-50",
							children: busy ? "…" : mode === "in" ? "Sign in" : "Sign up"
						})
					]
				}),
				mode === "in" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: forgot,
					className: "mt-4 w-full text-center text-sm text-chrome/60 hover:text-chrome",
					children: "Forgot password?"
				}),
				msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-center text-sm text-crimson",
					children: msg
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setMode(mode === "in" ? "up" : "in"),
					className: "mt-6 w-full text-center text-sm text-chrome/60 hover:text-chrome",
					children: mode === "in" ? "New here? Create an account" : "Have an account? Sign in"
				})
			]
		})]
	});
}
//#endregion
export { AuthPage as component };
