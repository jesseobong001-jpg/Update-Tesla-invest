import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-ehOh6BmY.js
var $$splitComponentImporter = () => import("./auth-0QBQOZ1s2.mjs");
var Route = createFileRoute("/auth")({
	validateSearch: (s) => ({ redirect: typeof s["redirect"] === "string" ? s["redirect"] : void 0 }),
	head: () => ({ meta: [
		{ title: "Sign in — Tesla Roadster" },
		{
			name: "description",
			content: "Sign in or create an account to reserve your Tesla Roadster."
		},
		{
			property: "og:title",
			content: "Sign in — Tesla Roadster"
		},
		{
			property: "og:description",
			content: "Sign in to reserve your Tesla Roadster flying car."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
