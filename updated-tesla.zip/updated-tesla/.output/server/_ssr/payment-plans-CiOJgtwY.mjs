import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as Button } from "./button-B2wejuZy.mjs";
import { t as AppNav } from "./AppNav-CKEiHbPq.mjs";
import { t as Route } from "./payment-plans-CjmpqFoD.mjs";
import { t as AppFooter } from "./AppFooter-Db6kr7eX.mjs";
import { n as OrderForm, o as installment, r as PLANS, s as money, t as MODELS } from "./OrderForm-Pko4lQfO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/payment-plans-CiOJgtwY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Installments({ userId }) {
	const [freq, setFreq] = (0, import_react.useState)("month");
	const [plans, setPlans] = (0, import_react.useState)({});
	const [order, setOrder] = (0, import_react.useState)(null);
	const available = PLANS.filter((p) => p.unit === freq);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "installments",
		className: "mx-auto max-w-5xl px-5 pb-16 md:px-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-[0.25em] text-crimson",
				children: "Pay by installment"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 font-wide text-2xl uppercase md:text-4xl",
				children: "Drive now, pay over time"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 inline-flex rounded-full border border-chrome/20 p-1",
				role: "tablist",
				"aria-label": "Plan frequency",
				children: ["week", "month"].map((unit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					role: "tab",
					"aria-selected": freq === unit,
					onClick: () => setFreq(unit),
					className: `rounded-full px-6 py-2 text-xs font-semibold uppercase tracking-widest transition ${freq === unit ? "bg-chrome text-ink" : "text-chrome/60 hover:text-chrome"}`,
					children: unit === "week" ? "Weekly" : "Monthly"
				}, unit))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
				children: MODELS.map((m) => {
					const stored = plans[m.name];
					const plan = available.find((p) => p.id === stored) ?? available[0];
					if (!plan) return null;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "overflow-hidden rounded-3xl border border-chrome/15",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: m.img,
							alt: `Tesla ${m.name}`,
							loading: "lazy",
							className: "aspect-[3/2] w-full object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-wide text-lg uppercase",
										children: m.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-chrome/60",
										children: m.price
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mt-4 block text-xs text-chrome/60",
									children: ["Plan", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										value: plan.id,
										onChange: (e) => setPlans({
											...plans,
											[m.name]: e.target.value
										}),
										className: "mt-2 w-full rounded-lg border border-chrome/20 bg-ink px-3 py-2 text-sm text-chrome",
										children: available.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
											value: p.id,
											children: [
												p.label,
												" · ",
												money(installment(m.price, p)),
												"/",
												p.unit
											]
										}, p.id))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-4 font-wide text-2xl",
									children: [money(installment(m.price, plan)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-sm text-chrome/60",
										children: [" / ", plan.unit]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: () => setOrder({
										model: m,
										plan
									}),
									className: "mt-4 h-11 w-full rounded-full bg-chrome text-sm font-semibold uppercase text-ink hover:bg-chrome/85",
									children: "Order now"
								})
							]
						})]
					}, m.name);
				})
			}),
			order && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderForm, {
				model: order.model,
				plan: order.plan,
				userId,
				onClose: () => setOrder(null)
			})
		]
	});
}
function PaymentPlans() {
	const { user } = Route.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-[100svh] bg-ink text-chrome",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Installments, { userId: user.id })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppFooter, {})
		]
	});
}
//#endregion
export { PaymentPlans as component };
