import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/payment-plans-CjmpqFoD.js
var $$splitComponentImporter = () => import("./payment-plans-CiOJgtwY.mjs");
var Route = createFileRoute("/_authenticated/payment-plans")({
	head: () => ({ meta: [
		{ title: "Payment plans — Tesla vehicles" },
		{
			name: "description",
			content: "Choose a weekly or monthly payment plan for every Tesla model."
		},
		{
			property: "og:title",
			content: "Payment plans — Tesla vehicles"
		},
		{
			property: "og:description",
			content: "Pay for your Tesla weekly or monthly with flexible plans."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
