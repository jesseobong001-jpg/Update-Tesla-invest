import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-fMq9G4Ay.mjs";
import { t as tesla_wordmark_default } from "./tesla_wordmark-Bax_ylkM.mjs";
import { t as PasswordInput } from "./PasswordInput-Cpgll29Z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reset-password-Ba4GQ2Id.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ResetPassword() {
	const navigate = useNavigate();
	const [ready, setReady] = (0, import_react.useState)(false);
	const [checking, setChecking] = (0, import_react.useState)(true);
	const [msg, setMsg] = (0, import_react.useState)(null);
	const [pw, setPw] = (0, import_react.useState)("");
	const [pw2, setPw2] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		async function init() {
			const url = new URL(window.location.href);
			const code = url.searchParams.get("code");
			const hash = new URLSearchParams(url.hash.replace(/^#/, ""));
			const type = url.searchParams.get("type") ?? hash.get("type");
			if (code) {
				const { error } = await supabase.auth.exchangeCodeForSession(code);
				const { data } = await supabase.auth.getSession();
				if (data.session) setReady(true);
				else setMsg(error?.message ?? "This reset link has expired. Request a new one.");
				url.searchParams.delete("code");
				url.searchParams.delete("type");
				window.history.replaceState({}, "", url.pathname + url.search);
				setChecking(false);
				return;
			}
			const { data } = await supabase.auth.getSession();
			if (data.session && type === "recovery") setReady(true);
			else if (data.session) navigate({
				to: "/reserve",
				replace: true
			});
			else setMsg("This reset link has expired. Request a new one.");
			setChecking(false);
		}
		init();
	}, [navigate]);
	async function submit(e) {
		e.preventDefault();
		if (pw.length < 6) return setMsg("Use at least 6 characters.");
		if (pw !== pw2) return setMsg("The two passwords don't match.");
		setBusy(true);
		setMsg(null);
		const { error } = await supabase.auth.updateUser({ password: pw });
		setBusy(false);
		if (error) return setMsg(error.message);
		navigate({
			to: "/reserve",
			replace: true
		});
	}
	const input = "w-full rounded-full border border-chrome/20 bg-transparent px-5 py-3 text-chrome placeholder:text-chrome/40 outline-none focus:border-chrome/60";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-[100svh] flex-col items-center justify-center bg-ink px-6 text-chrome",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: tesla_wordmark_default,
				alt: "Tesla",
				className: "mb-10 w-36"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-wide text-center text-3xl uppercase",
					children: "New password"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-center text-sm text-chrome/60",
					children: "Choose a new password for your account."
				}),
				checking && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-center text-sm text-chrome/60",
					children: "Checking your link…"
				}),
				ready && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					className: "mt-8 space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordInput, {
							className: input,
							required: true,
							minLength: 6,
							placeholder: "New password",
							value: pw,
							onChange: (e) => setPw(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordInput, {
							className: input,
							required: true,
							minLength: 6,
							placeholder: "Repeat new password",
							value: pw2,
							onChange: (e) => setPw2(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: busy,
							className: "w-full rounded-full bg-chrome py-3 text-sm font-semibold uppercase tracking-widest text-ink hover:bg-chrome/85 disabled:opacity-50",
							children: busy ? "…" : "Save new password"
						})
					]
				}),
				msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-center text-sm text-crimson",
					children: msg
				}),
				!ready && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/auth",
					search: { redirect: void 0 },
					className: "mt-6 block w-full text-center text-sm text-chrome/60 hover:text-chrome",
					children: "Back to sign in"
				})
			]
		})]
	});
}
//#endregion
export { ResetPassword as component };
