import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { o as objectType, s as stringType } from "../_libs/zod.mjs";
import { t as createServerRpc } from "./createServerRpc-CxD4EZ5P.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/locations.functions-DPHR8OwX.js
var getCountries_createServerFn_handler = createServerRpc({
	id: "551d241f8441b5fe044d2212a4092d8892d0416576bbbcbfb5cf4309998663d0",
	name: "getCountries",
	filename: "src/lib/locations.functions.ts"
}, (opts) => getCountries.__executeServer(opts));
var getCountries = createServerFn({ method: "GET" }).handler(getCountries_createServerFn_handler, async () => {
	const { Country } = await import("../_libs/country-state-city.mjs").then((n) => n.t);
	return Country.getAllCountries().map(({ name, isoCode }) => ({
		name,
		code: isoCode
	})).sort((a, b) => a.name.localeCompare(b.name));
});
var getStates_createServerFn_handler = createServerRpc({
	id: "c1964b3579e6962aabd181aca431c300cbbb44e1c32e2f8024963eb0ed55f0ba",
	name: "getStates",
	filename: "src/lib/locations.functions.ts"
}, (opts) => getStates.__executeServer(opts));
var getStates = createServerFn({ method: "GET" }).inputValidator(objectType({ country: stringType().regex(/^[A-Z]{2}$/) })).handler(getStates_createServerFn_handler, async ({ data }) => {
	const { State } = await import("../_libs/country-state-city.mjs").then((n) => n.t);
	return [...new Set((State.getStatesOfCountry(data.country) ?? []).map((state) => state.name))].sort((a, b) => a.localeCompare(b));
});
//#endregion
export { getCountries_createServerFn_handler, getStates_createServerFn_handler };
