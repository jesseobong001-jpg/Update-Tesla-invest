import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as Button } from "./button-B2wejuZy.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-fMq9G4Ay.mjs";
import { t as useServerFn } from "./useServerFn-CrZF2pjq.mjs";
import { t as AppNav } from "./AppNav-CKEiHbPq.mjs";
import { t as PaymentMethods } from "./PaymentMethods-ZeNCBbZH.mjs";
import { t as ASSETS } from "./investments-MPYYFDUT.mjs";
import { t as AppFooter } from "./AppFooter-Db6kr7eX.mjs";
import { i as allocateInvestment, n as MarketInfo, r as Route, t as InvestmentRates } from "./stocks-CmqNpNAq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/stocks-BglJwL2u.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FACTS = [
	["Ticker", "TSLA"],
	["Exchange", "Nasdaq"],
	["Public since", "June 2010"],
	["Currency", "USD"],
	["IPO price", "$17 / share"],
	["Stock splits", "5-for-1 (2020), 3-for-1 (2022)"],
	["Sector", "Automotive & Energy"],
	["Index", "S&P 500, Nasdaq-100"]
];
var WHY = [
	["Vehicles", "Model 3, Y, S, X, Cybertruck and the new Roadster."],
	["Energy", "Powerwall and Megapack storage for homes and grids."],
	["Autonomy", "Self-driving software and the robotaxi network."],
	["Robotics", "Optimus humanoid robot for everyday work."]
];
function Stocks() {
	const [selected, setSelected] = (0, import_react.useState)("TSLA");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-[100svh] bg-ink text-chrome",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-5xl px-5 pb-16 md:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, {
						selected,
						onSelect: setSelected
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-10 text-xs uppercase tracking-[0.25em] text-crimson",
						children: "Investment"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-wide text-4xl uppercase md:text-6xl",
						children: "Stocks & crypto"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvestmentRates, {
						selected,
						onSelect: setSelected
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-10 max-w-xl text-sm text-chrome/60",
						children: "Tesla, Inc. trades on the Nasdaq under the ticker TSLA."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketInfo, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid grid-cols-2 gap-6 md:grid-cols-4",
						children: FACTS.map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-chrome/15 p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-widest text-chrome/50",
								children: k
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-wide text-base",
								children: v
							})]
						}, k))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-5xl px-5 pb-24 md:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-wide text-2xl uppercase md:text-4xl",
						children: "What you're investing in"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 grid gap-4 sm:grid-cols-2",
						children: WHY.map(([t, d]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-3xl border border-chrome/15 p-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-wide text-lg uppercase",
								children: t
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-chrome/60",
								children: d
							})]
						}, t))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#invest",
							onClick: (e) => {
								e.preventDefault();
								window.scrollTo({
									top: 0,
									behavior: "smooth"
								});
							},
							className: "rounded-full bg-chrome px-8 py-3 text-center text-sm font-semibold uppercase tracking-widest text-ink hover:bg-chrome/85",
							children: "Invest"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#market",
							onClick: (e) => {
								e.preventDefault();
								document.getElementById("market")?.scrollIntoView({ behavior: "smooth" });
							},
							className: "rounded-full border border-chrome/40 px-8 py-3 text-center text-sm font-semibold uppercase tracking-widest hover:bg-chrome/10",
							children: "View market"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-8 text-xs text-chrome/40",
						children: "For information only, not financial advice."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppFooter, {})
		]
	});
}
var usd = (n) => n.toLocaleString("en-US", {
	style: "currency",
	currency: "USD"
});
function Wallet({ selected, onSelect }) {
	const { user } = Route.useRouteContext();
	const navigate = useNavigate();
	const [balance, setBalance] = (0, import_react.useState)(0);
	const [invested, setInvested] = (0, import_react.useState)(0);
	const [amount, setAmount] = (0, import_react.useState)("");
	const [msg, setMsg] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [depositOpen, setDepositOpen] = (0, import_react.useState)(false);
	const [method, setMethod] = (0, import_react.useState)(null);
	const [dAmount, setDAmount] = (0, import_react.useState)("");
	const [dMsg, setDMsg] = (0, import_react.useState)(null);
	const [allocations, setAllocations] = (0, import_react.useState)([]);
	const allocate = useServerFn(allocateInvestment);
	async function loadWallet() {
		const [{ data, error }, positions] = await Promise.all([supabase.from("wallets").select("balance,invested").eq("user_id", user.id).maybeSingle(), supabase.from("investment_allocations").select("symbol,amount").eq("user_id", user.id)]);
		if (error || positions.error) {
			setMsg({
				ok: false,
				t: "Your wallet could not be loaded. Please refresh."
			});
			return;
		}
		if (data) {
			setBalance(Number(data.balance));
			setInvested(Number(data.invested));
		}
		setAllocations((positions.data ?? []).map((p) => ({
			symbol: p.symbol,
			amount: Number(p.amount)
		})));
	}
	(0, import_react.useEffect)(() => {
		loadWallet();
	}, [user.id]);
	async function invest() {
		const a = Math.round(Number(amount) * 100) / 100;
		if (!a || a <= 0 || a > 1e7) return setMsg({
			ok: false,
			t: "Enter an amount above $0."
		});
		if (a > balance) return setMsg({
			ok: false,
			t: "Not enough balance. Deposit first."
		});
		setBusy(true);
		try {
			await allocate({ data: {
				symbol: selected,
				amount: a
			} });
			await loadWallet();
			setAmount("");
			setMsg({
				ok: true,
				t: `Allocated ${usd(a)} to ${selected}.`
			});
		} catch (error) {
			setMsg({
				ok: false,
				t: error instanceof Error ? error.message : "Investment could not be saved."
			});
		} finally {
			setBusy(false);
		}
	}
	async function deposit() {
		if (!method) return;
		const a = Math.round(Number(dAmount) * 100) / 100;
		if (!a || a <= 0 || a > 1e7) return setDMsg("Enter an amount above $0.");
		if (method.group === "Card") {
			setDepositOpen(false);
			navigate({ to: "/pay" });
			return;
		}
		setDepositOpen(false);
		navigate({
			to: "/confirm-payment",
			search: {
				amount: a,
				method: method.label
			}
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "invest",
		className: "scroll-mt-6 border-b border-chrome/15 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-widest text-chrome/50",
				children: "Balance"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `mt-1 break-words font-wide leading-none md:text-8xl ${usd(balance).length > 10 ? "text-3xl" : "text-6xl"}`,
				children: usd(balance)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-widest text-chrome/50",
					children: "Total allocated"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-wide text-lg md:text-xl",
					children: usd(invested)
				})]
			}),
			allocations.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 divide-y divide-chrome/10",
				children: allocations.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between gap-3 py-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.symbol }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: usd(p.amount) })]
				}, p.symbol))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: "investment-asset",
				className: "mt-6 block text-xs text-chrome/60",
				children: "Investment"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				id: "investment-asset",
				value: selected,
				onChange: (e) => onSelect(e.target.value),
				className: "mt-2 w-full rounded-lg border border-chrome/20 bg-ink px-4 py-3 text-sm",
				children: ASSETS.map((asset) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
					value: asset.symbol,
					children: [
						asset.name,
						" (",
						asset.symbol,
						")"
					]
				}, asset.symbol))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				"aria-label": "Investment amount in USD",
				type: "number",
				inputMode: "decimal",
				min: "0",
				step: "0.01",
				placeholder: "Amount in USD",
				value: amount,
				onChange: (e) => setAmount(e.target.value),
				className: "mt-6 w-full rounded-xl border border-chrome/20 bg-transparent px-4 py-3 text-sm outline-none focus:border-chrome/60"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: busy,
					onClick: () => {
						setDepositOpen(true);
						setMethod(null);
						setDMsg(null);
					},
					className: "h-12 rounded-full bg-chrome text-sm font-semibold uppercase text-ink hover:bg-chrome/85",
					children: "Deposit"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					disabled: busy,
					onClick: invest,
					className: "h-12 rounded-full border-chrome/40 bg-transparent text-sm font-semibold text-chrome hover:bg-chrome/10 hover:text-chrome",
					children: busy ? "Saving…" : `Invest · ${selected}`
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs leading-relaxed text-chrome/50",
				children: "Allocations are recorded on this site only. No brokerage or exchange is connected; investing here does not purchase real shares or crypto."
			}),
			msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `mt-3 text-xs ${msg.ok ? "text-chrome/70" : "text-crimson"}`,
				children: msg.t
			}),
			depositOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center bg-ink/80 p-4 backdrop-blur sm:items-center",
				onClick: () => setDepositOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[90svh] w-full max-w-md overflow-y-auto rounded-3xl border border-chrome/15 bg-ink p-6",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-wide text-2xl uppercase",
								children: "Deposit"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								"aria-label": "Close",
								onClick: () => {
									setDepositOpen(false);
									setMethod(null);
									setDMsg(null);
								},
								className: "text-2xl text-chrome/60 hover:text-chrome",
								children: "×"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentMethods, {
								value: method,
								onChange: (value) => {
									setMethod(value);
									setDMsg(null);
									if (value?.group === "Card") {
										setDepositOpen(false);
										navigate({ to: "/pay" });
									}
								}
							})
						}),
						method && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								"aria-label": "Deposit amount in USD",
								type: "number",
								inputMode: "decimal",
								min: "0",
								step: "0.01",
								placeholder: "Amount in USD",
								value: dAmount,
								onChange: (e) => setDAmount(e.target.value),
								className: "mt-3 w-full rounded-xl border border-chrome/20 bg-transparent px-4 py-3 text-sm outline-none focus:border-chrome/60"
							}),
							dMsg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs text-crimson",
								children: dMsg
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: deposit,
								className: "mt-4 h-12 w-full rounded-full bg-chrome text-sm font-semibold text-ink hover:bg-chrome/85",
								children: method.group === "Card" ? `Pay ${usd(Number(dAmount) || 0)}` : "I've made the deposit"
							})
						] })
					]
				})
			})
		]
	});
}
//#endregion
export { Stocks as component };
