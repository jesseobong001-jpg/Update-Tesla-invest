//#region node_modules/.nitro/vite/services/ssr/assets/payment-methods-ChWa9U61.js
var DEPOSIT_METHODS = [
	{
		group: "Crypto",
		label: "Bitcoin",
		sub: "BTC",
		pay: "adress1235388"
	},
	{
		group: "Crypto",
		label: "USDT",
		sub: "Tether",
		pay: "adress1235388"
	},
	{
		group: "Crypto",
		label: "Ethereum",
		sub: "ETH",
		pay: "adress1235388"
	},
	{
		group: "Card",
		label: "Card",
		sub: "Debit or credit",
		pay: ""
	}
];
//#endregion
export { DEPOSIT_METHODS as t };
