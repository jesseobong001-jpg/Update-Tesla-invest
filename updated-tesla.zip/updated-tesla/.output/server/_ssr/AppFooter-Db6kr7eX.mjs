import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-fMq9G4Ay.mjs";
import { t as tesla_wordmark_default } from "./tesla_wordmark-Bax_ylkM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/AppFooter-Db6kr7eX.js
var import_jsx_runtime = require_jsx_runtime();
function AppFooter() {
	const navigate = useNavigate();
	async function signOut() {
		await supabase.auth.signOut();
		navigate({
			to: "/",
			replace: true
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-chrome/10 px-5 py-10 md:px-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-5xl flex-col items-center gap-6 sm:flex-row sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: tesla_wordmark_default,
				alt: "Tesla",
				className: "w-28"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: signOut,
				className: "font-wide w-full rounded-full border border-chrome/40 px-10 py-3 text-center text-sm font-bold uppercase tracking-[0.18em] text-chrome hover:bg-chrome/10 sm:w-auto",
				children: "Sign out"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mx-auto mt-8 max-w-5xl text-xs text-chrome/40",
			children: "Tesla © 2026 · Concept"
		})]
	});
}
//#endregion
export { AppFooter as t };
