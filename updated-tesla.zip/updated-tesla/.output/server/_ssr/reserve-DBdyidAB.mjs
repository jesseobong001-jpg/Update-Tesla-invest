import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reserve-DBdyidAB.js
var $$splitComponentImporter = () => import("./reserve-g2wntCXe.mjs");
var Route = createFileRoute("/_authenticated/reserve")({
	head: () => ({ meta: [
		{ title: "Reserve your Roadster — Tesla" },
		{
			name: "description",
			content: "Reserve your Tesla Roadster flying car."
		},
		{
			property: "og:title",
			content: "Reserve your Roadster — Tesla"
		},
		{
			property: "og:description",
			content: "Place your Tesla Roadster reservation."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
