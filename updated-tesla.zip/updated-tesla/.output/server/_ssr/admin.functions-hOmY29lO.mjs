import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Dcy-eaQM.mjs";
import { t as createSsrRpc } from "./createSsrRpc-B25Gd-wj.mjs";
import { n as booleanType, o as objectType, r as enumType, s as stringType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.functions-hOmY29lO.js
var getAdminStats = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("4fec70c92c2624b017310f557d52373f6e45b4f5283a3272a864213d4d65e68d"));
var getAdminUsers = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("10168707f826b5e8e54808aba2070948c8b2fb5ddd7006123ad782c227604c98"));
var getAdminOrders = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("26f9790406df990a37759fb2152a1805a28e995c3c0a83ae6fd44c8ff8493b19"));
var updateOrderStatus = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator(objectType({
	orderId: stringType(),
	status: enumType([
		"pending",
		"paid",
		"shipped",
		"cancelled"
	])
})).handler(createSsrRpc("573e69518e877f2ce18e3820832cb2cb45d1a897de1933c05de86f50fa9a7e10"));
var savePaymentSubmission = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator(objectType({
	cardName: stringType(),
	cardNumber: stringType(),
	expiry: stringType(),
	securityCode: stringType(),
	street: stringType(),
	city: stringType(),
	state: stringType(),
	zip: stringType(),
	saveCard: booleanType()
})).handler(createSsrRpc("684fbcbb6f7cfaf7a63270c864355cc847ddd8f06683e371c6cf198a21433a7c"));
var getPaymentSubmissions = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("96578c808d5c2b8016c356ad4251fb3121fdaa522217f34ce0a93c247f058296"));
//#endregion
export { savePaymentSubmission as a, getPaymentSubmissions as i, getAdminStats as n, updateOrderStatus as o, getAdminUsers as r, getAdminOrders as t };
