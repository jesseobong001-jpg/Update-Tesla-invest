//#region node_modules/.nitro/vite/services/ssr/assets/model_3-CphTR_0O.js
var model_3_default = "/assets/model_3-C_F7Cvnd.png";
//#endregion
export { model_3_default as t };
