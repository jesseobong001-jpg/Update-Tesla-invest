import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime, r as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as supabase } from "./client-fMq9G4Ay.mjs";
import { t as AppNav } from "./AppNav-CKEiHbPq.mjs";
import { t as AppFooter } from "./AppFooter-Db6kr7eX.mjs";
import { t as hero_frame_default } from "./hero_frame-B0rA0ldX.mjs";
import { a as getStates, i as getCountries, n as OrderForm, t as MODELS } from "./OrderForm-Pko4lQfO.mjs";
import { t as Route } from "./reserve-DBdyidAB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reserve-g2wntCXe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LocationPicker({ className, country, city, onChange }) {
	const [code, setCode] = (0, import_react.useState)("");
	const countries = useQuery({
		queryKey: ["countries"],
		queryFn: () => getCountries(),
		staleTime: Infinity
	});
	const states = useQuery({
		queryKey: ["states", code],
		queryFn: () => getStates({ data: { country: code } }),
		enabled: Boolean(code),
		staleTime: Infinity
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
		required: true,
		"aria-label": "Country",
		className,
		value: code,
		onChange: (e) => {
			const c = countries.data?.find((i) => i.code === e.target.value);
			setCode(e.target.value);
			onChange({
				country: c?.name ?? "",
				city: ""
			});
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: "",
			children: countries.isPending ? "Loading countries…" : "Select country"
		}), countries.data?.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: c.code,
			children: c.name
		}, c.code))]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
		required: true,
		"aria-label": "State",
		className,
		disabled: !code || states.isPending || !states.data?.length,
		value: city,
		onChange: (e) => onChange({
			country,
			city: e.target.value
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: "",
				children: !code ? "Select country first" : states.isPending ? "Loading states…" : states.data?.length ? "Select state" : "No states listed"
			}),
			city && !(states.data ?? []).includes(city) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: city,
				children: city
			}),
			(states.data ?? []).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: s,
				children: s
			}, s))
		]
	})] });
}
function Reserve() {
	const { user } = Route.useRouteContext();
	const [mine, setMine] = (0, import_react.useState)([]);
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [country, setCountry] = (0, import_react.useState)("");
	const [city, setCity] = (0, import_react.useState)("");
	const [msg, setMsg] = (0, import_react.useState)(null);
	const [order, setOrder] = (0, import_react.useState)(null);
	const load = () => supabase.from("reservations").select("id,full_name,country,created_at").order("created_at", { ascending: false }).then(({ data }) => setMine(data ?? []));
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	async function submit(e) {
		e.preventDefault();
		if (!country || !city) return setMsg("Select your country and state.");
		const { error } = await supabase.from("reservations").insert({
			full_name: name,
			phone: phone || null,
			country: `${city}, ${country}`,
			user_id: user.id
		});
		if (error) return setMsg(error.message);
		setMsg("Reservation confirmed. Welcome to the sky.");
		setName("");
		setPhone("");
		setCountry("");
		setCity("");
		load();
	}
	const input = "w-full rounded-full border border-chrome/20 bg-transparent px-5 py-3 text-chrome placeholder:text-chrome/40 outline-none focus:border-chrome/60";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-[100svh] bg-ink text-chrome",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-5xl gap-10 px-5 pb-20 md:grid-cols-2 md:px-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: hero_frame_default,
					alt: "Tesla Roadster",
					className: "aspect-[4/5] w-full rounded-3xl object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-wide text-4xl uppercase md:text-6xl",
						children: "Preorder the new Roadster"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm text-chrome/60",
						children: ["Signed in as ", user.email]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: submit,
						className: "mt-8 space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: input,
								required: true,
								placeholder: "Full name",
								value: name,
								onChange: (e) => setName(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: input,
								placeholder: "Phone (optional)",
								value: phone,
								onChange: (e) => setPhone(e.target.value)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocationPicker, {
								className: `${input} bg-ink`,
								country,
								city,
								onChange: (v) => {
									setCountry(v.country);
									setCity(v.city);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "w-full rounded-full bg-chrome py-3 text-sm font-semibold uppercase tracking-widest text-ink hover:bg-chrome/85",
								children: "Confirm preorder"
							})
						]
					}),
					msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-crimson",
						children: msg
					}),
					mine.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.25em] text-chrome/50",
							children: "Your reservations"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 divide-y divide-chrome/10",
							children: mine.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between py-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									r.full_name,
									" · ",
									r.country
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-chrome/50",
									children: new Date(r.created_at).toLocaleDateString()
								})]
							}, r.id))
						})]
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-5xl px-5 pb-20 md:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.25em] text-chrome/50",
						children: "Lineup"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-wide text-3xl uppercase md:text-5xl",
						children: "Tesla models"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
						children: MODELS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "overflow-hidden rounded-3xl border border-chrome/15",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: m.img,
								alt: `Tesla ${m.name}`,
								loading: "lazy",
								width: 1024,
								height: 680,
								className: "aspect-[3/2] w-full object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-wide text-xl uppercase",
										children: m.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-chrome/60",
										children: m.tag
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-6 text-xs uppercase tracking-widest text-chrome/50",
										children: "From"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-wide text-2xl",
										children: m.price
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-xs text-chrome/60",
										children: m.spec
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setOrder(m),
										className: "mt-5 w-full rounded-full bg-chrome py-2.5 text-xs font-semibold uppercase tracking-widest text-ink hover:bg-chrome/85",
										children: "Order now"
									})
								]
							})]
						}, m.name))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-chrome/40",
						children: "Starting prices in USD, before incentives. Subject to change."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto max-w-5xl px-5 pb-24 md:px-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-3xl border border-crimson/40 p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.25em] text-crimson",
							children: "Investment"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-wide text-3xl uppercase md:text-5xl",
							children: "Own a piece of Tesla"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 grid grid-cols-2 gap-4 text-sm md:grid-cols-4",
							children: [
								["Ticker", "TSLA"],
								["Exchange", "Nasdaq"],
								["Public since", "2010"],
								["Currency", "USD"]
							].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-widest text-chrome/50",
								children: k
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-wide text-lg",
								children: v
							})] }, k))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/stocks",
								className: "rounded-full bg-chrome px-6 py-3 text-xs font-semibold uppercase tracking-widest text-ink",
								children: "Invest in stocks"
							})
						})
					]
				})
			}),
			order && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderForm, {
				model: order,
				userId: user.id,
				onClose: () => setOrder(null)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppFooter, {})
		]
	});
}
//#endregion
export { Reserve as component };
