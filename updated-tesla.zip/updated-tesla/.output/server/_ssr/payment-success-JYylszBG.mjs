import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as model_3_default } from "./model_3-CphTR_0O.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/payment-success-JYylszBG.js
var import_jsx_runtime = require_jsx_runtime();
function PaymentSuccess() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-[100svh] w-full bg-white text-gray-900 font-sans flex flex-col items-center justify-center px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-md text-center px-6 py-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: model_3_default,
					alt: "Tesla Model 3",
					className: "mx-auto mb-8 max-w-[260px] h-auto rounded-xl shadow-lg"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-wide text-3xl uppercase md:text-5xl mb-4",
					children: "Order confirmed"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-lg text-gray-600 mb-2",
					children: "Your order is on the way."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-lg text-gray-600 mb-8",
					children: "A confirmation email has been sent to you."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "rounded-full bg-chrome px-10 py-3 text-center text-sm font-semibold uppercase tracking-widest text-ink transition hover:bg-chrome/85",
					children: "Back to home"
				})
			]
		})
	});
}
//#endregion
export { PaymentSuccess as component };
