//#region node_modules/.nitro/vite/services/ssr/assets/admin-DIQeDyiU.js
var STORAGE_KEY_PREFIX = "tesla_admin_";
function isAdminAuthenticated() {
	if (typeof window === "undefined") return false;
	try {
		const raw = localStorage.getItem(`${STORAGE_KEY_PREFIX}session`);
		if (!raw) return false;
		const session = JSON.parse(raw);
		return Boolean(session?.authenticated && session?.expiresAt && Date.now() < session.expiresAt);
	} catch {
		return false;
	}
}
function adminLogin(email, password) {
	if (email === "admin@tesla.app" && password === "1234Admin5678") {
		const session = {
			authenticated: true,
			email,
			expiresAt: Date.now() + 6048e5
		};
		localStorage.setItem(`${STORAGE_KEY_PREFIX}session`, JSON.stringify(session));
		return true;
	}
	return false;
}
function adminLogout() {
	if (typeof window === "undefined") return;
	localStorage.removeItem(`${STORAGE_KEY_PREFIX}session`);
}
var DEFAULT_PRICES = {
	"Model 3": "$42,490",
	"Model Y": "$44,990",
	"Model S": "$84,990",
	"Model X": "$89,990",
	Cybertruck: "$79,990",
	Cybercab: "$29,990",
	Semi: "$179,990",
	Roadster: "$200,000"
};
function getPrices() {
	if (typeof window === "undefined") return DEFAULT_PRICES;
	try {
		const raw = localStorage.getItem(`${STORAGE_KEY_PREFIX}prices`);
		if (!raw) return DEFAULT_PRICES;
		return {
			...DEFAULT_PRICES,
			...JSON.parse(raw)
		};
	} catch {
		return DEFAULT_PRICES;
	}
}
function setPrices(prices) {
	if (typeof window === "undefined") return;
	localStorage.setItem(`${STORAGE_KEY_PREFIX}prices`, JSON.stringify(prices));
}
var DEFAULT_CRYPTO = {
	Bitcoin: "adress1235388",
	USDT: "adress1235388",
	Ethereum: "adress1235388"
};
function getCryptoDestinations() {
	if (typeof window === "undefined") return DEFAULT_CRYPTO;
	try {
		const raw = localStorage.getItem(`${STORAGE_KEY_PREFIX}crypto`);
		if (!raw) return DEFAULT_CRYPTO;
		return {
			...DEFAULT_CRYPTO,
			...JSON.parse(raw)
		};
	} catch {
		return DEFAULT_CRYPTO;
	}
}
function setCryptoDestinations(destinations) {
	if (typeof window === "undefined") return;
	localStorage.setItem(`${STORAGE_KEY_PREFIX}crypto`, JSON.stringify(destinations));
}
var DEFAULT_CONTENT = {
	heroTitle: "Tesla Roadster — Models and Investments",
	heroDescription: "Preorder the new Tesla Roadster or invest in TSLA from one place.",
	stocksTitle: "Invest in Tesla",
	stocksDescription: "Own a piece of the company building electric cars, energy storage and autonomous vehicles. Tesla shares trade publicly on the Nasdaq.",
	reserveTitle: "Preorder the new Roadster",
	reserveDescription: "Deliveries from 2028",
	footerText: "Tesla © 2026 · Concept"
};
function getWebsiteContent() {
	if (typeof window === "undefined") return DEFAULT_CONTENT;
	try {
		const raw = localStorage.getItem(`${STORAGE_KEY_PREFIX}content`);
		if (!raw) return DEFAULT_CONTENT;
		return {
			...DEFAULT_CONTENT,
			...JSON.parse(raw)
		};
	} catch {
		return DEFAULT_CONTENT;
	}
}
function setWebsiteContent(content) {
	if (typeof window === "undefined") return;
	localStorage.setItem(`${STORAGE_KEY_PREFIX}content`, JSON.stringify(content));
}
//#endregion
export { getWebsiteContent as a, setPrices as c, getPrices as i, setWebsiteContent as l, adminLogout as n, isAdminAuthenticated as o, getCryptoDestinations as r, setCryptoDestinations as s, adminLogin as t };
