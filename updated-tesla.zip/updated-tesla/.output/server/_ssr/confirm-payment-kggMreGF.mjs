import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as Button } from "./button-B2wejuZy.mjs";
import { l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Dcy-eaQM.mjs";
import { t as createSsrRpc } from "./createSsrRpc-B25Gd-wj.mjs";
import { a as numberType, o as objectType, s as stringType } from "../_libs/zod.mjs";
import { t as supabase } from "./client-fMq9G4Ay.mjs";
import { t as useServerFn } from "./useServerFn-CrZF2pjq.mjs";
import { t as DEPOSIT_METHODS } from "./payment-methods-ChWa9U61.mjs";
import { t as Route } from "./confirm-payment-Dc24vLhD.mjs";
import { t as AppNav } from "./AppNav-CKEiHbPq.mjs";
import { t as PaymentMethods } from "./PaymentMethods-ZeNCBbZH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/confirm-payment-kggMreGF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var submitDeposit = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator(objectType({
	amount: numberType().positive().max(1e7),
	method: stringType(),
	path: stringType().max(250)
})).handler(createSsrRpc("dff922681f093011d53e7542cd5e173678f4312a18e546a53922cd225ff54eac"));
function ConfirmPayment() {
	const { user } = Route.useRouteContext();
	const search = Route.useSearch();
	const [amount, setAmount] = (0, import_react.useState)(search.amount > 0 ? String(search.amount) : "");
	const [method, setMethod] = (0, import_react.useState)(DEPOSIT_METHODS.find((m) => m.label === search.method) ?? null);
	const [file, setFile] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [message, setMessage] = (0, import_react.useState)("");
	const [submitted, setSubmitted] = (0, import_react.useState)(false);
	const submit = useServerFn(submitDeposit);
	async function confirm(e) {
		e.preventDefault();
		if (!file || !method || !Number.isFinite(Number(amount)) || Number(amount) <= 0 || Number(amount) > 1e7) {
			setMessage("Select a method, amount, and payment screenshot.");
			return;
		}
		if (file.size > 5242880 || ![
			"image/png",
			"image/jpeg",
			"image/webp"
		].includes(file.type)) {
			setMessage("Choose a PNG, JPG, or WebP image under 5 MB.");
			return;
		}
		setBusy(true);
		setMessage("Uploading screenshot, then reviewing with AI…");
		try {
			const ext = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : "jpg";
			const path = `${user.id}/${crypto.randomUUID()}.${ext}`;
			const { error } = await supabase.storage.from("payment-proofs").upload(path, file, {
				contentType: file.type,
				upsert: false
			});
			if (error) throw new Error("Couldn't upload the screenshot. Please try again.");
			const result = await submit({ data: {
				amount: Number(amount),
				method: method.label,
				path
			} });
			setSubmitted(true);
			setMessage(result.message);
		} catch (err) {
			setMessage(err instanceof Error ? err.message : "Couldn't submit your payment.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-[100svh] bg-ink text-chrome",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppNav, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-lg px-5 pb-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-wide text-3xl uppercase",
					children: "Confirm payment"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm leading-relaxed text-chrome/60",
					children: "AI checks the screenshot's visible details. Your balance stays unchanged until receipt of funds is independently verified."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: confirm,
					className: "mt-8 space-y-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
							disabled: busy || submitted,
							className: "space-y-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block space-y-2 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Amount in USD" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										type: "number",
										min: "0.01",
										max: "10000000",
										step: "0.01",
										value: amount,
										onChange: (e) => setAmount(e.target.value),
										className: "w-full rounded-lg border border-chrome/20 bg-ink px-4 py-3"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentMethods, {
									value: method,
									onChange: setMethod
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block space-y-2 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Payment screenshot" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										type: "file",
										accept: "image/png,image/jpeg,image/webp",
										onChange: (e) => setFile(e.target.files?.[0] ?? null),
										className: "block w-full min-w-0 rounded-lg border border-chrome/20 p-3 text-xs"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-chrome/50",
									children: "PNG, JPG, WebP · Up to 5 MB · Stored privately. The screenshot is sent to AI for review."
								})
							]
						}),
						!submitted && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "h-12 w-full bg-chrome text-ink hover:bg-chrome/85",
							type: "submit",
							disabled: busy,
							children: busy ? "Reviewing…" : "Submit for review"
						}),
						message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							role: "status",
							className: "text-sm leading-relaxed text-chrome/80",
							children: message
						})
					]
				})
			]
		})]
	});
}
//#endregion
export { ConfirmPayment as component };
