import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/confirm-payment-Dc24vLhD.js
var $$splitComponentImporter = () => import("./confirm-payment-kggMreGF.mjs");
var Route = createFileRoute("/_authenticated/confirm-payment")({
	validateSearch: (s) => ({
		amount: typeof s["amount"] === "number" && Number.isFinite(s["amount"]) ? s["amount"] : 0,
		method: typeof s["method"] === "string" ? s["method"] : ""
	}),
	head: () => ({ meta: [
		{ title: "Confirm payment — Tesla investments" },
		{
			name: "description",
			content: "Submit a private payment screenshot for review of your Tesla investment deposit."
		},
		{
			property: "og:title",
			content: "Confirm payment — Tesla investments"
		},
		{
			property: "og:description",
			content: "Submit your deposit payment screenshot for review."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
