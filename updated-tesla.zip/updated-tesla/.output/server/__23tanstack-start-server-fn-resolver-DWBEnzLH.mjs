//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-DWBEnzLH.js
var manifest = {
	"10168707f826b5e8e54808aba2070948c8b2fb5ddd7006123ad782c227604c98": {
		functionName: "getAdminUsers_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-DOaxzBVu.mjs")
	},
	"26f9790406df990a37759fb2152a1805a28e995c3c0a83ae6fd44c8ff8493b19": {
		functionName: "getAdminOrders_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-DOaxzBVu.mjs")
	},
	"4fec70c92c2624b017310f557d52373f6e45b4f5283a3272a864213d4d65e68d": {
		functionName: "getAdminStats_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-DOaxzBVu.mjs")
	},
	"551d241f8441b5fe044d2212a4092d8892d0416576bbbcbfb5cf4309998663d0": {
		functionName: "getCountries_createServerFn_handler",
		importer: () => import("./_ssr/locations.functions-DPHR8OwX.mjs")
	},
	"573e69518e877f2ce18e3820832cb2cb45d1a897de1933c05de86f50fa9a7e10": {
		functionName: "updateOrderStatus_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-DOaxzBVu.mjs")
	},
	"684fbcbb6f7cfaf7a63270c864355cc847ddd8f06683e371c6cf198a21433a7c": {
		functionName: "savePaymentSubmission_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-DOaxzBVu.mjs")
	},
	"813733deccff2ce3a4a4e8d014a2350a90b73f59616550e78806eddcf2860e94": {
		functionName: "getInvestmentRates_createServerFn_handler",
		importer: () => import("./_ssr/investments.functions-BS-cubdE.mjs")
	},
	"8a1bd87281c3531114c52a7fb49ccc4148854e361177d36d1805628354bb0a07": {
		functionName: "getTeslaMarket_createServerFn_handler",
		importer: () => import("./_ssr/market.functions-BxGb7JkM.mjs")
	},
	"96578c808d5c2b8016c356ad4251fb3121fdaa522217f34ce0a93c247f058296": {
		functionName: "getPaymentSubmissions_createServerFn_handler",
		importer: () => import("./_ssr/admin.functions-DOaxzBVu.mjs")
	},
	"b4b8ad236f3d6a2b98d6df7f9045d8c1591883330604c9ed324cdcc92b7c2748": {
		functionName: "allocateInvestment_createServerFn_handler",
		importer: () => import("./_ssr/investments.functions-BS-cubdE.mjs")
	},
	"c1964b3579e6962aabd181aca431c300cbbb44e1c32e2f8024963eb0ed55f0ba": {
		functionName: "getStates_createServerFn_handler",
		importer: () => import("./_ssr/locations.functions-DPHR8OwX.mjs")
	},
	"dff922681f093011d53e7542cd5e173678f4312a18e546a53922cd225ff54eac": {
		functionName: "submitDeposit_createServerFn_handler",
		importer: () => import("./_ssr/deposits.functions-6lhb4fbG.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ??= await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
