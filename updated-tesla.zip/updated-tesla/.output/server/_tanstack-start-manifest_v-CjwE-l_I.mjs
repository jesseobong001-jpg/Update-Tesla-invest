//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CjwE-l_I.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/tomdev/Downloads/remix-of-remix-of-tesla.invest-main/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/admin",
			"/admin-dashboard",
			"/auth",
			"/reset-password"
		],
		preloads: [
			"/assets/index-_8B90n1-.js",
			"/assets/useRouter-Dpb7RwMI.js",
			"/assets/createServerFn-BS4t1TZ1.js",
			"/assets/not-found-DIgawKw1.js",
			"/assets/invariant-CgFvOqN2.js",
			"/assets/link-DmIVlRKu.js",
			"/assets/matchContext-DN9gHYo-.js",
			"/assets/preload-helper-BTh7jEnC.js",
			"/assets/useSelector-wdOmz881.js",
			"/assets/auth-middleware-JDjVgB0Q.js",
			"/assets/useBaseQuery-DubnubG-.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-_8B90n1-.js"
		} }]
	},
	"/": {
		filePath: "/home/tomdev/Downloads/remix-of-remix-of-tesla.invest-main/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DNGecdzh.js",
			"/assets/tesla_wordmark-BKx-nrS8.js",
			"/assets/AppNav-C5OJ3UK2.js",
			"/assets/hero_frame-D_PnzOxJ.js"
		]
	},
	"/_authenticated": {
		filePath: "/home/tomdev/Downloads/remix-of-remix-of-tesla.invest-main/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/confirm-payment",
			"/_authenticated/pay",
			"/_authenticated/payment-plans",
			"/_authenticated/payment-success",
			"/_authenticated/reserve",
			"/_authenticated/stocks"
		],
		preloads: ["/assets/route-DZ1KXerg.js"]
	},
	"/admin": {
		filePath: "/home/tomdev/Downloads/remix-of-remix-of-tesla.invest-main/src/routes/admin.tsx",
		children: void 0,
		preloads: ["/assets/admin-C-G5C8Zp.js", "/assets/useNavigate-DT7ghfdY.js"]
	},
	"/admin-dashboard": {
		filePath: "/home/tomdev/Downloads/remix-of-remix-of-tesla.invest-main/src/routes/admin-dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-dashboard-CRIBlkjT.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/admin.functions-z85CXTqy.js"
		]
	},
	"/auth": {
		filePath: "/home/tomdev/Downloads/remix-of-remix-of-tesla.invest-main/src/routes/auth.tsx",
		children: void 0,
		preloads: [
			"/assets/auth-Dyoj7RCl.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/PasswordInput-3HidDNBm.js",
			"/assets/tesla_wordmark-BKx-nrS8.js"
		]
	},
	"/reset-password": {
		filePath: "/home/tomdev/Downloads/remix-of-remix-of-tesla.invest-main/src/routes/reset-password.tsx",
		children: void 0,
		preloads: [
			"/assets/reset-password-DxK3xvk8.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/PasswordInput-3HidDNBm.js",
			"/assets/tesla_wordmark-BKx-nrS8.js"
		]
	},
	"/_authenticated/confirm-payment": {
		filePath: "/home/tomdev/Downloads/remix-of-remix-of-tesla.invest-main/src/routes/_authenticated/confirm-payment.tsx",
		children: void 0,
		preloads: [
			"/assets/confirm-payment-fDpOFdwn.js",
			"/assets/useServerFn-_bchQTyX.js",
			"/assets/PaymentMethods-BKHtCd1J.js",
			"/assets/AppNav-C5OJ3UK2.js"
		]
	},
	"/_authenticated/pay": {
		filePath: "/home/tomdev/Downloads/remix-of-remix-of-tesla.invest-main/src/routes/_authenticated/pay.tsx",
		children: void 0,
		preloads: [
			"/assets/pay-CH51MDLQ.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/admin.functions-z85CXTqy.js"
		]
	},
	"/_authenticated/payment-plans": {
		filePath: "/home/tomdev/Downloads/remix-of-remix-of-tesla.invest-main/src/routes/_authenticated/payment-plans.tsx",
		children: void 0,
		preloads: [
			"/assets/payment-plans-D1p5to-a.js",
			"/assets/OrderForm-Dw0A69M9.js",
			"/assets/AppNav-C5OJ3UK2.js",
			"/assets/AppFooter-B6yywdCE.js"
		]
	},
	"/_authenticated/payment-success": {
		filePath: "/home/tomdev/Downloads/remix-of-remix-of-tesla.invest-main/src/routes/_authenticated/payment-success.tsx",
		children: void 0,
		preloads: ["/assets/payment-success-ksu2X9t5.js", "/assets/model_3-DmN8wZFe.js"]
	},
	"/_authenticated/reserve": {
		filePath: "/home/tomdev/Downloads/remix-of-remix-of-tesla.invest-main/src/routes/_authenticated/reserve.tsx",
		children: void 0,
		preloads: [
			"/assets/reserve-C6oEcrPy.js",
			"/assets/OrderForm-Dw0A69M9.js",
			"/assets/AppNav-C5OJ3UK2.js",
			"/assets/AppFooter-B6yywdCE.js",
			"/assets/hero_frame-D_PnzOxJ.js"
		]
	},
	"/_authenticated/stocks": {
		filePath: "/home/tomdev/Downloads/remix-of-remix-of-tesla.invest-main/src/routes/_authenticated/stocks.tsx",
		children: void 0,
		preloads: [
			"/assets/stocks-BrPGIfAg.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/useServerFn-_bchQTyX.js",
			"/assets/PaymentMethods-BKHtCd1J.js",
			"/assets/AppNav-C5OJ3UK2.js",
			"/assets/AppFooter-B6yywdCE.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
